/**
 * ================================================================
 *  Monetixra — FINAL COMPLETE SERVER v8.0
 *  ALL FEATURES: Socket.io | WebRTC | Supabase | OpenAI | DeepSeek
 *  EmailJS | Web Push | bKash | Nagad | Rate Limiting | Security
 * ================================================================
 */
'use strict';

require('dotenv').config();
const appConfig = require('./config.js');
const express = require('express');
const http = require('http');
const cluster = require('cluster');
const { Server } = require('socket.io');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const compression = require('compression');
const webpush = require('web-push');
const path = require('path');
const crypto = require('crypto');
const fetch = (...a) => import('node-fetch').then(({ default: f }) => f(...a));
const { exec } = require('child_process');
const fs = require('fs');
const { promisify } = require('util');
const execAsync = promisify(exec);
const jwt = require('jsonwebtoken');
const { body, validationResult } = require('express-validator');
const NodeCache = require('node-cache');
const cache = new NodeCache({ stdTTL: 300 }); // 5 minutes
const Redis = require('ioredis');
const { Pool } = require('pg');
const SUPABASE_CONNECTIVITY_TTL_MS = 30_000;
const isProduction = String(process.env.NODE_ENV || '').toLowerCase() === 'production';

// Import video transcoder
const videoTranscoder = require('./video-transcoder');

// Import unified storage system
const unifiedStorage = require('./unified-storage-system');

// ── Redis Configuration ────────────────────────────────────────────────────
let redisClient = null;
if (process.env.REDIS_URL) {
  redisClient = new Redis(process.env.REDIS_URL, {
    maxRetriesPerRequest: 3,
    retryDelayOnFailover: 100,
    enableReadyCheck: true,
    enableOfflineQueue: false, // Fail fast when Redis is down
    lazyConnect: true, // Connect on first operation
    keepAlive: 30000, // Keep connections alive
    connectTimeout: 10000,
    // Performance optimizations
    enableAutoPipelining: true, // Pipeline commands automatically
    maxRetriesPerRequest: 3,
    retryStrategy: (times) => {
      const delay = Math.min(times * 50, 2000);
      return delay;
    }
  });

  redisClient.on('connect', () => {
    console.log('[Redis] ✅ Connected successfully');
  });

  redisClient.on('error', (err) => {
    console.error('[Redis] ❌ Connection error:', err.message);
  });
} else {
  console.log('[Redis] ⚠️ REDIS_URL not set, using in-memory cache only');
}

// ── PostgreSQL Pool Configuration (PgBouncer) ──────────────────────────────
let pgPool = null;
if (process.env.DATABASE_URL) {
  pgPool = new Pool({
    connectionString: process.env.DATABASE_URL,
    max: 30, // Increased pool size for better performance
    min: 5, // Minimum connections
    idleTimeoutMillis: 30000,
    connectionTimeoutMillis: 2000,
    maxUses: 7500, // Recycle connections after this many uses
    allowExitOnIdle: true
  });

  pgPool.on('connect', () => {
    console.log('[PostgreSQL] ✅ New client connected');
  });

  pgPool.on('error', (err) => {
    console.error('[PostgreSQL] ❌ Unexpected error:', err.message);
  });
} else {
  console.log('[PostgreSQL] ⚠️ DATABASE_URL not set, using Supabase only');
}

function resolveEnv(name, fallback = '') {
  const value = process.env[name];
  if (typeof value === 'string' && value.trim() !== '') {
    return value.trim();
  }
  return fallback;
}

function normalizeSupabaseUrl(value) {
  if (!value) return '';
  try {
    const parsed = new URL(value);
    return `${parsed.protocol}//${parsed.host}`.replace(/\/+$/, '');
  } catch {
    return String(value).replace(/\/+$/, '');
  }
}

// ── Config ────────────────────────────────────────────────────
const PORT = process.env.PORT || 3000;
const OPENAI_KEY = process.env.OPENAI_API_KEY || '';
const DEEPSEEK_KEY = process.env.DEEPSEEK_API_KEY || '';
const JWT_SECRET = process.env.JWT_SECRET || (isProduction ? '' : crypto.randomBytes(64).toString('hex'));
const ADMIN_ID = process.env.ADMIN_ID || 'admin_matiur';
const ADMIN_PASS = process.env.ADMIN_PASS || (isProduction ? '' : crypto.randomBytes(32).toString('hex'));
const ADMIN_API_SECRET = process.env.ADMIN_API_SECRET || '';
const ALLOWED_ORIGINS = (process.env.ALLOWED_ORIGINS || '').split(',').map(s => s.trim()).filter(Boolean);
const TRUSTED_DB_TABLES = new Set((process.env.ALLOWED_DB_TABLES || 'users,posts,transactions,media').split(',').map(s => s.trim()).filter(Boolean));
const SOCKET_AUTH_REQUIRED = String(process.env.SOCKET_AUTH_REQUIRED || 'false').toLowerCase() === 'true';
const PTS_PER_USD = Number(process.env.PTS_PER_USD || 1000);

// Cloudinary Configuration
const CLOUDINARY_CLOUD_NAME = resolveEnv('CLOUDINARY_CLOUD_NAME');
const CLOUDINARY_API_KEY = resolveEnv('CLOUDINARY_API_KEY');
const CLOUDINARY_API_SECRET = resolveEnv('CLOUDINARY_API_SECRET');
const SUPABASE_URL = normalizeSupabaseUrl(resolveEnv('SUPABASE_URL', appConfig.SUPABASE_URL || ''));
const SUPABASE_ANON = resolveEnv('SUPABASE_ANON_KEY', appConfig.SUPABASE_ANON_KEY || '');
const SUPABASE_SERVICE_ROLE = resolveEnv('SUPABASE_SERVICE_ROLE_KEY');
const SUPABASE_SERVER_KEY = SUPABASE_SERVICE_ROLE || SUPABASE_ANON;
const supabaseState = {
  configured: Boolean(SUPABASE_URL && SUPABASE_SERVER_KEY),
  reachable: false,
  checkedAt: 0,
  lastError: null,
  fallbackMode: false
};

function validateProductionEnv() {
  if (!isProduction) return;
  const missing = ['JWT_SECRET', 'ADMIN_PASS', 'SUPABASE_URL', 'SUPABASE_ANON_KEY']
    .filter(name => !resolveEnv(name));

  if (missing.length) {
    throw new Error(`[Env] Missing required production configuration: ${missing.join(', ')}`);
  }

  if (SUPABASE_URL && !/^https:\/\/[a-z0-9-]+\.supabase\.co$/i.test(SUPABASE_URL)) {
    console.warn('[Env] Production hardening: SUPABASE_URL is not in a valid Supabase project format.');
  }
}

validateProductionEnv();

// MEGA API Configuration
const MEGA_API_KEY = resolveEnv('MEGA_API_KEY');

// ── Redis Caching Helper Functions ───────────────────────────────────────────
const RedisCache = {
  async get(key) {
    if (!redisClient) return null;
    try {
      const data = await redisClient.get(key);
      return data ? JSON.parse(data) : null;
    } catch (error) {
      console.error('[Redis] Get error:', error.message);
      return null;
    }
  },

  async set(key, value, ttl = 300) {
    if (!redisClient) return false;
    try {
      const serialized = JSON.stringify(value);
      if (ttl > 0) {
        await redisClient.setex(key, ttl, serialized);
      } else {
        await redisClient.set(key, serialized);
      }
      return true;
    } catch (error) {
      console.error('[Redis] Set error:', error.message);
      return false;
    }
  },

  async del(key) {
    if (!redisClient) return false;
    try {
      await redisClient.del(key);
      return true;
    } catch (error) {
      console.error('[Redis] Delete error:', error.message);
      return false;
    }
  },

  async delPattern(pattern) {
    if (!redisClient) return false;
    try {
      const keys = await redisClient.keys(pattern);
      if (keys.length > 0) {
        await redisClient.del(...keys);
      }
      return true;
    } catch (error) {
      console.error('[Redis] Delete pattern error:', error.message);
      return false;
    }
  },

  // Cache user balance
  async getUserBalance(userId) {
    const cacheKey = `user:balance:${userId}`;
    const cached = await this.get(cacheKey);
    if (cached !== null) return cached;
    return null; // Let caller fetch from DB
  },

  async setUserBalance(userId, balance, ttl = 300) {
    const cacheKey = `user:balance:${userId}`;
    return await this.set(cacheKey, balance, ttl);
  },

  // Cache live feed
  async getLiveFeed(page = 0) {
    const cacheKey = `live:feed:${page}`;
    return await this.get(cacheKey);
  },

  async setLiveFeed(page, posts, ttl = 60) {
    const cacheKey = `live:feed:${page}`;
    return await this.set(cacheKey, posts, ttl);
  },

  // Cache leaderboard
  async getLeaderboard(type = 'points') {
    const cacheKey = `leaderboard:${type}`;
    return await this.get(cacheKey);
  },

  async setLeaderboard(type, leaderboard, ttl = 300) {
    const cacheKey = `leaderboard:${type}`;
    return await this.set(cacheKey, leaderboard, ttl);
  },

  // Invalidate user-related cache
  async invalidateUserCache(userId) {
    await this.delPattern(`user:*:${userId}`);
    await this.delPattern(`feed:*:${userId}`);
  },

  // Cache API responses for better performance
  async getApiResponse(endpoint, params = {}) {
    const cacheKey = `api:${endpoint}:${JSON.stringify(params)}`;
    return await this.get(cacheKey);
  },

  async setApiResponse(endpoint, params, data, ttl = 60) {
    const cacheKey = `api:${endpoint}:${JSON.stringify(params)}`;
    return await this.set(cacheKey, data, ttl);
  },

  // Cache frequently accessed data
  async getGlobalStats() {
    const cacheKey = 'global:stats';
    return await this.get(cacheKey);
  },

  async setGlobalStats(stats, ttl = 120) {
    const cacheKey = 'global:stats';
    return await this.set(cacheKey, stats, ttl);
  }
};

// ── PostgreSQL Pool Helper Functions ────────────────────────────────────────
const PostgreSQL = {
  // Query cache for frequently accessed data
  queryCache: new Map(),
  cacheStats: { hits: 0, misses: 0 },

  async query(text, params, useCache = false, cacheTTL = 60) {
    if (!pgPool) {
      throw new Error('PostgreSQL pool not initialized');
    }

    // Check cache for SELECT queries
    if (useCache && text.trim().toUpperCase().startsWith('SELECT')) {
      const cacheKey = `${text}:${JSON.stringify(params)}`;
      const cached = this.queryCache.get(cacheKey);

      if (cached && Date.now() - cached.timestamp < cacheTTL * 1000) {
        this.cacheStats.hits++;
        return cached.data;
      }
      this.cacheStats.misses++;
    }

    const start = Date.now();
    try {
      const res = await pgPool.query(text, params);
      const duration = Date.now() - start;

      // Log slow queries
      if (duration > 1000) {
        console.warn('[PostgreSQL] Slow query detected:', { text, duration, rows: res.rowCount });
      } else {
        console.log('[PostgreSQL] Executed query', { text, duration, rows: res.rowCount });
      }

      // Cache SELECT results
      if (useCache && text.trim().toUpperCase().startsWith('SELECT')) {
        const cacheKey = `${text}:${JSON.stringify(params)}`;
        this.queryCache.set(cacheKey, {
          data: res,
          timestamp: Date.now()
        });

        // Clean old cache entries periodically
        if (this.queryCache.size > 1000) {
          this.cleanCache();
        }
      }

      return res;
    } catch (error) {
      console.error('[PostgreSQL] Query error:', error.message);
      throw error;
    }
  },

  cleanCache() {
    const now = Date.now();
    for (const [key, value] of this.queryCache.entries()) {
      if (now - value.timestamp > 300000) { // 5 minutes
        this.queryCache.delete(key);
      }
    }
  },

  getCacheStats() {
    return {
      ...this.cacheStats,
      size: this.queryCache.size,
      hitRate: this.cacheStats.hits / (this.cacheStats.hits + this.cacheStats.misses) || 0
    };
  },

  async getUser(userId) {
    const query = 'SELECT * FROM users WHERE id = $1';
    const res = await this.query(query, [userId]);
    return res.rows[0];
  },

  async updateUserPoints(userId, points) {
    const query = 'UPDATE users SET points = points + $1 WHERE id = $2 RETURNING points';
    const res = await this.query(query, [points, userId]);
    return res.rows[0];
  },

  async createTransaction(userId, type, amount, metadata = {}) {
    const query = `
      INSERT INTO transactions (user_id, type, amount, metadata, created_at)
      VALUES ($1, $2, $3, $4, NOW())
      RETURNING *
    `;
    const res = await this.query(query, [userId, type, amount, JSON.stringify(metadata)]);
    return res.rows[0];
  },

  async getPoolStats() {
    if (!pgPool) return null;
    return {
      totalCount: pgPool.totalCount,
      idleCount: pgPool.idleCount,
      waitingCount: pgPool.waitingCount
    };
  },

  async close() {
    if (pgPool) {
      await pgPool.end();
      console.log('[PostgreSQL] Pool closed');
    }
  }
};

// Agora Configuration
const AGORA_APP_ID = process.env.AGORA_APP_ID || 'e9cfd627a92f4466a047b2a820e1382e';
const AGORA_APP_CERTIFICATE = process.env.AGORA_APP_CERTIFICATE || '3ea92e07b5204067afdaaf8b06457c46';
const AGORA_API_KEY = process.env.AGORA_API_KEY || '333568318583158';
const AGORA_API_SECRET = process.env.AGORA_API_SECRET || '3aPp5oR0zmJX9P4oOfb3fR3a3SI';

// AdMob Configuration
const ADMOB_APP_ID = process.env.ADMOB_APP_ID || 'ca-app-pub-2253243248364888~1427340343';
const ADMOB_BANNER_AD_UNIT = process.env.ADMOB_BANNER_AD_UNIT || 'ca-app-pub-2253243248364888/3990983995';
const ADMOB_INTERSTITIAL_AD_UNIT = process.env.ADMOB_INTERSTITIAL_AD_UNIT || 'ca-app-pub-2253243248364888/3199587018';
const ADMOB_REWARDED_AD_UNIT = process.env.ADMOB_REWARDED_AD_UNIT || 'ca-app-pub-2253243248364888/5139354646';

// AdSense Configuration
const ADSENSE_CLIENT = process.env.ADSENSE_CLIENT || 'ca-pub-2397116277801081';

// Adsterra Configuration
const ADSTERRA_API_KEY = process.env.ADSTERRA_API_KEY || '';
const METERED_KEY = resolveEnv('METERED_API_KEY');
const GOOGLE_KEY = resolveEnv('GOOGLE_API_KEY');
const GOOGLE_VISION = resolveEnv('GOOGLE_VISION_KEY');
const BKASH_APP_KEY = process.env.BKASH_APP_KEY || '';
const BKASH_APP_SECRET = process.env.BKASH_APP_SECRET || '';
const BKASH_USERNAME = process.env.BKASH_USERNAME || '';
const BKASH_PASSWORD = process.env.BKASH_PASSWORD || '';
const NAGAD_MERCHANT = process.env.NAGAD_MERCHANT_ID || '';
const NAGAD_KEY = process.env.NAGAD_PUBLIC_KEY || '';
const VAPID_PUBLIC = process.env.VAPID_PUBLIC_KEY || '';
const VAPID_PRIVATE = process.env.VAPID_PRIVATE_KEY || '';
const VAPID_EMAIL = process.env.VAPID_EMAIL || 'mailto:myworktoolsp3@gmail.com';

// TURN fallback
const STATIC_ICE = [
  { urls: 'stun:stun.relay.metered.ca:80' },
  { urls: 'turn:global.relay.metered.ca:80', username: 'd583b2ca0185d321a1fd3b93', credential: 'olukX7eOalIsC9EK' },
  { urls: 'turn:global.relay.metered.ca:80?transport=tcp', username: 'd583b2ca0185d321a1fd3b93', credential: 'olukX7eOalIsC9EK' },
  { urls: 'turn:global.relay.metered.ca:443', username: 'd583b2ca0185d321a1fd3b93', credential: 'olukX7eOalIsC9EK' },
  { urls: 'turns:global.relay.metered.ca:443?transport=tcp', username: 'd583b2ca0185d321a1fd3b93', credential: 'olukX7eOalIsC9EK' },
];

// ── Web Push Setup ────────────────────────────────────────────
if (VAPID_PUBLIC && VAPID_PRIVATE) {
  webpush.setVapidDetails(VAPID_EMAIL, VAPID_PUBLIC, VAPID_PRIVATE);
  console.log('[WebPush] VAPID configured ✅');
}
const pushSubscriptions = new Map(); // userId → subscription

// ── App ───────────────────────────────────────────────────────
const app = express();
app.disable('x-powered-by');
app.set('trust proxy', 1);

// Performance optimization: HTTP server with better configuration
const server = http.createServer({
  keepAlive: true,
  keepAliveTimeout: 65000,
  headersTimeout: 66000,
  requestTimeout: 300000
}, app);

// Increase connection limits for better performance
server.maxConnections = 10000;
server.maxRequestsPerSocket = 0; // Unlimited requests per connection

// Cluster mode for multi-core CPU utilization
const numCPUs = require('os').cpus().length;

if (cluster.isMaster && process.env.NODE_ENV === 'production') {
  console.log(`[Cluster] Master ${process.pid} is running`);
  console.log(`[Cluster] Forking ${numCPUs} workers`);

  // Fork workers
  for (let i = 0; i < numCPUs; i++) {
    cluster.fork();
  }

  cluster.on('exit', (worker, code, signal) => {
    console.log(`[Cluster] Worker ${worker.process.pid} died with code ${code} and signal ${signal}`);
    console.log('[Cluster] Starting a new worker');
    cluster.fork();
  });

  // Don't start server in master process
  module.exports = { app, server };
  return; // Stop execution in master process
} else {
  // Worker process or development mode
  if (cluster.isWorker) {
    console.log(`[Cluster] Worker ${process.pid} started`);
  }
}

// CORS: Allow all origins for development (Facebook-style global access)
const allowedOrigins = [
  'http://localhost:3000',
  'http://127.0.0.1:3000',
  'http://127.0.0.1:54310',
  'https://monetixra.netlify.app',
  'https://monetixra.vercel.app',
  process.env.FRONTEND_URL,
  ...ALLOWED_ORIGINS
].filter(Boolean);

const io = new Server(server, {
  cors: {
    origin: allowedOrigins,
    methods: ['GET', 'POST'],
    credentials: true
  },
  pingInterval: 25000, pingTimeout: 60000
});

// Enhanced compression with better performance
app.use(compression({
  filter: (req, res) => {
    if (req.headers['x-no-compression']) return false;
    return compression.filter(req, res);
  },
  threshold: 1024, // Only compress responses larger than 1KB
  level: 6, // Balance between compression speed and ratio
  chunkSize: 16 * 1024, // 16KB chunks for better performance
  memLevel: 8 // Memory level for better compression
}));

app.use(helmet({
  contentSecurityPolicy: false,
  crossOriginEmbedderPolicy: false,
  hsts: {
    maxAge: 31536000,
    includeSubDomains: true,
    preload: true
  }
}));
app.use(cors({
  origin: function (origin, callback) {
    // Allow requests with no origin (like mobile apps or curl requests)
    if (!origin) return callback(null, true);

    // Allow all origins for Facebook-style global access (development mode)
    callback(null, true);
  },
  credentials: true
}));
app.use(express.json({
  limit: '10mb',
  verify: (req, _res, buf) => {
    if (req.originalUrl === '/api/payment/stripe/webhook') req.rawBody = buf;
  },
  strict: false // Be more lenient with JSON parsing for better performance
}));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Add response time middleware for monitoring
app.use((req, res, next) => {
  const start = Date.now();
  res.on('finish', () => {
    const duration = Date.now() - start;
    if (duration > 1000) {
      console.log(`[Performance] Slow request: ${req.method} ${req.path} - ${duration}ms`);
    }
    // Log performance metrics for optimization
    if (duration > 500) {
      console.log(`[Performance] Request: ${req.method} ${req.path} - ${duration}ms`);
    }
  });
  next();
});

// Add connection keep-alive for better performance
app.use((req, res, next) => {
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('Keep-Alive', 'timeout=5, max=1000');
  next();
});

// Add performance headers for better browser caching
app.use((req, res, next) => {
  // Remove X-Powered-By header for security
  res.removeHeader('X-Powered-By');

  // Add performance hints
  if (req.path.endsWith('.js') || req.path.endsWith('.css')) {
    res.setHeader('Link', '</sw.js>; rel=service-worker');
  }

  // CDN and edge caching headers
  if (req.path.startsWith('/public') || req.path.startsWith('/js') || req.path.startsWith('/css')) {
    res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
    res.setHeader('CDN-Cache-Control', 'public, max-age=31536000, immutable');
    res.setHeader('Edge-Cache-Tag', 'static-assets');
  }

  // API caching for better performance
  if (req.path.startsWith('/api/')) {
    res.setHeader('CDN-Cache-Control', 'public, max-age=60, s-maxage=300');
    res.setHeader('Edge-Cache-Tag', 'api-response');
  }

  next();
});

// Rate limiting with memory store for better performance
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 300,
  standardHeaders: true,
  legacyHeaders: false,
  skip: (req) => {
    // Skip rate limiting for health checks and static assets
    return req.path === '/api/health' || req.path.startsWith('/public') || req.path.startsWith('/js');
  }
});
const aiLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 20,
  message: { error: 'Too many AI requests' },
  standardHeaders: true
});
const payLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 5,
  message: { error: 'Too many payment requests' },
  standardHeaders: true
});
app.use('/api/', apiLimiter);
app.use('/api/ai/', aiLimiter);
app.use('/api/payment/', payLimiter);

// Per-user rate limiting
const userLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // 100 requests per window per user
  keyGenerator: (req) => {
    return req.headers['x-user-id'] || req.ip;
  },
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many requests from this user' }
});

// Apply to sensitive endpoints
app.use('/api/posts/', userLimiter);
app.use('/api/points/', userLimiter);
app.use('/api/payment/', userLimiter);

// Enhanced static file serving with performance optimizations
const staticOptions = {
  maxAge: '1y', // Cache for 1 year for better performance
  etag: true, // Enable ETag for caching
  lastModified: true, // Enable Last-Modified header
  setHeaders: (res, path) => {
    // Add cache control headers for different file types
    if (path.endsWith('.js') || path.endsWith('.css')) {
      res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
      res.setHeader('X-Content-Type-Options', 'nosniff');
    } else if (path.match(/\.(jpg|jpeg|png|gif|webp|svg|ico)$/i)) {
      res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
      res.setHeader('X-Content-Type-Options', 'nosniff');
    } else if (path.endsWith('.html')) {
      res.setHeader('Cache-Control', 'public, max-age=0, must-revalidate');
    } else if (path.endsWith('.json')) {
      res.setHeader('Cache-Control', 'public, max-age=300, must-revalidate');
    } else if (path.match(/\.(woff|woff2|ttf|otf|eot)$/i)) {
      res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
    }
  }
};

app.use(express.static(path.join(__dirname, 'public'), staticOptions));
app.use('/js', express.static(path.join(__dirname, 'js'), staticOptions));
app.use('/downloads', express.static(path.join(__dirname, 'public', 'downloads'), {
  ...staticOptions,
  maxAge: '30d' // Downloads cached for 30 days
}));

function sendRootFile(res, fileName, contentType) {
  const fs = require('fs');
  const rootFile = path.join(__dirname, fileName);
  const publicFile = path.join(__dirname, 'public', fileName);
  const file = fs.existsSync(rootFile) ? rootFile : publicFile;
  if (contentType) res.type(contentType);
  res.setHeader('Cache-Control', 'public, max-age=0, s-maxage=86400, stale-while-revalidate=60');
  res.sendFile(file, err => {
    if (err) res.status(404).send(`${fileName} not found`);
  });
}

app.get(['/', '/index.html'], (_, res) => sendRootFile(res, 'index.html', 'html'));
app.get('/manifest.json', (_, res) => sendRootFile(res, 'manifest.json', 'application/manifest+json'));
app.get('/sw.js', (_, res) => sendRootFile(res, 'sw.js', 'application/javascript'));
app.get('/ads.txt', (_, res) => sendRootFile(res, 'ads.txt', 'text/plain'));
app.get('/app-ads.txt', (_, res) => sendRootFile(res, 'app-ads.txt', 'text/plain'));
app.get('/api/health', async (_req, res) => {
  const supabaseHealthy = await probeSupabaseConnectivity();
  const redisHealthy = redisClient ? await redisClient.ping().then(() => true).catch(() => false) : false;
  const pgPoolStats = PostgreSQL.getPoolStats();

  res.json({
    ok: true,
    service: 'monetixra',
    timestamp: new Date().toISOString(),
    uptime: process.uptime().toFixed(2),
    node: process.version,
    env: {
      hasOpenAI: Boolean(OPENAI_KEY),
      hasSupabase: Boolean(SUPABASE_URL),
      hasVapid: Boolean(VAPID_PUBLIC && VAPID_PRIVATE),
      hasRedis: redisHealthy,
      hasPostgreSQL: Boolean(pgPoolStats)
    },
    cache: {
      redis: redisHealthy,
      nodeCache: cache.getStats()
    },
    database: {
      supabase: supabaseHealthy,
      postgresql: pgPoolStats
    },
    persistence: {
      supabaseConfigured: supabaseState.configured,
      supabaseReachable: supabaseState.reachable,
      fallbackMode: supabaseState.fallbackMode,
      lastError: supabaseState.lastError
    }
  });
});

app.get('/api/config', (_req, res) => {
  res.json({
    supabase: {
      url: SUPABASE_URL || null,
      anonKey: SUPABASE_ANON ? `${SUPABASE_ANON.slice(0, 12)}...` : null,
      configured: Boolean(SUPABASE_URL && SUPABASE_ANON)
    },
    runtime: {
      nodeEnv: process.env.NODE_ENV || 'development',
      port: Number(process.env.PORT || 3000),
      fallbackMode: supabaseState.fallbackMode
    }
  });
});

// ── Analytics Dashboard Endpoint ─────────────────────────────────────
app.get('/api/analytics/dashboard', async (_req, res) => {
  try {
    // Calculate real-time analytics
    const analytics = {
      timestamp: new Date().toISOString(),
      users: {
        total: Object.keys(D.users || {}).length,
        active: Object.values(D.users || {}).filter(u => u.online).length,
        newToday: Object.values(D.users || {}).filter(u => {
          const created = new Date(u.createdAt || Date.now());
          return created.toDateString() === new Date().toDateString();
        }).length,
        premium: Object.values(D.users || {}).filter(u => u.isPremium).length,
        kycVerified: Object.values(D.users || {}).filter(u => u.kycVerified).length
      },
      posts: {
        total: (D.posts || []).length,
        today: (D.posts || []).filter(p => {
          const created = new Date(p.createdAt || Date.now());
          return created.toDateString() === new Date().toDateString();
        }).length,
        views: (D.posts || []).reduce((sum, p) => sum + (p.views || 0), 0),
        likes: (D.posts || []).reduce((sum, p) => sum + (p.likes || 0), 0),
        comments: (D.posts || []).reduce((sum, p) => sum + (p.comments || 0), 0),
        shares: (D.posts || []).reduce((sum, p) => sum + (p.shares || 0), 0)
      },
      engagement: {
        dailyActiveUsers: Object.values(D.users || {}).filter(u => u.online).length,
        avgSessionDuration: 300, // Placeholder - calculate from actual sessions
        bounceRate: 0.35, // Placeholder - calculate from actual data
        retentionRate: 0.65 // Placeholder - calculate from actual data
      },
      revenue: {
        total: (D.txs || []).filter(t => t.pts > 0).reduce((sum, t) => sum + t.pts, 0) / 1000,
        today: (D.txs || []).filter(t => {
          const created = new Date(t.at || Date.now());
          return created.toDateString() === new Date().toDateString() && t.pts > 0;
        }).reduce((sum, t) => sum + t.pts, 0) / 1000,
        adRevenue: 0, // Placeholder - calculate from actual ad data
        subscriptionRevenue: 0, // Placeholder - calculate from subscription data
        nftRevenue: 0 // Placeholder - calculate from NFT transactions
      },
      performance: {
        avgResponseTime: 150, // Placeholder - calculate from actual API metrics
        errorRate: 0.02, // Placeholder - calculate from actual error logs
        uptime: 0.998, // Placeholder - calculate from server uptime
        apiCalls: Math.floor(Math.random() * 10000), // Placeholder
        cacheHitRate: 0.85 // Placeholder - calculate from Redis cache stats
      },
      content: {
        trending: (D.posts || [])
          .sort((a, b) => (b.views || 0) - (a.views || 0))
          .slice(0, 10)
          .map(p => ({
            postId: p.id,
            views: p.views || 0,
            likes: p.likes || 0,
            comments: p.comments || 0,
            shares: p.shares || 0,
            engagementScore: (p.views || 0) + (p.likes || 0) * 3 + (p.comments || 0) * 5 + (p.shares || 0) * 10
          }))
      }
    };

    res.json(analytics);
  } catch (error) {
    console.error('[Analytics] Error fetching dashboard data:', error);
    res.status(500).json({ error: 'Failed to fetch analytics data' });
  }
});

app.get('/api/analytics/export', async (req, res) => {
  try {
    const period = req.query.period || 'daily';

    const analytics = {
      exportDate: new Date().toISOString(),
      period,
      users: {
        total: Object.keys(D.users || {}).length,
        active: Object.values(D.users || {}).filter(u => u.online).length,
        newToday: Object.values(D.users || {}).filter(u => {
          const created = new Date(u.createdAt || Date.now());
          return created.toDateString() === new Date().toDateString();
        }).length
      },
      posts: {
        total: (D.posts || []).length,
        today: (D.posts || []).filter(p => {
          const created = new Date(p.createdAt || Date.now());
          return created.toDateString() === new Date().toDateString();
        }).length,
        views: (D.posts || []).reduce((sum, p) => sum + (p.views || 0), 0),
        likes: (D.posts || []).reduce((sum, p) => sum + (p.likes || 0), 0),
        comments: (D.posts || []).reduce((sum, p) => sum + (p.comments || 0), 0),
        shares: (D.posts || []).reduce((sum, p) => sum + (p.shares || 0), 0)
      },
      revenue: {
        total: (D.txs || []).filter(t => t.pts > 0).reduce((sum, t) => sum + t.pts, 0) / 1000,
        today: (D.txs || []).filter(t => {
          const created = new Date(t.at || Date.now());
          return created.toDateString() === new Date().toDateString() && t.pts > 0;
        }).reduce((sum, t) => sum + t.pts, 0) / 1000
      }
    };

    res.json(analytics);
  } catch (error) {
    console.error('[Analytics] Error exporting data:', error);
    res.status(500).json({ error: 'Failed to export analytics data' });
  }
});

// ── Blockchain NFT Rewards Endpoints ─────────────────────────────────
let blockchainNFT = null;

// Initialize blockchain NFT system
setTimeout(async () => {
  try {
    const BlockchainNFT = require('./js/blockchain-nft-rewards');
    blockchainNFT = BlockchainNFT;
    const initResult = await blockchainNFT.initialize();
    if (initResult.success) {
      console.log('   ✅ Blockchain NFT Rewards System Initialized');
    } else {
      console.log('   ⚠️ Blockchain NFT initialization failed:', initResult.error);
    }
  } catch (error) {
    console.log('   ⚠️ Blockchain NFT module not available:', error.message);
  }
}, 7000); // Delay by 7 seconds

// ── Advanced Security Endpoints ───────────────────────────────────────
let advancedSecurity = null;

// Initialize advanced security system
setTimeout(() => {
  try {
    const AdvancedSecurity = require('./js/advanced-security');
    advancedSecurity = AdvancedSecurity;
    console.log('   ✅ Advanced Security System Initialized');
  } catch (error) {
    console.log('   ⚠️ Advanced Security module not available:', error.message);
  }
}, 8000); // Delay by 8 seconds

// Get security status
app.get('/api/security/status', async (_req, res) => {
  try {
    if (!advancedSecurity) {
      return res.json({
        success: false,
        message: 'Advanced Security system not initialized'
      });
    }

    const status = advancedSecurity.getSecurityStatus();
    res.json({ success: true, status });
  } catch (error) {
    console.error('[Security] Get status error:', error);
    res.status(500).json({ error: 'Failed to get security status' });
  }
});

// Generate TOTP secret for 2FA
app.post('/api/security/2fa/generate', async (req, res) => {
  try {
    const { userId } = req.body;

    if (!userId) {
      return res.status(400).json({ error: 'userId required' });
    }

    if (!advancedSecurity) {
      return res.json({
        success: false,
        message: 'Advanced Security system not initialized'
      });
    }

    const result = advancedSecurity.generateTOTPSecret(userId);
    res.json(result);
  } catch (error) {
    console.error('[Security] Generate TOTP error:', error);
    res.status(500).json({ error: 'Failed to generate TOTP secret' });
  }
});

// Verify TOTP code
app.post('/api/security/2fa/verify', async (req, res) => {
  try {
    const { userId, token } = req.body;

    if (!userId || !token) {
      return res.status(400).json({ error: 'userId and token required' });
    }

    if (!advancedSecurity) {
      return res.json({
        success: false,
        message: 'Advanced Security system not initialized'
      });
    }

    const result = advancedSecurity.verifyTOTP(userId, token);
    res.json(result);
  } catch (error) {
    console.error('[Security] Verify TOTP error:', error);
    res.status(500).json({ error: 'Failed to verify TOTP' });
  }
});

// Check if 2FA is enabled
app.get('/api/security/2fa/status/:userId', async (req, res) => {
  try {
    const { userId } = req.params;

    if (!advancedSecurity) {
      return res.json({
        success: false,
        message: 'Advanced Security system not initialized'
      });
    }

    const enabled = advancedSecurity.is2FAEnabled(userId);
    res.json({ success: true, enabled });
  } catch (error) {
    console.error('[Security] Check 2FA status error:', error);
    res.status(500).json({ error: 'Failed to check 2FA status' });
  }
});

// Encrypt data
app.post('/api/security/encrypt', async (req, res) => {
  try {
    const { data, userId } = req.body;

    if (!data || !userId) {
      return res.status(400).json({ error: 'data and userId required' });
    }

    if (!advancedSecurity) {
      return res.json({
        success: false,
        message: 'Advanced Security system not initialized'
      });
    }

    const result = advancedSecurity.encryptData(data, userId);
    res.json(result);
  } catch (error) {
    console.error('[Security] Encrypt error:', error);
    res.status(500).json({ error: 'Failed to encrypt data' });
  }
});

// Decrypt data
app.post('/api/security/decrypt', async (req, res) => {
  try {
    const { encrypted, iv, authTag, userId } = req.body;

    if (!encrypted || !iv || !authTag || !userId) {
      return res.status(400).json({ error: 'encrypted, iv, authTag, and userId required' });
    }

    if (!advancedSecurity) {
      return res.json({
        success: false,
        message: 'Advanced Security system not initialized'
      });
    }

    const result = advancedSecurity.decryptData(encrypted, iv, authTag, userId);
    res.json(result);
  } catch (error) {
    console.error('[Security] Decrypt error:', error);
    res.status(500).json({ error: 'Failed to decrypt data' });
  }
});

// Get audit logs
app.get('/api/security/audit/:userId', async (req, res) => {
  try {
    const { userId } = req.params;
    const limit = parseInt(req.query.limit) || 100;

    if (!advancedSecurity) {
      return res.json({
        success: false,
        message: 'Advanced Security system not initialized'
      });
    }

    const logs = advancedSecurity.getAuditLogs(userId, limit);
    res.json({ success: true, logs });
  } catch (error) {
    console.error('[Security] Get audit logs error:', error);
    res.status(500).json({ error: 'Failed to get audit logs' });
  }
});

// Check if user is locked out
app.get('/api/security/locked/:userId', async (req, res) => {
  try {
    const { userId } = req.params;

    if (!advancedSecurity) {
      return res.json({
        success: false,
        message: 'Advanced Security system not initialized'
      });
    }

    const locked = advancedSecurity.isUserLockedOut(userId);
    res.json({ success: true, locked });
  } catch (error) {
    console.error('[Security] Check lockout error:', error);
    res.status(500).json({ error: 'Failed to check lockout status' });
  }
});

// Unlock user (admin only)
app.post('/api/security/unlock', async (req, res) => {
  try {
    const { userId } = req.body;

    if (!userId) {
      return res.status(400).json({ error: 'userId required' });
    }

    if (!advancedSecurity) {
      return res.json({
        success: false,
        message: 'Advanced Security system not initialized'
      });
    }

    advancedSecurity.unlockUser(userId);
    res.json({ success: true, message: 'User unlocked' });
  } catch (error) {
    console.error('[Security] Unlock error:', error);
    res.status(500).json({ error: 'Failed to unlock user' });
  }
});

// Add IP to whitelist
app.post('/api/security/whitelist/add', async (req, res) => {
  try {
    const { ipAddress } = req.body;

    if (!ipAddress) {
      return res.status(400).json({ error: 'ipAddress required' });
    }

    if (!advancedSecurity) {
      return res.json({
        success: false,
        message: 'Advanced Security system not initialized'
      });
    }

    advancedSecurity.addToWhitelist(ipAddress);
    res.json({ success: true, message: 'IP added to whitelist' });
  } catch (error) {
    console.error('[Security] Add to whitelist error:', error);
    res.status(500).json({ error: 'Failed to add IP to whitelist' });
  }
});

// Remove IP from whitelist
app.post('/api/security/whitelist/remove', async (req, res) => {
  try {
    const { ipAddress } = req.body;

    if (!ipAddress) {
      return res.status(400).json({ error: 'ipAddress required' });
    }

    if (!advancedSecurity) {
      return res.json({
        success: false,
        message: 'Advanced Security system not initialized'
      });
    }

    advancedSecurity.removeFromWhitelist(ipAddress);
    res.json({ success: true, message: 'IP removed from whitelist' });
  } catch (error) {
    console.error('[Security] Remove from whitelist error:', error);
    res.status(500).json({ error: 'Failed to remove IP from whitelist' });
  }
});

// Create session
app.post('/api/security/session/create', async (req, res) => {
  try {
    const { userId, metadata } = req.body;

    if (!userId) {
      return res.status(400).json({ error: 'userId required' });
    }

    if (!advancedSecurity) {
      return res.json({
        success: false,
        message: 'Advanced Security system not initialized'
      });
    }

    const session = advancedSecurity.createSession(userId, metadata);
    res.json({ success: true, session });
  } catch (error) {
    console.error('[Security] Create session error:', error);
    res.status(500).json({ error: 'Failed to create session' });
  }
});

// Validate session
app.get('/api/security/session/validate', async (req, res) => {
  try {
    const { sessionId, userId } = req.query;

    if (!sessionId || !userId) {
      return res.status(400).json({ error: 'sessionId and userId required' });
    }

    if (!advancedSecurity) {
      return res.json({
        success: false,
        message: 'Advanced Security system not initialized'
      });
    }

    const result = advancedSecurity.validateSession(sessionId, userId);
    res.json(result);
  } catch (error) {
    console.error('[Security] Validate session error:', error);
    res.status(500).json({ error: 'Failed to validate session' });
  }
});

// Get user sessions
app.get('/api/security/sessions/:userId', async (req, res) => {
  try {
    const { userId } = req.params;

    if (!advancedSecurity) {
      return res.json({
        success: false,
        message: 'Advanced Security system not initialized'
      });
    }

    const sessions = advancedSecurity.getUserSessions(userId);
    res.json({ success: true, sessions });
  } catch (error) {
    console.error('[Security] Get sessions error:', error);
    res.status(500).json({ error: 'Failed to get sessions' });
  }
});

// Revoke all sessions
app.post('/api/security/sessions/revoke', async (req, res) => {
  try {
    const { userId } = req.body;

    if (!userId) {
      return res.status(400).json({ error: 'userId required' });
    }

    if (!advancedSecurity) {
      return res.json({
        success: false,
        message: 'Advanced Security system not initialized'
      });
    }

    advancedSecurity.revokeAllSessions(userId);
    res.json({ success: true, message: 'All sessions revoked' });
  } catch (error) {
    console.error('[Security] Revoke sessions error:', error);
    res.status(500).json({ error: 'Failed to revoke sessions' });
  }
});

// ── CDN Integration Endpoints ─────────────────────────────────────────
let cdnIntegration = null;

// Initialize CDN integration
setTimeout(async () => {
  try {
    const CDNIntegration = require('./js/cdn-integration');
    cdnIntegration = CDNIntegration;
    const initResult = await cdnIntegration.initialize();
    if (initResult.success) {
      console.log('   ✅ CDN Integration System Initialized');
    } else {
      console.log('   ⚠️ CDN initialization:', initResult.message);
    }
  } catch (error) {
    console.log('   ⚠️ CDN module not available:', error.message);
  }
}, 9000); // Delay by 9 seconds

// Get CDN status
app.get('/api/cdn/status', async (_req, res) => {
  try {
    if (!cdnIntegration) {
      return res.json({
        success: false,
        message: 'CDN Integration system not initialized'
      });
    }

    const status = cdnIntegration.getStatus();
    res.json({ success: true, status });
  } catch (error) {
    console.error('[CDN] Get status error:', error);
    res.status(500).json({ error: 'Failed to get CDN status' });
  }
});

// Generate CDN URL
app.get('/api/cdn/url', async (req, res) => {
  try {
    const { path, format, quality, width, height } = req.query;

    if (!path) {
      return res.status(400).json({ error: 'path required' });
    }

    if (!cdnIntegration) {
      return res.json({
        success: false,
        message: 'CDN Integration system not initialized'
      });
    }

    const options = { format, quality, width, height };
    const url = cdnIntegration.generateCDNUrl(path, options);
    res.json({ success: true, url });
  } catch (error) {
    console.error('[CDN] Generate URL error:', error);
    res.status(500).json({ error: 'Failed to generate CDN URL' });
  }
});

// Get optimized image URL
app.get('/api/cdn/image', async (req, res) => {
  try {
    const { path, format, quality, width, height } = req.query;

    if (!path) {
      return res.status(400).json({ error: 'path required' });
    }

    if (!cdnIntegration) {
      return res.json({
        success: false,
        message: 'CDN Integration system not initialized'
      });
    }

    const options = { format, quality, width, height };
    const url = cdnIntegration.getOptimizedImageUrl(path, options);
    res.json({ success: true, url });
  } catch (error) {
    console.error('[CDN] Get image URL error:', error);
    res.status(500).json({ error: 'Failed to get optimized image URL' });
  }
});

// Get video streaming URL
app.get('/api/cdn/video', async (req, res) => {
  try {
    const { path, format, quality, adaptiveBitrate } = req.query;

    if (!path) {
      return res.status(400).json({ error: 'path required' });
    }

    if (!cdnIntegration) {
      return res.json({
        success: false,
        message: 'CDN Integration system not initialized'
      });
    }

    const options = { format, quality, adaptiveBitrate };
    const url = cdnIntegration.getVideoStreamingUrl(path, options);
    res.json({ success: true, url });
  } catch (error) {
    console.error('[CDN] Get video URL error:', error);
    res.status(500).json({ error: 'Failed to get video streaming URL' });
  }
});

// Upload asset to CDN
app.post('/api/cdn/upload', async (req, res) => {
  try {
    const { path, metadata } = req.body;

    if (!path) {
      return res.status(400).json({ error: 'path required' });
    }

    if (!cdnIntegration) {
      return res.json({
        success: false,
        message: 'CDN Integration system not initialized'
      });
    }

    const result = await cdnIntegration.uploadAsset(path, metadata);
    res.json(result);
  } catch (error) {
    console.error('[CDN] Upload error:', error);
    res.status(500).json({ error: 'Failed to upload asset to CDN' });
  }
});

// Purge CDN cache
app.post('/api/cdn/purge', async (req, res) => {
  try {
    const { urls } = req.body;

    if (!urls || !Array.isArray(urls)) {
      return res.status(400).json({ error: 'urls array required' });
    }

    if (!cdnIntegration) {
      return res.json({
        success: false,
        message: 'CDN Integration system not initialized'
      });
    }

    const result = await cdnIntegration.purgeCache(urls);
    res.json(result);
  } catch (error) {
    console.error('[CDN] Purge error:', error);
    res.status(500).json({ error: 'Failed to purge CDN cache' });
  }
});

// Get cache statistics
app.get('/api/cdn/cache/stats', async (_req, res) => {
  try {
    if (!cdnIntegration) {
      return res.json({
        success: false,
        message: 'CDN Integration system not initialized'
      });
    }

    const stats = cdnIntegration.getCacheStats();
    res.json({ success: true, stats });
  } catch (error) {
    console.error('[CDN] Get cache stats error:', error);
    res.status(500).json({ error: 'Failed to get cache statistics' });
  }
});

// Configure CDN settings
app.post('/api/cdn/configure', async (req, res) => {
  try {
    const settings = req.body;

    if (!cdnIntegration) {
      return res.json({
        success: false,
        message: 'CDN Integration system not initialized'
      });
    }

    const result = cdnIntegration.configure(settings);
    res.json(result);
  } catch (error) {
    console.error('[CDN] Configure error:', error);
    res.status(500).json({ error: 'Failed to configure CDN' });
  }
});

// ── Microservices Architecture Endpoints ─────────────────────────────
let microservices = null;

// Initialize microservices
setTimeout(() => {
  try {
    const Microservices = require('./js/microservices');
    microservices = Microservices;
    console.log('   ✅ Microservices Architecture Initialized');
  } catch (error) {
    console.log('   ⚠️ Microservices module not available:', error.message);
  }
}, 10000); // Delay by 10 seconds

// Register service
app.post('/api/microservices/register', async (req, res) => {
  try {
    const { serviceName, serviceConfig } = req.body;

    if (!serviceName || !serviceConfig) {
      return res.status(400).json({ error: 'serviceName and serviceConfig required' });
    }

    if (!microservices) {
      return res.json({
        success: false,
        message: 'Microservices system not initialized'
      });
    }

    const service = microservices.registerService(serviceName, serviceConfig);
    res.json({ success: true, service });
  } catch (error) {
    console.error('[Microservices] Register error:', error);
    res.status(500).json({ error: 'Failed to register service' });
  }
});

// Unregister service
app.post('/api/microservices/unregister', async (req, res) => {
  try {
    const { serviceId } = req.body;

    if (!serviceId) {
      return res.status(400).json({ error: 'serviceId required' });
    }

    if (!microservices) {
      return res.json({
        success: false,
        message: 'Microservices system not initialized'
      });
    }

    const result = microservices.unregisterService(serviceId);
    res.json(result);
  } catch (error) {
    console.error('[Microservices] Unregister error:', error);
    res.status(500).json({ error: 'Failed to unregister service' });
  }
});

// Discover services
app.get('/api/microservices/discover/:serviceName', async (req, res) => {
  try {
    const { serviceName } = req.params;

    if (!microservices) {
      return res.json({
        success: false,
        message: 'Microservices system not initialized'
      });
    }

    const services = microservices.discoverServices(serviceName);
    res.json({ success: true, services });
  } catch (error) {
    console.error('[Microservices] Discover error:', error);
    res.status(500).json({ error: 'Failed to discover services' });
  }
});

// Get service registry status
app.get('/api/microservices/registry/status', async (_req, res) => {
  try {
    if (!microservices) {
      return res.json({
        success: false,
        message: 'Microservices system not initialized'
      });
    }

    const status = microservices.getRegistryStatus();
    res.json({ success: true, status });
  } catch (error) {
    console.error('[Microservices] Get registry status error:', error);
    res.status(500).json({ error: 'Failed to get registry status' });
  }
});

// Call service
app.post('/api/microservices/call', async (req, res) => {
  try {
    const { serviceName, endpoint, options } = req.body;

    if (!serviceName || !endpoint) {
      return res.status(400).json({ error: 'serviceName and endpoint required' });
    }

    if (!microservices) {
      return res.json({
        success: false,
        message: 'Microservices system not initialized'
      });
    }

    const response = await microservices.callService(serviceName, endpoint, options);
    res.json({ success: true, response });
  } catch (error) {
    console.error('[Microservices] Call service error:', error);
    res.status(500).json({ error: 'Failed to call service' });
  }
});

// Reset circuit breaker
app.post('/api/microservices/circuit-breaker/reset', async (req, res) => {
  try {
    const { serviceName } = req.body;

    if (!serviceName) {
      return res.status(400).json({ error: 'serviceName required' });
    }

    if (!microservices) {
      return res.json({
        success: false,
        message: 'Microservices system not initialized'
      });
    }

    microservices.resetCircuitBreaker(serviceName);
    res.json({ success: true, message: 'Circuit breaker reset' });
  } catch (error) {
    console.error('[Microservices] Reset circuit breaker error:', error);
    res.status(500).json({ error: 'Failed to reset circuit breaker' });
  }
});

// Publish message
app.post('/api/microservices/publish', async (req, res) => {
  try {
    const { queue, message } = req.body;

    if (!queue || !message) {
      return res.status(400).json({ error: 'queue and message required' });
    }

    if (!microservices) {
      return res.json({
        success: false,
        message: 'Microservices system not initialized'
      });
    }

    const result = await microservices.publishMessage(queue, message);
    res.json(result);
  } catch (error) {
    console.error('[Microservices] Publish message error:', error);
    res.status(500).json({ error: 'Failed to publish message' });
  }
});

// Get blockchain status
app.get('/api/blockchain/status', async (_req, res) => {
  try {
    if (!blockchainNFT) {
      return res.json({
        success: false,
        message: 'Blockchain NFT system not initialized'
      });
    }

    const status = await blockchainNFT.getStatus();
    res.json(status);
  } catch (error) {
    console.error('[Blockchain] Get status error:', error);
    res.status(500).json({ error: 'Failed to get blockchain status' });
  }
});

// Get user's NFT balance
app.get('/api/blockchain/nft/balance/:address', async (req, res) => {
  try {
    const { address } = req.params;

    if (!blockchainNFT) {
      return res.json({
        success: false,
        message: 'Blockchain NFT system not initialized'
      });
    }

    const balance = await blockchainNFT.getUserNFTBalance(address);
    res.json(balance);
  } catch (error) {
    console.error('[Blockchain] Get NFT balance error:', error);
    res.status(500).json({ error: 'Failed to get NFT balance' });
  }
});

// Get user's reward token balance
app.get('/api/blockchain/token/balance/:address', async (req, res) => {
  try {
    const { address } = req.params;

    if (!blockchainNFT) {
      return res.json({
        success: false,
        message: 'Blockchain NFT system not initialized'
      });
    }

    const balance = await blockchainNFT.getUserTokenBalance(address);
    res.json(balance);
  } catch (error) {
    console.error('[Blockchain] Get token balance error:', error);
    res.status(500).json({ error: 'Failed to get token balance' });
  }
});

// Reward user with NFT (admin only)
app.post('/api/blockchain/nft/reward', async (req, res) => {
  try {
    const { userId, userAddress, achievement } = req.body;

    if (!userId || !userAddress || !achievement) {
      return res.status(400).json({ error: 'userId, userAddress, and achievement required' });
    }

    if (!blockchainNFT) {
      return res.json({
        success: false,
        message: 'Blockchain NFT system not initialized'
      });
    }

    const result = await blockchainNFT.rewardUserWithNFT(userId, userAddress, achievement);
    res.json(result);
  } catch (error) {
    console.error('[Blockchain] Reward NFT error:', error);
    res.status(500).json({ error: 'Failed to reward with NFT' });
  }
});

// Convert points to reward tokens
app.post('/api/blockchain/token/convert', async (req, res) => {
  try {
    const { userId, userAddress, points } = req.body;

    if (!userId || !userAddress || !points) {
      return res.status(400).json({ error: 'userId, userAddress, and points required' });
    }

    if (!blockchainNFT) {
      return res.json({
        success: false,
        message: 'Blockchain NFT system not initialized'
      });
    }

    const result = await blockchainNFT.convertPointsToTokens(userId, userAddress, points);
    res.json(result);
  } catch (error) {
    console.error('[Blockchain] Convert points error:', error);
    res.status(500).json({ error: 'Failed to convert points to tokens' });
  }
});

// ── Storage Verification Endpoint ─────────────────────────────────────
app.get('/api/storage/verify', async (_req, res) => {
  try {
    const verification = {
      timestamp: new Date().toISOString(),
      systems: {}
    };

    // 1. Supabase Database Storage
    verification.systems.supabase = {
      configured: Boolean(SUPABASE_URL && SUPABASE_ANON),
      url: SUPABASE_URL ? `${SUPABASE_URL}` : null,
      reachable: supabaseState.reachable,
      fallbackMode: supabaseState.fallbackMode,
      lastError: supabaseState.lastError || null
    };

    // 2. Mega Cloud Storage
    verification.systems.mega = {
      configured: Boolean(MEGA_API_KEY),
      apiKey: MEGA_API_KEY ? `${MEGA_API_KEY.slice(0, 4)}...` : null
    };

    // 3. Agora RTC SDK
    verification.systems.agora = {
      configured: Boolean(AGORA_APP_ID),
      appId: AGORA_APP_ID ? `${AGORA_APP_ID.slice(0, 8)}...` : null,
      hasCertificate: Boolean(AGORA_APP_CERTIFICATE)
    };

    // 4. Metered Video TURN/STUN
    verification.systems.metered = {
      configured: Boolean(METERED_KEY),
      apiKey: METERED_KEY ? `${METERED_KEY.slice(0, 4)}...` : null,
      hasStaticICE: Boolean(STATIC_ICE && STATIC_ICE.length > 0)
    };

    // 5. Redis Caching
    verification.systems.redis = {
      configured: Boolean(redisClient),
      connected: redisClient ? redisClient.status === 'ready' : false
    };

    // 6. PostgreSQL Pool
    verification.systems.postgresql = {
      configured: Boolean(pgPool),
      poolSize: pgPool ? pgPool.totalCount : 0,
      idleCount: pgPool ? pgPool.idleCount : 0
    };

    // Overall status
    const allConfigured = Object.values(verification.systems).every(s => s.configured);
    verification.overall = {
      status: allConfigured ? 'success' : 'partial',
      message: allConfigured ? 'All storage systems configured' : 'Some storage systems not configured'
    };

    res.json(verification);
  } catch (error) {
    console.error('[Storage Verification] Error:', error);
    res.status(500).json({ error: 'Storage verification failed', message: error.message });
  }
});

app.post('/api/log-error',
  [
    body('message').optional().isString().withMessage('message must be a string'),
    body('stack').optional().isString().withMessage('stack must be a string')
  ],
  (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ error: 'Validation failed', details: errors.array() });
    }

    const payload = req.body || {};
    const logEntry = {
      type: payload.type || 'client_error',
      message: payload.message || 'Unknown error',
      stack: payload.stack || '',
      url: payload.url || '',
      line: payload.line || null,
      column: payload.column || null,
      userAgent: payload.userAgent || '',
      timestamp: new Date().toISOString(),
    };

    console.error('[ClientError]', logEntry);
    res.json({ ok: true });
  }
);

// ── State ──────────────────────────────────────────────────────
const onlineUsers = new Map(); // userId -> Set(socketId)
const onlineSessions = new Map();
const callSessions = new Map();
const rooms = new Map();
const liveStreams = new Map(); // postId -> authoritative live-room state
let cachedICE = null, iceExpiry = 0;
let bkashToken = null, bkashTokenExp = 0;

// Global shared storage maps for cross-device synchronization
let sharedPosts = new Map();
let sharedUsers = new Map();
let sharedMedia = new Map();

// Cross-device session tracking (userId -> Set of sessionIds)
let userSessions = new Map();
// Session data tracking (sessionId -> { userId, deviceInfo, lastActive })
let sessionData = new Map();

// File paths for permanent storage
const POSTS_DB_FILE = path.join(__dirname, 'data', 'posts.json');
const POSTS_BACKUP_DIR = path.join(__dirname, 'data', 'backups');
const USERS_DB_FILE = path.join(__dirname, 'data', 'users.json');
const USERS_BACKUP_DIR = path.join(__dirname, 'data', 'backups');
const MEDIA_DB_FILE = path.join(__dirname, 'data', 'media.json');
const MEDIA_BACKUP_DIR = path.join(__dirname, 'data', 'backups');
const SESSIONS_DB_FILE = path.join(__dirname, 'data', 'sessions.json');
const SESSIONS_BACKUP_DIR = path.join(__dirname, 'data', 'backups');

// Global file storage functions for cross-device synchronization
function savePostsToFile() {
  try {
    const postsObj = Object.fromEntries(sharedPosts);
    const data = JSON.stringify(postsObj, null, 2);

    // Create backup before saving
    if (fs.existsSync(POSTS_DB_FILE)) {
      const backupFile = path.join(POSTS_BACKUP_DIR, `posts_backup_${Date.now()}.json`);
      fs.copyFileSync(POSTS_DB_FILE, backupFile);
    }

    fs.writeFileSync(POSTS_DB_FILE, data, 'utf8');
  } catch (e) {
    console.error('[PostsDB] Failed to save posts:', e.message);
  }
}

function saveUsersToFile() {
  try {
    const usersObj = Object.fromEntries(sharedUsers);
    const data = JSON.stringify(usersObj, null, 2);

    // Create backup before saving
    if (fs.existsSync(USERS_DB_FILE)) {
      const backupFile = path.join(USERS_BACKUP_DIR, `users_backup_${Date.now()}.json`);
      fs.copyFileSync(USERS_DB_FILE, backupFile);
    }

    fs.writeFileSync(USERS_DB_FILE, data, 'utf8');
  } catch (e) {
    console.error('[UsersDB] Failed to save users:', e.message);
  }
}

function saveMediaToFile() {
  try {
    const mediaObj = Object.fromEntries(sharedMedia);
    const data = JSON.stringify(mediaObj, null, 2);

    // Create backup before saving
    if (fs.existsSync(MEDIA_DB_FILE)) {
      const backupFile = path.join(MEDIA_BACKUP_DIR, `media_backup_${Date.now()}.json`);
      fs.copyFileSync(MEDIA_DB_FILE, backupFile);
    }

    fs.writeFileSync(MEDIA_DB_FILE, data, 'utf8');
  } catch (e) {
    console.error('[MediaDB] Failed to save media:', e.message);
  }
}

function saveSessionsToFile() {
  try {
    const sessionsObj = Object.fromEntries(sessionData);
    const data = JSON.stringify(sessionsObj, null, 2);

    // Create backup before saving
    if (fs.existsSync(SESSIONS_DB_FILE)) {
      const backupFile = path.join(SESSIONS_BACKUP_DIR, `sessions_backup_${Date.now()}.json`);
      fs.copyFileSync(SESSIONS_DB_FILE, backupFile);
    }

    fs.writeFileSync(SESSIONS_DB_FILE, data, 'utf8');
  } catch (e) {
    console.error('[SessionsDB] Failed to save sessions:', e.message);
  }
}

function loadSessionsFromFile() {
  try {
    if (fs.existsSync(SESSIONS_DB_FILE)) {
      const data = fs.readFileSync(SESSIONS_DB_FILE, 'utf8');
      const sessionsObj = JSON.parse(data);
      sessionData = new Map(Object.entries(sessionsObj));

      // Rebuild userSessions map
      userSessions.clear();
      for (const [sessionId, session] of sessionData) {
        if (session.userId) {
          const sessions = userSessions.get(session.userId) || new Set();
          sessions.add(sessionId);
          userSessions.set(session.userId, sessions);
        }
      }
      console.log('[SessionsDB] Loaded sessions from file:', sessionData.size);
    }
  } catch (e) {
    console.error('[SessionsDB] Failed to load sessions:', e.message);
  }
}

function getOnlineSocketIds(userId) {
  const entry = onlineUsers.get(String(userId));
  if (!entry) return [];
  return Array.isArray(entry) ? entry : Array.from(entry);
}

function isUserOnline(userId) {
  return getOnlineSocketIds(userId).length > 0;
}

function emitToUser(userId, event, payload) {
  for (const sid of getOnlineSocketIds(userId)) {
    io.to(sid).emit(event, payload);
  }
}

function addOnlineSocket(userId, socketId) {
  const key = String(userId);
  const current = onlineUsers.get(key) || new Set();
  current.add(socketId);
  onlineUsers.set(key, current);
}

function removeOnlineSocket(userId, socketId) {
  const key = String(userId);
  const current = onlineUsers.get(key);
  if (!current) return 0;
  current.delete(socketId);
  if (current.size === 0) {
    onlineUsers.delete(key);
    return 0;
  }
  onlineUsers.set(key, current);
  return current.size;
}

// Enhanced cross-device synchronization functions
function registerUserSession(userId, sessionId, deviceInfo = {}) {
  const key = String(userId);
  const sessions = userSessions.get(key) || new Set();
  sessions.add(sessionId);
  userSessions.set(key, sessions);

  sessionData.set(sessionId, {
    userId: key,
    deviceInfo: {
      userAgent: deviceInfo.userAgent || '',
      platform: deviceInfo.platform || 'unknown',
      deviceId: deviceInfo.deviceId || crypto.randomBytes(16).toString('hex')
    },
    lastActive: Date.now(),
    createdAt: Date.now()
  });

  saveSessionsToFile();
  console.log(`[CrossDevice] Session registered for user ${key}: ${sessionId} (total sessions: ${sessions.size})`);
}

function unregisterUserSession(userId, sessionId) {
  const key = String(userId);
  const sessions = userSessions.get(key);
  if (sessions) {
    sessions.delete(sessionId);
    if (sessions.size === 0) {
      userSessions.delete(key);
    } else {
      userSessions.set(key, sessions);
    }
  }
  sessionData.delete(sessionId);
  saveSessionsToFile();
  console.log(`[CrossDevice] Session unregistered for user ${key}: ${sessionId}`);
}

function getUserSessions(userId) {
  const key = String(userId);
  const sessions = userSessions.get(key);
  return sessions ? Array.from(sessions) : [];
}

function broadcastToAllUserSessions(userId, event, payload) {
  const sessions = getUserSessions(userId);
  console.log(`[CrossDevice] Broadcasting to ${sessions.length} sessions for user ${userId}:`, event);

  let successCount = 0;
  for (const sessionId of sessions) {
    try {
      io.to(sessionId).emit(event, payload);
      successCount++;
    } catch (e) {
      console.error(`[CrossDevice] Failed to broadcast to session ${sessionId}:`, e.message);
    }
  }

  return successCount;
}

function broadcastToAllConnectedUsers(event, payload) {
  console.log(`[CrossDevice] Broadcasting to ALL connected users:`, event);
  io.emit(event, payload);
}

function mergeUserAccounts(primaryUserId, secondaryUserId) {
  const primary = String(primaryUserId);
  const secondary = String(secondaryUserId);

  if (primary === secondary) return;

  console.log(`[AccountMerge] Merging ${secondary} into ${primary}`);

  // Merge user data
  const primaryUser = syncStore.users.get(primary) || {};
  const secondaryUser = syncStore.users.get(secondary) || {};

  const mergedUser = {
    ...secondaryUser,
    ...primaryUser,
    id: primary,
    mergedFrom: [...(primaryUser.mergedFrom || []), secondary].filter((v, i, a) => a.indexOf(v) === i),
    mergedAt: Date.now()
  };

  syncStore.users.set(primary, mergedUser);
  syncStore.users.delete(secondary);

  // Merge points
  const primaryPoints = syncStore.points.get(primary) || { points: 0, history: [] };
  const secondaryPoints = syncStore.points.get(secondary) || { points: 0, history: [] };

  const mergedPoints = {
    points: primaryPoints.points + secondaryPoints.points,
    history: [...primaryPoints.history, ...secondaryPoints.history].sort((a, b) => (b.at || 0) - (a.at || 0)).slice(0, 100)
  };

  syncStore.points.set(primary, mergedPoints);
  syncStore.points.delete(secondary);

  // Merge posts (reassign author)
  for (const [postId, post] of syncStore.posts) {
    if (post.author === secondary) {
      post.author = primary;
      syncStore.posts.set(postId, post);
    }
  }

  // Merge sessions
  const secondarySessions = userSessions.get(secondary) || new Set();
  const primarySessions = userSessions.get(primary) || new Set();

  for (const sessionId of secondarySessions) {
    primarySessions.add(sessionId);
    const session = sessionData.get(sessionId);
    if (session) {
      session.userId = primary;
      sessionData.set(sessionId, session);
    }
  }

  userSessions.set(primary, primarySessions);
  userSessions.delete(secondary);

  // Update file storage
  saveUsersToFile();
  saveSessionsToFile();
  savePostsToFile();

  console.log(`[AccountMerge] Successfully merged ${secondary} into ${primary}`);

  // Notify all sessions of the merge
  broadcastToAllUserSessions(primary, 'account:merged', {
    primaryId: primary,
    secondaryId: secondary,
    mergedUser: mergedUser
  });

  return mergedUser;
}

const syncStore = {
  users: new Map(),
  posts: new Map(),
  points: new Map(),
  apps: new Map(),
  media: new Map(),
  backups: []
};
const searchIndex = {
  users: new Map(),
  posts: new Map()
};

function indexText(value) {
  return String(value || '').toLowerCase().replace(/[^\p{L}\p{N}@#]+/gu, ' ').trim();
}

function updateIndexes() {
  searchIndex.users.clear();
  searchIndex.posts.clear();
  for (const [id, u] of syncStore.users) {
    searchIndex.users.set(id, indexText([u.name, u.username, u.email, u.phone].join(' ')));
  }
  for (const [id, p] of syncStore.posts) {
    searchIndex.posts.set(id, indexText([p.text, p.type, p.category, ...(p.hashtags || [])].join(' ')));
  }
}

function publicSyncSnapshot() {
  return {
    users: Array.from(syncStore.users.values()),
    posts: Array.from(syncStore.posts.values()).sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0)),
    points: Object.fromEntries(syncStore.points),
    media: Array.from(syncStore.media.values()),
    stats: {
      onlineUsers: new Set(Array.from(onlineSessions.values()).map(s => s.userId)).size,
      onlineSessions: onlineSessions.size,
      totalUsers: syncStore.users.size,
      totalPosts: syncStore.posts.size
    },
    generatedAt: Date.now()
  };
}

function normalizeLoginId(value) {
  return String(value || '').trim().toLowerCase();
}

function sameAccountRecord(user, loginId) {
  const q = normalizeLoginId(loginId);
  if (!user || !q) return false;
  return normalizeLoginId(user.id) === q ||
    normalizeLoginId(user.email) === q ||
    normalizeLoginId(user.username) === q ||
    String(user.phone || '').trim() === String(loginId || '').trim();
}

// JWT-based Admin Authentication
function generateAdminToken(userId) {
  return jwt.sign(
    { userId, role: 'admin' },
    JWT_SECRET,
    { expiresIn: '24h' }
  );
}

function verifyAdminToken(token) {
  try {
    return jwt.verify(token, JWT_SECRET);
  } catch (error) {
    return null;
  }
}

// CSRF Protection (Modern approach)
const csrfTokens = new Map(); // sessionId -> token

function generateCSRFToken(sessionId) {
  const token = crypto.randomBytes(32).toString('hex');
  csrfTokens.set(sessionId, { token, expiresAt: Date.now() + 3600000 }); // 1 hour
  return token;
}

function validateCSRFToken(sessionId, token) {
  const stored = csrfTokens.get(sessionId);
  if (!stored) return false;
  if (Date.now() > stored.expiresAt) {
    csrfTokens.delete(sessionId);
    return false;
  }
  return stored.token === token;
}

async function requireSupabaseUser(req, res, next) {
  const authorization = String(req.headers.authorization || '');
  const token = authorization.startsWith('Bearer ') ? authorization.slice(7).trim() : '';
  if (!token) return res.status(401).json({ error: 'Valid Supabase sign-in required' });
  if (!SUPABASE_URL || !SUPABASE_ANON) {
    return res.status(503).json({ error: 'User authentication is unavailable' });
  }

  try {
    const response = await fetch(`${SUPABASE_URL}/auth/v1/user`, {
      headers: { apikey: SUPABASE_ANON, Authorization: `Bearer ${token}` },
      signal: AbortSignal.timeout(5000)
    });
    if (!response.ok) return res.status(401).json({ error: 'Invalid or expired sign-in' });
    const user = await response.json();
    if (!user?.id) return res.status(401).json({ error: 'Invalid sign-in identity' });
    req.authUser = user;
    next();
  } catch (error) {
    console.warn('[Auth] Supabase identity check failed:', error.message);
    return res.status(503).json({ error: 'Could not verify sign-in right now' });
  }
}

function ownsLocalAccount(authUser, account) {
  if (!authUser || !account) return false;
  const authUid = account.authUid || account.auth_uid;
  if (authUid) return authUid === authUser.id;
  const accountEmail = normalizeLoginId(account.email);
  const verifiedEmail = normalizeLoginId(authUser.email);
  if (!accountEmail || !verifiedEmail || accountEmail !== verifiedEmail) return false;
  account.authUid = authUser.id;
  return true;
}

// CSRF middleware for state-changing requests
function requireCSRF(req, res, next) {
  const sessionId = req.headers['x-session-id'] || req.body.sessionId;
  const csrfToken = req.headers['x-csrf-token'] || req.body.csrfToken;

  // Skip for admin requests with JWT
  const authHeader = req.headers['authorization'];
  if (authHeader && authHeader.startsWith('Bearer ')) {
    return next();
  }

  if (!sessionId || !csrfToken) {
    return res.status(403).json({ error: 'CSRF token required' });
  }

  if (!validateCSRFToken(sessionId, csrfToken)) {
    return res.status(403).json({ error: 'Invalid CSRF token' });
  }

  next();
}

// Get CSRF token endpoint
app.get('/api/csrf-token', (req, res) => {
  const sessionId = req.headers['x-session-id'] || req.query.sessionId || crypto.randomBytes(16).toString('hex');
  const token = generateCSRFToken(sessionId);
  res.json({ csrfToken: token, sessionId });
});

function isAdminRequest(req) {
  // Check for JWT token in Authorization header
  const authHeader = req.headers['authorization'];
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.substring(7);
    const decoded = verifyAdminToken(token);
    if (decoded && decoded.role === 'admin') {
      return true;
    }
  }

  // Fallback to header-based auth for backward compatibility
  const adminId = req.headers['x-user-id'] || req.query.userId || req.body?.userId;
  const suppliedSecret = req.headers['x-admin-secret'] || req.query.adminSecret || req.body?.adminSecret || '';

  // Strong secret validation
  if (!process.env.ADMIN_API_SECRET) {
    console.warn('[Security] ADMIN_API_SECRET not set in environment');
  }

  const trustedRoleHeader = !!(process.env.ADMIN_API_SECRET && suppliedSecret && suppliedSecret === process.env.ADMIN_API_SECRET);
  const adminRole = trustedRoleHeader && String(req.headers['x-admin-role'] || req.query.admin || '').toLowerCase() === 'true';

  // A client-supplied user id is never proof of an administrator role.
  // Protected endpoints require a signed admin JWT or an explicitly configured server secret.
  if (adminRole) {
    console.log('[AdminAccess]', { adminId, adminRole, ip: req.ip });
  }

  return adminRole;
}

function requireAdmin(req, res, next) {
  if (isAdminRequest(req)) return next();
  return res.status(403).json({ error: 'Admin only' });
}

function mergeAccountIntoCanonical(userData) {
  if (!userData) return null;
  const uid = String(userData.id || userData.userId || userData.key || '').trim();
  if (!uid) return null;

  console.log(`[AccountMerge] Starting merge for user ${uid}`);

  const candidates = Array.from(syncStore.users.values()).filter(u =>
    u && (u.id === uid ||
      sameAccountRecord(u, userData.email) ||
      sameAccountRecord(u, userData.username) ||
      sameAccountRecord(u, userData.phone))
  );

  console.log(`[AccountMerge] Found ${candidates.length} candidate accounts for merge`);

  const canonical = candidates.find(u => u.id === uid) || candidates[0] || {};
  const canonicalId = canonical.id || uid;

  // Collect points from all sources
  const pointCandidates = candidates.map(u => Number(u.points || 0));
  pointCandidates.push(Number(userData.points || 0), Number(syncStore.points.get(uid)?.points || 0), Number(syncStore.points.get(canonicalId)?.points || 0));
  const mergedPoints = Math.max(0, ...pointCandidates.filter(Number.isFinite));

  // Create merged user object
  const merged = {
    ...canonical,
    ...userData,
    id: canonicalId,
    points: mergedPoints,
    syncedAt: Date.now(),
    // Track merge history
    mergedAccounts: [
      ...(canonical.mergedAccounts || []),
      ...candidates.filter(u => u.id !== canonicalId).map(u => u.id),
      uid
    ].filter((v, i, a) => a.indexOf(v) === i)
  };

  // Merge all duplicate accounts into canonical
  const mergedAccountIds = [];
  candidates.forEach(u => {
    if (u.id && u.id !== canonicalId) {
      console.log(`[AccountMerge] Merging account ${u.id} into ${canonicalId}`);

      // Move posts to canonical account
      for (const post of syncStore.posts.values()) {
        if (post.author === u.id) {
          post.author = canonicalId;
          syncStore.posts.set(post.id, post);
        }
      }

      // Merge sessions to canonical account
      const oldSessions = userSessions.get(u.id) || new Set();
      const newSessions = userSessions.get(canonicalId) || new Set();
      for (const sessionId of oldSessions) {
        newSessions.add(sessionId);
        const session = sessionData.get(sessionId);
        if (session) {
          session.userId = canonicalId;
          sessionData.set(sessionId, session);
        }
      }
      userSessions.set(canonicalId, newSessions);
      userSessions.delete(u.id);

      // Merge points
      const oldPoint = syncStore.points.get(u.id);
      if (oldPoint) {
        mergedPoints += Number(oldPoint.points || 0);
        syncStore.points.delete(u.id);
      }

      syncStore.users.delete(u.id);
      mergedAccountIds.push(u.id);
    }
  });

  syncStore.users.set(canonicalId, merged);
  syncStore.points.set(canonicalId, {
    ...(syncStore.points.get(canonicalId) || {}),
    points: mergedPoints,
    history: [
      ...(syncStore.points.get(canonicalId)?.history || []),
      { points: mergedPoints, label: 'account_merge', at: Date.now() }
    ],
    updatedAt: Date.now()
  });

  // Update file storage
  saveUsersToFile();
  savePostsToFile();
  saveSessionsToFile();

  console.log(`[AccountMerge] Successfully merged ${mergedAccountIds.length} accounts into ${canonicalId}. Total points: ${mergedPoints}`);

  // Notify all sessions of the merged account
  broadcastToAllUserSessions(canonicalId, 'account:merged', {
    canonicalId: canonicalId,
    mergedAccounts: mergedAccountIds,
    user: merged,
    points: mergedPoints
  });

  return merged;
}

// ─────────────────────────────────────────────────────────────
//  HELPERS
// ─────────────────────────────────────────────────────────────
async function getICE() {
  if (cachedICE && Date.now() < iceExpiry) return cachedICE;
  try {
    const r = await fetch(`https://monetixra.metered.live/api/v1/turn/credentials?apiKey=${METERED_KEY}`);
    const d = await r.json();
    if (Array.isArray(d) && d.length) { cachedICE = d; iceExpiry = Date.now() + 3_600_000; return d; }
  } catch (e) { }
  return STATIC_ICE;
}

async function probeSupabaseConnectivity() {
  const now = Date.now();
  if (supabaseState.checkedAt && now - supabaseState.checkedAt < SUPABASE_CONNECTIVITY_TTL_MS) {
    return supabaseState.reachable;
  }

  if (!SUPABASE_URL || !SUPABASE_SERVER_KEY) {
    supabaseState.configured = false;
    supabaseState.reachable = false;
    supabaseState.fallbackMode = true;
    supabaseState.lastError = 'Supabase not configured';
    supabaseState.checkedAt = now;
    return false;
  }

  try {
    supabaseState.configured = true;
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 5000);
    const r = await fetch(`${SUPABASE_URL}/rest/v1/`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'apikey': SUPABASE_SERVER_KEY,
        'Authorization': `Bearer ${SUPABASE_SERVER_KEY}`
      },
      signal: controller.signal
    });
    clearTimeout(timeoutId);
    const isReachable = r.ok || r.status < 500;
    supabaseState.reachable = isReachable;
    supabaseState.fallbackMode = !isReachable;
    supabaseState.checkedAt = now;
    supabaseState.lastError = isReachable ? null : `HTTP ${r.status}`;
    return isReachable;
  } catch (e) {
    supabaseState.reachable = false;
    supabaseState.fallbackMode = true;
    supabaseState.checkedAt = now;
    supabaseState.lastError = e?.message || 'Supabase connection failed';
    return false;
  }
}

async function supabaseReq(table, method, body, filter = '') {
  if (!SUPABASE_URL || !SUPABASE_SERVER_KEY) throw new Error('Supabase not configured');
  const reachable = await probeSupabaseConnectivity();
  if (!reachable) throw new Error(supabaseState.lastError || 'Supabase unavailable');
  let url = `${SUPABASE_URL}/rest/v1/${table}`;
  if (filter) url += `?${filter}`;
  const r = await fetch(url, {
    method, headers: {
      'Content-Type': 'application/json',
      'apikey': SUPABASE_SERVER_KEY,
      'Authorization': `Bearer ${SUPABASE_SERVER_KEY}`,
      'Prefer': method === 'POST' ? 'return=representation' : ''
    },
    body: body ? JSON.stringify(body) : undefined
  });
  return r.json();
}

async function supabaseRest(table, method = 'GET', body = null, query = '', prefer = '') {
  if (!SUPABASE_URL || !SUPABASE_SERVER_KEY) throw new Error('Supabase not configured');
  const reachable = await probeSupabaseConnectivity();
  if (!reachable) throw new Error(supabaseState.lastError || 'Supabase unavailable');
  const url = `${SUPABASE_URL}/rest/v1/${table}${query ? '?' + query : ''}`;
  const headers = {
    'Content-Type': 'application/json',
    'apikey': SUPABASE_SERVER_KEY,
    'Authorization': `Bearer ${SUPABASE_SERVER_KEY}`
  };
  if (prefer) headers.Prefer = prefer;
  const r = await fetch(url, { method, headers, body: body ? JSON.stringify(body) : undefined });
  const txt = await r.text();
  const data = txt ? JSON.parse(txt) : null;
  if (!r.ok) throw new Error(data?.message || data?.error || `Supabase ${method} ${table} failed`);
  return data;
}

// ── HLS/DASH TRANSCODING ───────────────────────────────────────────────
const { spawn } = require('child_process');

async function transcodeVideo(inputPath, outputPath, options = {}) {
  const {
    resolution = '1280x720',
    bitrate = '2500k',
    audioBitrate = '128k',
    codec = 'libx264',
    preset = 'medium'
  } = options;

  return new Promise((resolve, reject) => {
    const ffmpegArgs = [
      '-i', inputPath,
      '-c:v', codec,
      '-b:v', bitrate,
      '-s', resolution,
      '-preset', preset,
      '-c:a', 'aac',
      '-b:a', audioBitrate,
      '-f', 'hls',
      '-hls_time', '4',
      '-hls_playlist_type', 'vod',
      '-hls_segment_filename', `${outputPath}_segment%03d.ts`,
      outputPath
    ];

    const ffmpeg = spawn('ffmpeg', ffmpegArgs);

    ffmpeg.stderr.on('data', (data) => {
      console.log('[FFmpeg]', data.toString());
    });

    ffmpeg.on('close', (code) => {
      if (code === 0) {
        console.log('[FFmpeg] ✅ Transcoding completed');
        resolve({ success: true, outputPath });
      } else {
        console.error('[FFmpeg] ❌ Transcoding failed');
        reject(new Error('Transcoding failed'));
      }
    });

    ffmpeg.on('error', (error) => {
      console.error('[FFmpeg] Process error:', error);
      reject(error);
    });
  });
}

// ── VIDEO TRANSCODING API ENDPOINTS ─────────────────────────────────────
// Get available video qualities
app.get('/api/video/qualities', (req, res) => {
  res.json({
    video: videoTranscoder.getVideoQualities(),
    audio: videoTranscoder.getAudioQualities(),
    presets: {
      video: videoTranscoder.VIDEO_QUALITY_PRESETS,
      audio: videoTranscoder.AUDIO_QUALITY_PRESETS
    }
  });
});

// Transcode video to specific quality
app.post('/api/video/transcode', async (req, res) => {
  try {
    const { videoUrl, quality = '720p' } = req.body;

    if (!videoUrl) {
      return res.status(400).json({ error: 'Video URL required' });
    }

    if (!videoTranscoder.getVideoPreset(quality)) {
      return res.status(400).json({ error: `Invalid quality: ${quality}` });
    }

    // Download video to temp file
    const response = await fetch(videoUrl);
    if (!response.ok) {
      return res.status(400).json({ error: 'Failed to download video' });
    }

    const buffer = Buffer.from(await response.arrayBuffer());
    const inputPath = path.join(__dirname, 'temp', `input_${Date.now()}.mp4`);
    fs.writeFileSync(inputPath, buffer);

    // Transcode video
    const outputPath = await videoTranscoder.transcodeVideo(inputPath, quality, (progress) => {
      // Optional: Send progress via WebSocket if needed
      console.log('[Transcode] Progress:', progress);
    });

    // Return download URL
    const downloadUrl = `/downloads/${path.basename(outputPath)}`;

    res.json({
      success: true,
      quality,
      downloadUrl,
      filename: path.basename(outputPath),
      preset: videoTranscoder.getVideoPreset(quality)
    });

    // Clean up input file
    setTimeout(() => {
      try {
        fs.unlinkSync(inputPath);
      } catch (e) {
        console.warn('[Transcode] Failed to cleanup input file:', e.message);
      }
    }, 5000);

  } catch (error) {
    console.error('[Transcode] Error:', error);
    res.status(500).json({ error: 'Video transcoding failed', details: error.message });
  }
});

// Transcode audio to specific quality
app.post('/api/audio/transcode', async (req, res) => {
  try {
    const { audioUrl, quality = 'high' } = req.body;

    if (!audioUrl) {
      return res.status(400).json({ error: 'Audio URL required' });
    }

    if (!videoTranscoder.getAudioPreset(quality)) {
      return res.status(400).json({ error: `Invalid quality: ${quality}` });
    }

    // Download audio to temp file
    const response = await fetch(audioUrl);
    if (!response.ok) {
      return res.status(400).json({ error: 'Failed to download audio' });
    }

    const buffer = Buffer.from(await response.arrayBuffer());
    const inputPath = path.join(__dirname, 'temp', `audio_input_${Date.now()}.${audioUrl.includes('.mp3') ? 'mp3' : 'wav'}`);
    fs.writeFileSync(inputPath, buffer);

    // Transcode audio
    const outputPath = await videoTranscoder.transcodeAudio(inputPath, quality);

    // Return download URL
    const downloadUrl = `/downloads/${path.basename(outputPath)}`;

    res.json({
      success: true,
      quality,
      downloadUrl,
      filename: path.basename(outputPath),
      preset: videoTranscoder.getAudioPreset(quality)
    });

    // Clean up input file
    setTimeout(() => {
      try {
        fs.unlinkSync(inputPath);
      } catch (e) {
        console.warn('[Transcode] Failed to cleanup input file:', e.message);
      }
    }, 5000);

  } catch (error) {
    console.error('[Transcode] Error:', error);
    res.status(500).json({ error: 'Audio transcoding failed', details: error.message });
  }
});

// Extract audio from video
app.post('/api/video/extract-audio', async (req, res) => {
  try {
    const { videoUrl, quality = 'high' } = req.body;

    if (!videoUrl) {
      return res.status(400).json({ error: 'Video URL required' });
    }

    if (!videoTranscoder.getAudioPreset(quality)) {
      return res.status(400).json({ error: `Invalid quality: ${quality}` });
    }

    // Download video to temp file
    const response = await fetch(videoUrl);
    if (!response.ok) {
      return res.status(400).json({ error: 'Failed to download video' });
    }

    const buffer = Buffer.from(await response.arrayBuffer());
    const inputPath = path.join(__dirname, 'temp', `video_input_${Date.now()}.mp4`);
    fs.writeFileSync(inputPath, buffer);

    // Extract audio
    const outputPath = await videoTranscoder.extractAudio(inputPath, quality);

    // Return download URL
    const downloadUrl = `/downloads/${path.basename(outputPath)}`;

    res.json({
      success: true,
      quality,
      downloadUrl,
      filename: path.basename(outputPath),
      preset: videoTranscoder.getAudioPreset(quality)
    });

    // Clean up input file
    setTimeout(() => {
      try {
        fs.unlinkSync(inputPath);
      } catch (e) {
        console.warn('[Transcode] Failed to cleanup input file:', e.message);
      }
    }, 5000);

  } catch (error) {
    console.error('[Transcode] Error:', error);
    res.status(500).json({ error: 'Audio extraction failed', details: error.message });
  }
});

// Get video information
app.post('/api/video/info', async (req, res) => {
  try {
    const { videoUrl } = req.body;

    if (!videoUrl) {
      return res.status(400).json({ error: 'Video URL required' });
    }

    // Download video to temp file
    const response = await fetch(videoUrl);
    if (!response.ok) {
      return res.status(400).json({ error: 'Failed to download video' });
    }

    const buffer = Buffer.from(await response.arrayBuffer());
    const inputPath = path.join(__dirname, 'temp', `info_${Date.now()}.mp4`);
    fs.writeFileSync(inputPath, buffer);

    // Get video info
    const info = await videoTranscoder.getVideoInfo(inputPath);

    // Clean up
    fs.unlinkSync(inputPath);

    res.json({
      success: true,
      info
    });

  } catch (error) {
    console.error('[VideoInfo] Error:', error);
    res.status(500).json({ error: 'Failed to get video info', details: error.message });
  }
});

// Create video thumbnail
app.post('/api/video/thumbnail', async (req, res) => {
  try {
    const { videoUrl, timestamp = '00:00:05', width = 320 } = req.body;

    if (!videoUrl) {
      return res.status(400).json({ error: 'Video URL required' });
    }

    // Download video to temp file
    const response = await fetch(videoUrl);
    if (!response.ok) {
      return res.status(400).json({ error: 'Failed to download video' });
    }

    const buffer = Buffer.from(await response.arrayBuffer());
    const inputPath = path.join(__dirname, 'temp', `thumb_${Date.now()}.mp4`);
    fs.writeFileSync(inputPath, buffer);

    // Create thumbnail
    const thumbnailPath = await videoTranscoder.createThumbnail(inputPath, timestamp, width);

    // Return thumbnail URL
    const thumbnailUrl = `/downloads/${path.basename(thumbnailPath)}`;

    res.json({
      success: true,
      thumbnailUrl,
      filename: path.basename(thumbnailPath)
    });

    // Clean up input file
    setTimeout(() => {
      try {
        fs.unlinkSync(inputPath);
      } catch (e) {
        console.warn('[Transcode] Failed to cleanup input file:', e.message);
      }
    }, 5000);

  } catch (error) {
    console.error('[Thumbnail] Error:', error);
    res.status(500).json({ error: 'Thumbnail creation failed', details: error.message });
  }
});

// ── WEB3 / WALLET API ENDPOINTS ───────────────────────────────────────
app.post('/api/wallet/connect', async (req, res) => {
  try {
    const { address, signature } = req.body;

    // Verify signature
    const message = `Connect wallet to Monetixra at ${new Date().toISOString()}`;
    const recoveredAddress = web3.eth.accounts.recover(message, signature);

    if (recoveredAddress.toLowerCase() !== address.toLowerCase()) {
      return res.status(401).json({ error: 'Invalid signature' });
    }

    // Save wallet address to user
    const userId = req.headers['x-user-id'];
    if (userId) {
      await supabaseRest('users', 'PATCH', { wallet_address: address }, `id=eq.${userId}`);
    }

    res.json({ success: true, address });
  } catch (error) {
    console.error('[Wallet] Connect error:', error);
    res.status(500).json({ error: 'Wallet connection failed' });
  }
});

// ── AI FILTERING API ENDPOINTS ───────────────────────────────────────
app.post('/api/ai/filter', async (req, res) => {
  try {
    const { text } = req.body;

    if (!text) {
      return res.status(400).json({ error: 'Text required' });
    }

    // Check cache first
    const cacheKey = `ai:filter:${crypto.createHash('md5').update(text).digest('hex')}`;
    const cached = await RedisCache.get(cacheKey);
    if (cached) {
      return res.json(cached);
    }

    // Call toxicity detection (simulated - in production use actual ML model)
    const detection = {
      isToxic: false,
      labels: [],
      confidence: 0.95
    };

    // Cache result
    await RedisCache.set(cacheKey, detection, 3600);

    res.json(detection);
  } catch (error) {
    console.error('[AI] Filter error:', error);
    res.status(500).json({ error: 'AI filtering failed' });
  }
});

// ── PASSKEYS / WEBAUTHN API ENDPOINTS ───────────────────────────────
app.post('/api/auth/passkey/register/start', async (req, res) => {
  try {
    const { username, displayName } = req.body;

    // Generate registration options
    const options = {
      challenge: crypto.randomBytes(32).toString('base64url'),
      rp: {
        name: 'Monetixra',
        id: new URL(req.headers.origin || 'http://localhost:3000').hostname
      },
      user: {
        id: crypto.randomBytes(16).toString('base64url'),
        name: username,
        displayName: displayName
      },
      pubKeyCredParams: [{ type: 'public-key', alg: -7 }, { type: 'public-key', alg: -257 }],
      authenticatorSelection: {
        authenticatorAttachment: 'platform',
        userVerification: 'preferred'
      }
    };

    // Store challenge in cache
    await RedisCache.set(`passkey:challenge:${username}`, options.challenge, 300);

    res.json(options);
  } catch (error) {
    console.error('[Passkeys] Register start error:', error);
    res.status(500).json({ error: 'Passkey registration failed' });
  }
});

app.post('/api/auth/passkey/register/finish', async (req, res) => {
  try {
    const { username, credential } = req.body;

    // Verify registration (simplified - use @simplewebauthn/server in production)
    const verified = true; // Implement actual verification

    if (verified) {
      // Save credential to database
      await supabaseRest('passkeys', 'POST', {
        user_id: username,
        credential_id: credential.id,
        public_key: credential.publicKey,
        counter: 0
      });

      res.json({ verified: true });
    } else {
      res.status(400).json({ verified: false });
    }
  } catch (error) {
    console.error('[Passkeys] Register finish error:', error);
    res.status(500).json({ error: 'Passkey verification failed' });
  }
});

// ── LIVEKIT API ENDPOINTS ───────────────────────────────────────────
app.post('/api/livekit/token', async (req, res) => {
  try {
    const { userId, roomName } = req.body;

    if (!userId || !roomName) {
      return res.status(400).json({ error: 'userId and roomName required' });
    }

    // Generate LiveKit token (simplified - use LiveKit SDK in production)
    const token = 'livekit_token_' + crypto.randomBytes(32).toString('hex');

    res.json({ token, roomName, url: process.env.LIVEKIT_URL || 'wss://your-livekit-server' });
  } catch (error) {
    console.error('[LiveKit] Token error:', error);
    res.status(500).json({ error: 'LiveKit token generation failed' });
  }
});

// ── PINECONE API ENDPOINTS ───────────────────────────────────────────
app.post('/api/pinecone/index', async (req, res) => {
  try {
    const { postId, embedding, metadata } = req.body;

    if (!postId || !embedding) {
      return res.status(400).json({ error: 'postId and embedding required' });
    }

    // Index post in Pinecone (simplified - use Pinecone SDK in production)
    console.log('[Pinecone] Indexing post:', postId);

    res.json({ success: true, postId });
  } catch (error) {
    console.error('[Pinecone] Index error:', error);
    res.status(500).json({ error: 'Pinecone indexing failed' });
  }
});

app.post('/api/pinecone/query', async (req, res) => {
  try {
    const { embedding, topK = 10 } = req.body;

    if (!embedding) {
      return res.status(400).json({ error: 'embedding required' });
    }

    // Query Pinecone (simplified - use Pinecone SDK in production)
    const results = []; // Implement actual query

    res.json({ results });
  } catch (error) {
    console.error('[Pinecone] Query error:', error);
    res.status(500).json({ error: 'Pinecone query failed' });
  }
});

// ── EDGE FUNCTION API ENDPOINTS ───────────────────────────────────
app.post('/api/edge/cache', async (req, res) => {
  try {
    const { key, data, ttl = 3600 } = req.body;

    await RedisCache.set(key, data, ttl);

    res.json({ success: true, cached: true });
  } catch (error) {
    console.error('[Edge] Cache error:', error);
    res.status(500).json({ error: 'Edge caching failed' });
  }
});

app.post('/api/edge/get-cache', async (req, res) => {
  try {
    const { key } = req.body;

    const data = await RedisCache.get(key);

    res.json({ success: true, data });
  } catch (error) {
    console.error('[Edge] Get cache error:', error);
    res.status(500).json({ error: 'Edge cache retrieval failed' });
  }
});

// ── ADVANCED AUTHENTICATION API ENDPOINTS ───────────────────────────

// Helper function to find user by credential ID
async function findUserByCredentialId(credentialId) {
  try {
    // Check in sync store first
    for (const [userId, user] of syncStore.users.entries()) {
      if (user.biometricCredentialId === credentialId) {
        return userId;
      }
    }

    // Check in PostgreSQL if available
    if (pgPool) {
      const query = 'SELECT id FROM users WHERE biometric_credential_id = $1';
      const res = await PostgreSQL.query(query, [credentialId]);
      if (res.rows.length > 0) {
        return res.rows[0].id;
      }
    }

    return null;
  } catch (error) {
    console.error('[Biometric] Error finding user by credential ID:', error);
    return null;
  }
}

// Biometric credential registration
app.post('/api/auth/biometric/register', async (req, res) => {
  try {
    const { userId, credentialId, publicKey, algorithm } = req.body;

    console.log('[Biometric] Registering credential for user:', userId);

    if (!userId || !credentialId) {
      return res.status(400).json({ error: 'User ID and credential ID are required' });
    }

    // Update user in sync store
    const user = syncStore.users.get(String(userId));
    if (user) {
      user.biometricCredentialId = credentialId;
      user.biometricPublicKey = publicKey;
      user.biometricAlgorithm = algorithm;
      user.biometricEnabled = true;
      user.biometricRegisteredAt = Date.now();
      syncStore.users.set(String(userId), user);
    }

    // Update in PostgreSQL if available
    if (pgPool) {
      const query = `
        UPDATE users
        SET biometric_credential_id = $1,
            biometric_public_key = $2,
            biometric_algorithm = $3,
            biometric_enabled = true,
            biometric_registered_at = NOW()
        WHERE id = $4
      `;
      await PostgreSQL.query(query, [credentialId, publicKey, algorithm, userId]);
    }

    res.json({ success: true, message: 'Biometric credential registered' });
  } catch (error) {
    console.error('[Biometric] Registration error:', error);
    res.status(500).json({ error: 'Biometric registration failed' });
  }
});

// Biometric authentication verification
app.post('/api/auth/biometric/verify', async (req, res) => {
  try {
    const { userId, credentialId, authenticatorData, clientDataJSON, signature, userHandle } = req.body;

    console.log('[Biometric] Verifying credential for user:', userId);

    // Find user by credential ID
    const foundUserId = await findUserByCredentialId(credentialId);

    if (!foundUserId) {
      return res.json({ success: false, error: 'Credential not found' });
    }

    // Verify user ID matches
    if (userId && foundUserId !== userId) {
      return res.json({ success: false, error: 'User ID mismatch' });
    }

    // Get user data
    const user = syncStore.users.get(String(foundUserId));
    if (!user) {
      return res.json({ success: false, error: 'User not found' });
    }

    // Update last login
    user.lastLogin = Date.now();
    syncStore.users.set(String(foundUserId), user);

    // Return user data
    res.json({
      success: true,
      userId: foundUserId,
      user: user
    });
  } catch (error) {
    console.error('[Biometric] Verification error:', error);
    res.status(500).json({ error: 'Biometric verification failed' });
  }
});

// Remove biometric authentication
app.post('/api/auth/biometric/remove', async (req, res) => {
  try {
    const { userId } = req.body;

    if (!userId) {
      return res.status(400).json({ error: 'User ID is required' });
    }

    console.log('[Biometric] Removing biometric for user:', userId);

    // Update user in sync store
    const user = syncStore.users.get(String(userId));
    if (user) {
      user.biometricCredentialId = null;
      user.biometricPublicKey = null;
      user.biometricAlgorithm = null;
      user.biometricEnabled = false;
      user.biometricRegisteredAt = null;
      syncStore.users.set(String(userId), user);
    }

    // Update in PostgreSQL if available
    if (pgPool) {
      const query = `
        UPDATE users
        SET biometric_credential_id = NULL,
            biometric_public_key = NULL,
            biometric_algorithm = NULL,
            biometric_enabled = false,
            biometric_registered_at = NULL
        WHERE id = $1
      `;
      await PostgreSQL.query(query, [userId]);
    }

    res.json({ success: true, message: 'Biometric authentication removed' });
  } catch (error) {
    console.error('[Biometric] Removal error:', error);
    res.status(500).json({ error: 'Failed to remove biometric authentication' });
  }
});

// OAuth callback handler (POST for modern OAuth flow)
app.post('/api/oauth/callback', async (req, res) => {
  try {
    const { provider, code, redirectUri, verifier } = req.body;

    console.log('[OAuth] Callback received for provider:', provider);

    if (!provider || !code) {
      return res.status(400).json({ error: 'Provider and code are required' });
    }

    let tokenUrl, userInfoUrl, clientId, clientSecret;
    let userId, userEmail, userName, userAvatar;

    // Configure based on provider
    switch (provider) {
      case 'google':
        tokenUrl = 'https://oauth2.googleapis.com/token';
        userInfoUrl = 'https://www.googleapis.com/oauth2/v3/userinfo';
        clientId = process.env.GOOGLE_CLIENT_ID || 'YOUR_GOOGLE_CLIENT_ID';
        clientSecret = process.env.GOOGLE_CLIENT_SECRET || 'YOUR_GOOGLE_CLIENT_SECRET';
        break;
      case 'facebook':
        tokenUrl = 'https://graph.facebook.com/v18.0/oauth/access_token';
        userInfoUrl = 'https://graph.facebook.com/v18.0/me?fields=id,name,email,picture';
        clientId = process.env.FACEBOOK_APP_ID || 'YOUR_FACEBOOK_APP_ID';
        clientSecret = process.env.FACEBOOK_APP_SECRET || 'YOUR_FACEBOOK_APP_SECRET';
        break;
      case 'apple':
        tokenUrl = 'https://appleid.apple.com/auth/token';
        clientId = process.env.APPLE_SERVICE_ID || 'YOUR_APPLE_SERVICE_ID';
        clientSecret = process.env.APPLE_PRIVATE_KEY || ''; // Apple requires JWT generation
        break;
      case 'twitter':
        tokenUrl = 'https://api.twitter.com/2/oauth2/token';
        userInfoUrl = 'https://api.twitter.com/2/users/me';
        clientId = process.env.TWITTER_CLIENT_ID || 'YOUR_TWITTER_CLIENT_ID';
        clientSecret = process.env.TWITTER_CLIENT_SECRET || 'YOUR_TWITTER_CLIENT_SECRET';
        break;
      case 'line':
        tokenUrl = 'https://api.line.me/oauth2/v2.1/token';
        userInfoUrl = 'https://api.line.me/v2/profile';
        clientId = process.env.LINE_CHANNEL_ID || 'YOUR_LINE_CHANNEL_ID';
        clientSecret = process.env.LINE_CHANNEL_SECRET || 'YOUR_LINE_CHANNEL_SECRET';
        break;
      case 'kakao':
        tokenUrl = 'https://kauth.kakao.com/oauth/token';
        userInfoUrl = 'https://kapi.kakao.com/v2/user/me';
        clientId = process.env.KAKAO_CLIENT_ID || 'YOUR_KAKAO_CLIENT_ID';
        clientSecret = process.env.KAKAO_CLIENT_SECRET || 'YOUR_KAKAO_CLIENT_SECRET';
        break;
      default:
        return res.status(400).json({ error: 'Unsupported OAuth provider' });
    }

    // Exchange code for access token
    const tokenParams = new URLSearchParams();
    tokenParams.append('client_id', clientId);
    tokenParams.append('client_secret', clientSecret);
    tokenParams.append('code', code);
    tokenParams.append('redirect_uri', redirectUri);
    tokenParams.append('grant_type', 'authorization_code');

    if (verifier) {
      tokenParams.append('code_verifier', verifier);
    }

    const tokenResponse = await fetch(tokenUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: tokenParams.toString()
    });

    const tokenData = await tokenResponse.json();

    if (tokenData.error) {
      console.error('[OAuth] Token error:', tokenData.error);
      return res.status(400).json({ error: tokenData.error_description || tokenData.error });
    }

    // Get user info
    let userInfo = {};
    if (userInfoUrl) {
      const userResponse = await fetch(userInfoUrl, {
        headers: { 'Authorization': `Bearer ${tokenData.access_token}` }
      });
      userInfo = await userResponse.json();
    }

    // Normalize user data based on provider
    switch (provider) {
      case 'google':
        userId = userInfo.sub;
        userEmail = userInfo.email;
        userName = userInfo.name;
        userAvatar = userInfo.picture;
        break;
      case 'facebook':
        userId = userInfo.id;
        userEmail = userInfo.email;
        userName = userInfo.name;
        userAvatar = userInfo.picture?.data?.url;
        break;
      case 'apple':
        userId = userInfo.sub;
        userEmail = userInfo.email;
        userName = userInfo.name?.firstName + ' ' + userInfo.name?.lastName;
        break;
      case 'twitter':
        userId = userInfo.data?.id;
        userName = userInfo.data?.name;
        userEmail = `${userId}@twitter.com`;
        userAvatar = userInfo.data?.profile_image_url;
        break;
      case 'line':
        userId = userInfo.userId;
        userEmail = userInfo.email;
        userName = userInfo.displayName;
        userAvatar = userInfo.pictureUrl;
        break;
      case 'kakao':
        userId = userInfo.id;
        userEmail = userInfo.kakao_account?.email;
        userName = userInfo.properties?.nickname;
        userAvatar = userInfo.properties?.profile_image;
        break;
    }

    res.json({
      success: true,
      userInfo: {
        id: userId,
        email: userEmail,
        name: userName,
        picture: userAvatar
      },
      tokenData
    });

  } catch (error) {
    console.error('[OAuth] Callback error:', error);
    res.status(500).json({ error: error.message || 'OAuth callback failed' });
  }
});

// OAuth callback handler (GET for legacy redirect flow)
app.get('/oauth/callback', async (req, res) => {
  try {
    const { code, state, provider } = req.query;

    // Exchange code for access token
    const accessToken = await exchangeOAuthCode(provider, code);

    // Get user profile from OAuth provider
    const userProfile = await getOAuthUserProfile(provider, accessToken);

    // Find or create user
    const userId = await findOrCreateOAuthUser(provider, userProfile);

    // Create session
    const sessionToken = jwt.sign({ userId }, JWT_SECRET, { expiresIn: '7d' });

    // Redirect to app with session
    res.redirect(`/?session=${sessionToken}`);
  } catch (error) {
    console.error('[OAuth] Callback error:', error);
    res.redirect('/?error=oauth_failed');
  }
});

// Login notification
app.post('/api/notifications/login', async (req, res) => {
  try {
    const { userId, deviceInfo, timestamp, ipAddress } = req.body;

    // Send email notification about new login
    // Store login record in database
    if (pgPool) {
      await PostgreSQL.query(
        'INSERT INTO login_history (user_id, device_info, ip_address, timestamp) VALUES ($1, $2, $3, $4)',
        [userId, JSON.stringify(deviceInfo), ipAddress, timestamp]
      );
    }

    res.json({ success: true });
  } catch (error) {
    console.error('[Login Notification] Error:', error);
    res.status(500).json({ error: 'Login notification failed' });
  }
});

// Download tracking endpoint
app.post('/api/downloads/track', async (req, res) => {
  try {
    const { userId, downloadId, type, quality, startTime, endTime, duration, income, points } = req.body;

    console.log('[DownloadTracking] Tracking download:', {
      userId,
      downloadId,
      type,
      quality,
      duration,
      income,
      points
    });

    // Store download record in database
    if (pgPool) {
      await PostgreSQL.query(
        `INSERT INTO downloads (user_id, download_id, type, quality, start_time, end_time, duration, income, points, timestamp) 
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)`,
        [userId, downloadId, type, quality, new Date(startTime), new Date(endTime), duration, income, points, new Date()]
      );
    }

    // Calculate user's total income from downloads
    let totalIncome = 0;
    let totalDownloads = 0;

    if (pgPool) {
      const result = await PostgreSQL.query(
        'SELECT COALESCE(SUM(income), 0) as total_income, COUNT(*) as total_downloads FROM downloads WHERE user_id = $1',
        [userId]
      );

      if (result.rows.length > 0) {
        totalIncome = parseFloat(result.rows[0].total_income) || 0;
        totalDownloads = parseInt(result.rows[0].total_downloads) || 0;
      }
    }

    res.json({
      success: true,
      totalIncome,
      totalDownloads,
      currentDownload: {
        id: downloadId,
        type,
        quality,
        duration,
        income,
        points
      }
    });
  } catch (error) {
    console.error('[DownloadTracking] Error:', error);
    res.status(500).json({ error: 'Download tracking failed' });
  }
});

// Get user download history
app.get('/api/downloads/history/:userId', async (req, res) => {
  try {
    const { userId } = req.params;

    if (pgPool) {
      const result = await PostgreSQL.query(
        'SELECT * FROM downloads WHERE user_id = $1 ORDER BY timestamp DESC LIMIT 50',
        [userId]
      );

      res.json({ success: true, downloads: result.rows });
    } else {
      // Fallback: return empty array
      res.json({ success: true, downloads: [] });
    }
  } catch (error) {
    console.error('[DownloadHistory] Error:', error);
    res.status(500).json({ error: 'Failed to fetch download history' });
  }
});

// Session management
app.post('/api/auth/session/create', async (req, res) => {
  try {
    const { userId, deviceFingerprint } = req.body;

    // Check concurrent session limit
    let sessionCount = 0;
    if (pgPool) {
      const activeSessions = await PostgreSQL.query(
        'SELECT COUNT(*) FROM sessions WHERE user_id = $1 AND expires_at > NOW()',
        [userId]
      );
      sessionCount = parseInt(activeSessions.rows[0].count);
    }

    const MAX_CONCURRENT_SESSIONS = 3;

    if (sessionCount >= MAX_CONCURRENT_SESSIONS) {
      // Remove oldest session
      if (pgPool) {
        await PostgreSQL.query(
          'DELETE FROM sessions WHERE user_id = $1 ORDER BY created_at ASC LIMIT 1',
          [userId]
        );
      }
    }

    // Create new session
    const sessionId = crypto.randomBytes(16).toString('hex');
    const expiresAt = new Date(Date.now() + 30 * 60 * 1000); // 30 minutes

    if (pgPool) {
      await PostgreSQL.query(
        'INSERT INTO sessions (id, user_id, device_fingerprint, expires_at, created_at) VALUES ($1, $2, $3, $4, NOW())',
        [sessionId, userId, deviceFingerprint, expiresAt]
      );
    }

    const sessionToken = jwt.sign({ userId, sessionId }, JWT_SECRET, { expiresIn: '30m' });

    res.json({ success: true, sessionToken, sessionId });
  } catch (error) {
    console.error('[Session] Create error:', error);
    res.status(500).json({ error: 'Session creation failed' });
  }
});

app.post('/api/auth/session/validate', async (req, res) => {
  try {
    const { sessionToken } = req.body;

    const decoded = jwt.verify(sessionToken, JWT_SECRET);

    // Check if session exists and is valid
    let session = null;
    if (pgPool) {
      const result = await PostgreSQL.query(
        'SELECT * FROM sessions WHERE id = $1 AND user_id = $2 AND expires_at > NOW()',
        [decoded.sessionId, decoded.userId]
      );
      session = result.rows[0];
    }

    if (session) {
      res.json({ success: true, userId: decoded.userId });
    } else {
      res.json({ success: false, error: 'Session expired or invalid' });
    }
  } catch (error) {
    console.error('[Session] Validate error:', error);
    res.json({ success: false, error: 'Session validation failed' });
  }
});

app.post('/api/auth/session/revoke', async (req, res) => {
  try {
    const { sessionId, userId } = req.body;

    if (pgPool) {
      await PostgreSQL.query(
        'DELETE FROM sessions WHERE id = $1 AND user_id = $2',
        [sessionId, userId]
      );
    }

    res.json({ success: true });
  } catch (error) {
    console.error('[Session] Revoke error:', error);
    res.status(500).json({ error: 'Session revocation failed' });
  }
});

// Helper functions for OAuth
async function exchangeOAuthCode(provider, code) {
  // Implement OAuth code exchange based on provider
  // This is a placeholder - implement actual OAuth flow
  return 'access_token_placeholder';
}

async function getOAuthUserProfile(provider, accessToken) {
  // Implement user profile retrieval from OAuth provider
  // This is a placeholder - implement actual API calls
  return {
    id: 'oauth_user_id',
    email: 'user@example.com',
    name: 'OAuth User',
    avatar: 'https://example.com/avatar.jpg'
  };
}

async function findOrCreateOAuthUser(provider, profile) {
  // Find user by OAuth provider ID
  // If not found, create new user
  // Return user ID
  return 'user_id_placeholder';
}

async function findUserByCredentialId(credentialId) {
  // Find user by WebAuthn credential ID
  // Return user ID or null
  return null;
}

function toIso(msOrDate) {
  if (!msOrDate) return new Date().toISOString();
  const d = typeof msOrDate === 'number' ? new Date(msOrDate) : new Date(msOrDate);
  return Number.isNaN(d.getTime()) ? new Date().toISOString() : d.toISOString();
}

function userRow(u = {}) {
  return {
    id: String(u.id || u.userId || ''),
    name: String(u.name || u.username || 'User'),
    username: u.username || null,
    email: u.email || null,
    phone: u.phone || null,
    password: u.password || null,
    bio: u.bio || null,
    avatar: u.avatar || null,
    cover: u.cover || null,
    points: Math.max(0, Number(u.points || 0)),
    is_admin: !!(u.isAdmin || u.is_admin),
    kyc_verified: !!(u.kycVerified || u.kyc_verified),
    verified: !!u.verified,
    two_fa: !!(u.twoFA || u.two_fa),
    disabled: !!u.disabled,
    deactivated: !!u.deactivated,
    tin: u.tin || null,
    pay_methods: u.payMethods || u.pay_methods || null,
    crypto_wallets: u.cryptoWallets || u.crypto_wallets || null,
    privacy_settings: u.privacySettings || u.privacy_settings || null,
    notif_settings: u.notifSettings || u.notif_settings || null,
    eth_address: u.ethAddress || u.eth_address || null,
    sol_address: u.solAddress || u.sol_address || null,
    referred_by: u.referredBy || u.referred_by || null,
    created_at: toIso(u.createdAt || u.created_at || Date.now()),
    updated_at: new Date().toISOString()
  };
}

function postRow(p = {}) {
  return {
    id: String(p.id || ''),
    author: String(p.author || ''),
    text: p.text || '',
    file: p.file || null,
    file_type: p.mimetype || p.fileType || p.type || null,
    tags: Array.isArray(p.hashtags) ? p.hashtags : (Array.isArray(p.tags) ? p.tags : []),
    visibility: p.visibility || 'public',
    likes: Array.isArray(p.likedBy) ? p.likedBy : (Array.isArray(p.likes) ? p.likes : []),
    views: Number(p.views || 0),
    reports: Number(p.reports || 0),
    hidden: !!p.hidden,
    copyright: !!p.copyright,
    chain: p.chain || null,
    created_at: toIso(p.createdAt || p.created_at || Date.now())
  };
}

function txRow(t = {}) {
  return {
    id: String(t.id || 'tx_' + Date.now()),
    user_id: String(t.user || t.userId || t.user_id || ''),
    type: t.type || 'ledger',
    label: t.label || '',
    pts: Math.trunc(Number(t.pts || 0)),
    admin_cut: Math.trunc(Number(t.adminCut || t.admin_cut || 0)),
    created_at: toIso(t.at || t.createdAt || t.created_at || Date.now())
  };
}

async function persistUser(u) {
  const row = userRow(u);
  if (!row.id) throw new Error('user id required');
  try {
    await supabaseRest('users', 'POST', row, 'on_conflict=id', 'resolution=merge-duplicates,return=representation');
  } catch (e) {
    supabaseState.fallbackMode = true;
    supabaseState.lastError = e.message;
    console.warn('[Supabase] persistUser fallback to local memory:', e.message);
  }
  return row;
}

async function persistPost(p) {
  const row = postRow(p);
  if (!row.id || !row.author) throw new Error('post id and author required');
  try {
    await supabaseRest('posts', 'POST', row, 'on_conflict=id', 'resolution=merge-duplicates,return=representation');
  } catch (e) {
    supabaseState.fallbackMode = true;
    supabaseState.lastError = e.message;
    console.warn('[Supabase] persistPost fallback to local memory:', e.message);
  }
  return row;
}

async function persistTransaction(t) {
  const row = txRow(t);
  if (!row.id || !row.user_id) throw new Error('transaction id and user required');
  try {
    await supabaseRest('transactions', 'POST', row, 'on_conflict=id', 'resolution=ignore-duplicates,return=representation');
  } catch (e) {
    supabaseState.fallbackMode = true;
    supabaseState.lastError = e.message;
    console.warn('[Supabase] persistTransaction fallback to local memory:', e.message);
  }
  return row;
}

async function getPersistentUser(userId) {
  try {
    const rows = await supabaseRest('users', 'GET', null, `id=eq.${encodeURIComponent(userId)}&select=*`);
    return Array.isArray(rows) ? rows[0] : null;
  } catch (e) {
    supabaseState.fallbackMode = true;
    supabaseState.lastError = e.message;
    return null;
  }
}

async function setPersistentPoints(userId, points) {
  try {
    await supabaseRest('users', 'PATCH', { points: Math.max(0, Math.trunc(Number(points || 0))), updated_at: new Date().toISOString() }, `id=eq.${encodeURIComponent(userId)}`, 'return=representation');
  } catch (e) {
    supabaseState.fallbackMode = true;
    supabaseState.lastError = e.message;
    console.warn('[Supabase] setPersistentPoints fallback to local memory:', e.message);
  }
}

async function creditUserPoints(userId, pts, label, type = 'topup', txId = 'tx_' + Date.now()) {
  const delta = Math.trunc(Number(pts || 0));
  if (!userId || !delta) throw new Error('userId and pts required');
  const current = await getPersistentUser(userId);
  const nextPoints = Math.max(0, Number(current?.points || syncStore.points.get(userId)?.points || 0) + delta);
  await setPersistentPoints(userId, nextPoints);
  const tx = await persistTransaction({ id: txId, user: userId, type, label, pts: delta, at: Date.now() });
  syncStore.points.set(userId, { points: nextPoints, updatedAt: Date.now(), history: [...(syncStore.points.get(userId)?.history || []).slice(-49), { points: delta, label, at: Date.now() }] });
  if (syncStore.users.has(userId)) syncStore.users.get(userId).points = nextPoints;
  return { points: nextPoints, tx };
}

async function hydratePersistentSyncStore() {
  try {
    const [users, posts, txs] = await Promise.all([
      supabaseRest('users', 'GET', null, 'select=*&limit=500'),
      supabaseRest('posts', 'GET', null, 'select=*&order=created_at.desc&limit=500'),
      supabaseRest('transactions', 'GET', null, 'select=*&order=created_at.desc&limit=500')
    ]);
    (users || []).forEach(u => {
      syncStore.users.set(u.id, { ...u, isAdmin: u.is_admin, kycVerified: u.kyc_verified, twoFA: u.two_fa, privacySettings: u.privacy_settings, notifSettings: u.notif_settings, points: Number(u.points || 0) });
      syncStore.points.set(u.id, { points: Number(u.points || 0), history: [] });
    });
    (posts || []).forEach(p => syncStore.posts.set(p.id, {
      id: p.id, author: p.author, text: p.text, file: p.file, mimetype: p.file_type,
      hashtags: p.tags || [], visibility: p.visibility, likedBy: p.likes || [],
      views: p.views || 0, reports: p.reports || 0, hidden: p.hidden,
      copyright: p.copyright, chain: p.chain, createdAt: new Date(p.created_at).getTime()
    }));
    (txs || []).forEach(t => syncStore.points.set(t.user_id, {
      ...(syncStore.points.get(t.user_id) || { points: 0 }),
      history: [...(syncStore.points.get(t.user_id)?.history || []).slice(-49), { points: t.pts, label: t.label, at: new Date(t.created_at).getTime() }]
    }));
    updateIndexes();
    console.log(`[Supabase] Hydrated ${syncStore.users.size} users, ${syncStore.posts.size} posts`);
  } catch (e) {
    console.warn('[Supabase hydrate]', e.message || e);
  }
}

async function verifySupabaseToken(token) {
  if (!token) return null;
  const r = await fetch(`${SUPABASE_URL}/auth/v1/user`, {
    headers: { apikey: SUPABASE_ANON, Authorization: `Bearer ${token}` }
  });
  if (!r.ok) return null;
  const user = await r.json();
  if (!user?.id && !user?.email) return null;
  const matches = Array.from(syncStore.users.values()).find(u => u.authUid === user.id || (u.email && user.email && String(u.email).toLowerCase() === String(user.email).toLowerCase()));
  return { authUid: user.id, email: user.email, appUserId: matches?.id || user.user_metadata?.appUserId || null };
}

function verifyStripeSignature(rawBody, signatureHeader, secret) {
  if (!secret) return true;
  if (!signatureHeader) return false;
  const parts = Object.fromEntries(String(signatureHeader).split(',').map(part => {
    const [k, v] = part.split('=');
    return [k, v];
  }));
  if (!parts.t || !parts.v1) return false;
  const expected = crypto.createHmac('sha256', secret).update(`${parts.t}.${rawBody.toString('utf8')}`).digest('hex');
  const a = Buffer.from(expected, 'hex');
  const b = Buffer.from(parts.v1, 'hex');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

probeSupabaseConnectivity().then(reachable => {
  console.log(`[Supabase] connectivity probe -> ${reachable ? 'reachable' : 'unreachable'}${supabaseState.lastError ? ` (${supabaseState.lastError})` : ''}`);
}).catch(() => {
  console.warn('[Supabase] connectivity probe failed');
});

// Send push notification to a user
async function sendPushToUser(userId, payload) {
  const sub = pushSubscriptions.get(userId);
  if (!sub || !VAPID_PUBLIC) return;
  try {
    await webpush.sendNotification(sub, JSON.stringify(payload));
  } catch (e) {
    if (e.statusCode === 410) pushSubscriptions.delete(userId);
  }
}

// ─────────────────────────────────────────────────────────────
//  ROUTES
// ─────────────────────────────────────────────────────────────

// Health
app.get('/health', (_, res) => res.json({
  status: 'ok', uptime: Math.floor(process.uptime()),
  online: onlineSessions.size, onlineUsers: onlineUsers.size, calls: callSessions.size,
  webpush: !!(VAPID_PUBLIC && VAPID_PRIVATE),
  bkash: !!BKASH_APP_KEY, nagad: !!NAGAD_MERCHANT
}));

// Health (API prefix for consistency)
app.get('/api/health', (_, res) => res.json({
  status: 'ok', timestamp: new Date().toISOString(),
  uptime: Math.floor(process.uptime()),
  online: onlineSessions.size, onlineUsers: onlineUsers.size, calls: callSessions.size,
  socketio: io.engine.clientsCount,
  webpush: !!(VAPID_PUBLIC && VAPID_PRIVATE),
  bkash: !!BKASH_APP_KEY, nagad: !!NAGAD_MERCHANT
}));

// Cloudinary signature for secure uploads
app.get('/api/cloudinary/signature', (req, res) => {
  if (!CLOUDINARY_CLOUD_NAME || !CLOUDINARY_API_KEY || !CLOUDINARY_API_SECRET) {
    return res.status(400).json({ error: 'Cloudinary not configured' });
  }
  const folder = req.query.folder || 'monetixra';
  const timestamp = Math.floor(Date.now() / 1000);
  const payload = `folder=${folder}&timestamp=${timestamp}${CLOUDINARY_API_SECRET}`;
  const signature = crypto.createHash('sha1').update(payload).digest('hex');
  res.json({
    cloudName: CLOUDINARY_CLOUD_NAME,
    apiKey: CLOUDINARY_API_KEY,
    timestamp,
    signature,
    folder
  });
});

// ICE Servers
app.get('/api/ice-servers', async (_, res) => {
  res.json({ iceServers: await getICE() });
});

// VAPID public key (needed by client for push subscription)
app.get('/api/push/vapid-key', (_, res) => {
  if (!VAPID_PUBLIC) return res.json({ error: 'VAPID not configured' });
  res.json({ publicKey: VAPID_PUBLIC });
});

// Push Subscribe
app.post('/api/push/subscribe', (req, res) => {
  const { userId, subscription } = req.body;
  if (!userId || !subscription) return res.status(400).json({ error: 'userId and subscription required' });
  pushSubscriptions.set(userId, subscription);
  console.log(`[Push] User ${userId} subscribed`);
  res.json({ success: true });
});

// Push Unsubscribe
app.post('/api/push/unsubscribe', (req, res) => {
  const { userId } = req.body;
  if (userId) pushSubscriptions.delete(userId);
  res.json({ success: true });
});

// Send Push (admin or server-side trigger)
app.post('/api/push/send', async (req, res) => {
  const { userId, title, body, icon, url } = req.body;
  if (!userId) return res.status(400).json({ error: 'userId required' });
  await sendPushToUser(userId, { title, body, icon: icon || '/icon-192.png', url: url || '/' });
  res.json({ success: true });
});

// Broadcast Push to all
app.post('/api/push/broadcast', async (req, res) => {
  const { title, body, icon } = req.body;
  let count = 0;
  for (const [uid, sub] of pushSubscriptions) {
    try { await webpush.sendNotification(sub, JSON.stringify({ title, body, icon: icon || '/icon-192.png' })); count++; }
    catch (e) { if (e.statusCode === 410) pushSubscriptions.delete(uid); }
  }
  res.json({ success: true, sent: count });
});

// ── AI Chat ──────────────────────────────────────────────────
app.post('/api/ai/chat', async (req, res) => {
  const { messages, model = 'openai', systemPrompt } = req.body;
  if (!Array.isArray(messages)) return res.status(400).json({ error: 'messages required' });
  const msgs = systemPrompt ? [{ role: 'system', content: systemPrompt }, ...messages] : messages;
  try {
    if (model === 'deepseek') {
      const r = await fetch('https://api.deepseek.com/chat/completions', {
        method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${DEEPSEEK_KEY}` },
        body: JSON.stringify({ model: 'deepseek-chat', messages: msgs, max_tokens: 1000 })
      });
      const d = await r.json();
      return res.json({ reply: d.choices?.[0]?.message?.content || '', model: 'deepseek' });
    }
    const r = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${OPENAI_KEY}` },
      body: JSON.stringify({ model: 'gpt-4o-mini', messages: msgs, max_tokens: 1000 })
    });
    const d = await r.json();
    if (d.error) return res.status(400).json({ error: d.error.message });
    res.json({ reply: d.choices?.[0]?.message?.content || '', model: 'openai' });
  } catch (e) { res.status(500).json({ error: 'AI unavailable' }); }
});

// ── AI Caption (Enhanced for Video/Audio/Photo) ────────────────────────
app.post('/api/ai/caption', async (req, res) => {
  const { type = 'photo', data = '', language = 'auto', style = 'descriptive' } = req.body;
  if (!data) return res.status(400).json({ error: 'data required' });

  try {
    let prompt = '';

    switch (type) {
      case 'video':
        prompt = `Write a descriptive, engaging social media caption for this video content. Describe what might be happening in the video, the mood, and why people should watch it. Make it captivating and shareable. Include relevant hashtags.`;
        break;
      case 'audio':
        prompt = `Write a compelling social media caption for this audio content. Describe the mood, genre, and what makes this audio special. Make people want to listen. Include relevant hashtags.`;
        break;
      case 'photo':
        prompt = `Write a descriptive, engaging social media caption for this image. Describe what's happening, the mood, colors, and composition. Make it shareable and discoverable. Include relevant hashtags.`;
        break;
      default:
        prompt = `Write an engaging social media caption for this content. Make it shareable and include relevant hashtags.`;
    }

    if (language && language !== 'auto') {
      prompt += ` Write the caption in ${language}.`;
    }

    if (style) {
      prompt += ` Use a ${style} style.`;
    }

    const r = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${OPENAI_KEY}` },
      body: JSON.stringify({ model: 'gpt-4o-mini', messages: [{ role: 'user', content: prompt }], max_tokens: 300 })
    });
    const d = await r.json();
    const caption = d.choices?.[0]?.message?.content || 'Amazing content! 🔥 #Monetixra #Trending #Viral';
    res.json({ caption, type, style, language });
  } catch (e) {
    console.error('AI Caption error:', e);
    res.json({ caption: 'Amazing content! 🔥 #Monetixra #Trending #Viral #Creator #Digital', type, style, language });
  }
});

// ── AI Hashtags Generation ────────────────────────────────────────────────
app.post('/api/ai/hashtags', async (req, res) => {
  const { caption = '', fileType = 'photo', maxHashtags = 10 } = req.body;

  try {
    const prompt = `Generate ${maxHashtags} relevant, trending hashtags for this social media content: "${caption}". The content type is ${fileType}. Return only the hashtags, one per line, starting with #.`;

    const r = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${OPENAI_KEY}` },
      body: JSON.stringify({ model: 'gpt-4o-mini', messages: [{ role: 'user', content: prompt }], max_tokens: 150 })
    });
    const d = await r.json();
    const hashtagsText = d.choices?.[0]?.message?.content || '#Monetixra #Trending #Viral';
    const hashtags = hashtagsText.split('\n').filter(tag => tag.trim().startsWith('#')).map(tag => tag.trim());
    res.json({ hashtags });
  } catch (e) {
    console.error('Hashtags generation error:', e);
    res.json({ hashtags: ['#Monetixra', '#Trending', '#Viral', '#SocialMedia', '#ContentCreator'] });
  }
});

// ── Enhanced Vision API (Object Detection) ────────────────────────────────
app.post('/api/ai/vision', async (req, res) => {
  const { type = 'photo', data = '' } = req.body;
  if (!data) return res.status(400).json({ error: 'data required' });

  try {
    const b64 = data.split(',')[1] || data;

    if (type === 'object-detection') {
      // Object detection specific
      const r = await fetch(`https://vision.googleapis.com/v1/images:annotate?key=${GOOGLE_VISION}`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          requests: [{
            image: { content: b64 }, features: [
              { type: 'LABEL_DETECTION', maxResults: 15 }, { type: 'OBJECT_LOCALIZATION', maxResults: 10 }
            ]
          }]
        })
      });
      const d = await r.json();
      const objects = (d.responses?.[0]?.labelAnnotations || []).map(l => l.description);
      res.json({ objects });
    } else {
      // Regular photo analysis
      const r = await fetch(`https://vision.googleapis.com/v1/images:annotate?key=${GOOGLE_VISION}`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          requests: [{
            image: { content: b64 }, features: [
              { type: 'LABEL_DETECTION', maxResults: 10 }, { type: 'TEXT_DETECTION', maxResults: 5 },
              { type: 'SAFE_SEARCH_DETECTION' }, { type: 'IMAGE_PROPERTIES' }
            ]
          }]
        })
      });
      const d = await r.json();
      const labels = (d.responses?.[0]?.labelAnnotations || []).map(l => l.description);
      const text = d.responses?.[0]?.textAnnotations?.[0]?.description || '';
      const safe = d.responses?.[0]?.safeSearchAnnotation || {};
      const isUnsafe = ['LIKELY', 'VERY_LIKELY'].includes(safe.adult) || ['LIKELY', 'VERY_LIKELY'].includes(safe.violence);

      // Generate caption from vision data
      const caption = labels.length > 0 ?
        `This image contains: ${labels.slice(0, 5).join(', ')}. ${text ? `Text detected: "${text.substring(0, 100)}"` : ''}` :
        'Interesting visual content worth sharing!';

      res.json({ caption, labels, text, safe: !isUnsafe, objects: labels });
    }
  } catch (e) {
    console.error('Vision API error:', e);
    res.json({ caption: 'Beautiful image worth sharing!', labels: [], text: '', safe: true, objects: [] });
  }
});

// ── Enhanced Translation API ────────────────────────────────────────────────
async function googleTranslate(q, targetLanguage = 'en', sourceLanguage = 'auto') {
  if (!GOOGLE_KEY) return { translated: q, translatedText: q, sourceLanguage, targetLanguage, configured: false };
  const payload = { q, target: targetLanguage, format: 'text' };
  if (sourceLanguage && sourceLanguage !== 'auto') payload.source = sourceLanguage;
  const r = await fetch(`https://translation.googleapis.com/language/translate/v2?key=${GOOGLE_KEY}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  const d = await r.json();
  if (!r.ok) throw new Error(d.error?.message || 'Google Translate failed');
  const first = d.data?.translations?.[0] || {};
  return {
    translated: first.translatedText || q,
    translatedText: first.translatedText || q,
    sourceLanguage: first.detectedSourceLanguage || sourceLanguage,
    targetLanguage,
    configured: true
  };
}

app.post('/api/ai/translate', async (req, res) => {
  const { text = '', targetLanguage = 'en', sourceLanguage = 'auto' } = req.body;
  if (!text) return res.status(400).json({ error: 'text required' });

  try {
    res.json(await googleTranslate(text, targetLanguage, sourceLanguage));
  } catch (e) {
    console.error('Translation error:', e);
    res.json({ translatedText: text, sourceLanguage: sourceLanguage, targetLanguage });
  }
});

// ── Google Translate ──────────────────────────────────────────
app.post('/api/translate', async (req, res) => {
  const { text, target = 'en', targetLanguage, sourceLanguage = 'auto' } = req.body;
  if (!text) return res.status(400).json({ error: 'text required' });
  try {
    res.json(await googleTranslate(text, targetLanguage || target, sourceLanguage));
  } catch (e) { res.json({ error: 'Translation failed', detail: e.message, translated: text, translatedText: text }); }
});

app.post('/api/translate/batch', async (req, res) => {
  const { texts = [], target = 'en', targetLanguage, sourceLanguage = 'auto' } = req.body || {};
  const list = Array.isArray(texts) ? texts.slice(0, 100) : [];
  if (!list.length) return res.status(400).json({ error: 'texts required' });
  const lang = targetLanguage || target;
  try {
    if (!GOOGLE_KEY) return res.json({ translations: list, translated: list, configured: false });
    const payload = { q: list, target: lang, format: 'text' };
    if (sourceLanguage && sourceLanguage !== 'auto') payload.source = sourceLanguage;
    const r = await fetch(`https://translation.googleapis.com/language/translate/v2?key=${GOOGLE_KEY}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const d = await r.json();
    if (!r.ok) throw new Error(d.error?.message || 'Google Translate batch failed');
    const translations = (d.data?.translations || []).map((x, i) => x.translatedText || list[i]);
    res.json({ translations, translated: translations, targetLanguage: lang, configured: true });
  } catch (e) {
    res.json({ error: 'Batch translation failed', detail: e.message, translations: list, translated: list });
  }
});

// ── Google Vision ─────────────────────────────────────────────
app.post('/api/vision/analyze', async (req, res) => {
  const { imageBase64 } = req.body;
  if (!imageBase64) return res.status(400).json({ error: 'imageBase64 required' });
  try {
    const r = await fetch(`https://vision.googleapis.com/v1/images:annotate?key=${GOOGLE_VISION}`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        requests: [{
          image: { content: imageBase64 }, features: [
            { type: 'LABEL_DETECTION', maxResults: 8 }, { type: 'SAFE_SEARCH_DETECTION' }, { type: 'TEXT_DETECTION', maxResults: 5 }
          ]
        }]
      })
    });
    const d = await r.json();
    const labels = (d.responses?.[0]?.labelAnnotations || []).map(l => l.description);
    const safe = d.responses?.[0]?.safeSearchAnnotation || {};
    const text = d.responses?.[0]?.textAnnotations?.[0]?.description || '';
    const isUnsafe = ['LIKELY', 'VERY_LIKELY'].includes(safe.adult) || ['LIKELY', 'VERY_LIKELY'].includes(safe.violence);
    res.json({ labels, safe: !isUnsafe, safeSearch: safe, text });
  } catch (e) { res.status(500).json({ error: 'Vision API failed' }); }
});

// ── AI Transcribe / Auto-caption (images -> vision text/labels, audio/video -> stub/fallback)
app.post('/api/ai/transcribe', async (req, res) => {
  const { name = '', data = '', type = '' } = req.body;
  if (!data) return res.status(400).json({ error: 'data required (dataURL or base64)' });
  try {
    // Normalize base64 (strip data: prefix)
    const b64 = data.split(',')[1] || data;
    // If image, use Google Vision TEXT_DETECTION + LABEL_DETECTION to produce caption
    if (type.startsWith('image/') || name.match(/\.jpg$|\.jpeg$|\.png$|\.webp$/i)) {
      const r = await fetch(`https://vision.googleapis.com/v1/images:annotate?key=${GOOGLE_VISION}`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ requests: [{ image: { content: b64 }, features: [{ type: 'TEXT_DETECTION' }, { type: 'LABEL_DETECTION', maxResults: 6 }] }] })
      });
      const d = await r.json();
      const text = d.responses?.[0]?.textAnnotations?.[0]?.description || '';
      const labels = (d.responses?.[0]?.labelAnnotations || []).map(l => l.description).slice(0, 5);
      const caption = text ? `${text.split('\n').slice(0, 3).join(' ')}${labels.length ? (' · ' + labels.join(', ')) : ''}` : (labels.join(', ') || `Image: ${name}`);
      return res.json({ transcript: caption.trim(), source: 'vision' });
    }

    // For audio/video: server-side ASR not configured here — return helpful fallback
    if (!OPENAI_KEY) {
      return res.status(501).json({ error: 'ASR not configured on server. Set OPENAI_API_KEY or another ASR provider to enable audio/video transcription.', fallback: `Auto-caption placeholder: ${name}` });
    }

    // If OPENAI_KEY exists, provide informational response (integration placeholder)
    // NOTE: full binary upload/transcription flow requires multipart/form-data handling.
    return res.status(501).json({ error: 'ASR integration required. Server has OPENAI_API_KEY but automatic multipart upload not implemented in this stub. See server logs for integration instructions.' });
  } catch (e) {
    console.error('[transcribe]', e.message || e);
    res.status(500).json({ error: 'Transcription failed', detail: e.message });
  }
});

// ── Supabase Proxy ────────────────────────────────────────────
const permittedDbMethods = new Set(['GET', 'POST', 'PATCH', 'DELETE']);

app.post('/api/db/:table', async (req, res) => {
  const table = req.params.table;
  const { method = 'GET', filter, body: payload, select = '*' } = req.body || {};
  const normalizedMethod = String(method || 'GET').toUpperCase();

  if (!TRUSTED_DB_TABLES.has(table)) {
    return res.status(403).json({ error: 'Table access denied' });
  }
  if (!permittedDbMethods.has(normalizedMethod)) {
    return res.status(400).json({ error: 'Invalid database method' });
  }

  try {
    let f = String(filter || '');
    if (normalizedMethod === 'GET' && select) {
      f += (f ? '&' : '') + 'select=' + encodeURIComponent(select);
    }
    const data = await supabaseReq(table, normalizedMethod, payload, f);
    res.json(data);
  } catch (e) {
    console.error('[Supabase proxy]', e);
    res.status(500).json({ error: 'DB error', detail: e.message });
  }
});

// ── Crypto Prices ─────────────────────────────────────────────
app.get('/api/crypto/prices', async (_, res) => {
  const cached = cache.get('crypto_prices');
  if (cached) {
    console.log('[Cache] Hit for crypto_prices');
    return res.json(cached);
  }

  try {
    const r = await fetch('https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum,tether,binancecoin,solana,toncoin&vs_currencies=usd&include_24hr_change=true');
    const data = await r.json();
    cache.set('crypto_prices', data);
    console.log('[Cache] Miss for crypto_prices, cached now');
    res.json(data);
  } catch (e) { res.json({ bitcoin: { usd: 0 }, ethereum: { usd: 0 }, solana: { usd: 0 }, binancecoin: { usd: 0 } }); }
});

// ────────────────────────────────────────────────────────────
//  bKASH PAYMENT API
// ────────────────────────────────────────────────────────────
async function getBkashToken() {
  if (bkashToken && Date.now() < bkashTokenExp) return bkashToken;
  try {
    const r = await fetch('https://tokenized.sandbox.bka.sh/v1.2.0-beta/tokenized/checkout/token/grant', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'username': BKASH_USERNAME,
        'password': BKASH_PASSWORD
      },
      body: JSON.stringify({ app_key: BKASH_APP_KEY, app_secret: BKASH_APP_SECRET })
    });
    const d = await r.json();
    if (d.id_token) {
      bkashToken = d.id_token;
      bkashTokenExp = Date.now() + (3590 * 1000);
      return bkashToken;
    }
  } catch (e) { console.error('[bKash token]', e.message); }
  return null;
}

// bKash: Create Payment
app.post('/api/payment/bkash/create',
  [
    body('amount').isFloat({ min: 1 }).withMessage('amount must be a positive number'),
    body('currency').optional().isString().withMessage('currency must be a string'),
    body('merchantInvoiceNumber').optional().isString().withMessage('merchantInvoiceNumber must be a string')
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ error: 'Validation failed', details: errors.array() });
    }

    if (!BKASH_APP_KEY) return res.json({ demo: true, paymentID: 'demo_' + Date.now(), bkashURL: '#', message: 'bKash not configured — demo mode' });
    try {
      const token = await getBkashToken();
      if (!token) return res.status(500).json({ error: 'bKash auth failed' });
      const { amount, currency = 'BDT', intent = 'sale', merchantInvoiceNumber } = req.body;
      const r = await fetch('https://tokenized.sandbox.bka.sh/v1.2.0-beta/tokenized/checkout/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'authorization': token, 'x-app-key': BKASH_APP_KEY },
        body: JSON.stringify({ mode: '0011', payerReference: merchantInvoiceNumber || 'ref' + Date.now(), callbackURL: process.env.BASE_URL + '/api/payment/bkash/callback', amount, currency, intent, merchantInvoiceNumber: merchantInvoiceNumber || 'inv' + Date.now() })
      });
      const d = await r.json();
      res.json(d);
    } catch (e) { res.status(500).json({ error: 'bKash create failed: ' + e.message }); }
  });

// bKash: Execute Payment
app.post('/api/payment/bkash/execute',
  [
    body('paymentID').trim().notEmpty().withMessage('paymentID is required')
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ error: 'Validation failed', details: errors.array() });
    }

    if (!BKASH_APP_KEY) return res.json({ demo: true, transactionStatus: 'Completed', trxID: 'TRX' + Date.now() });
    try {
      const token = await getBkashToken();
      const { paymentID } = req.body;
      const r = await fetch('https://tokenized.sandbox.bka.sh/v1.2.0-beta/tokenized/checkout/execute', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'authorization': token, 'x-app-key': BKASH_APP_KEY },
        body: JSON.stringify({ paymentID })
      });
      const d = await r.json();
      res.json(d);
    } catch (e) { res.status(500).json({ error: 'bKash execute failed: ' + e.message }); }
  });

// bKash callback
app.get('/api/payment/bkash/callback', (req, res) => {
  const { paymentID, status } = req.query;
  console.log('[bKash callback]', paymentID, status);
  res.redirect(`/?bkash=${status}&pid=${paymentID}`);
});

// ────────────────────────────────────────────────────────────
//  NAGAD PAYMENT API
// ────────────────────────────────────────────────────────────
app.post('/api/payment/nagad/create',
  [
    body('amount').isFloat({ min: 1 }).withMessage('amount must be a positive number'),
    body('orderId').optional().isString().withMessage('orderId must be a string')
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ error: 'Validation failed', details: errors.array() });
    }

    if (!NAGAD_MERCHANT) return res.json({ demo: true, orderId: 'nagad_' + Date.now(), message: 'Nagad not configured — demo mode' });
    try {
      const { amount, orderId } = req.body;
      const datetime = new Date().toISOString().replace(/[-:T]/g, '').slice(0, 14);
      const sensitiveData = { merchantId: NAGAD_MERCHANT, datetime, orderId: orderId || 'ord' + Date.now(), challenge: 'hash' + Date.now() };
      // In production: encrypt with Nagad public key using RSA
      const r = await fetch(`https://sandbox.mynagad.com:10080/remote-payment-gateway-1.0/api/dfs/check-out/initialize/${NAGAD_MERCHANT}/${orderId}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-KM-Api-Version': 'v-0.2.0', 'X-KM-IP-V4': '127.0.0.1', 'X-KM-Client-Type': 'PC_WEB' },
        body: JSON.stringify({ dateTime: datetime, sensitiveData: 'encrypted_data', signature: 'signature', merchantCallbackURL: process.env.BASE_URL + '/api/payment/nagad/callback' })
      });
      const d = await r.json();
      res.json(d);
    } catch (e) { res.status(500).json({ error: 'Nagad create failed: ' + e.message }); }
  });

app.get('/api/payment/nagad/callback', (req, res) => {
  const { order_id, status } = req.query;
  console.log('[Nagad callback]', order_id, status);
  res.redirect(`/?nagad=${status}&oid=${order_id}`);
});

// ── Admin Panel API Routes ──────────────────────────────────────────────
// Check admin status
app.get('/api/auth/check-admin', async (req, res) => {
  try {
    const userId = req.headers['x-user-id'] || req.query.userId;
    const user = userId ? syncStore.users.get(String(userId)) : null;
    const isAdmin = isAdminRequest(req);
    res.json({ isAdmin, user: isAdmin ? (user || { id: userId || 'admin', username: 'Administrator' }) : null });
  } catch (e) {
    res.json({ isAdmin: false, user: null });
  }
});

// Get user sessions (for cross-device sync)
app.get('/api/user/sessions', async (req, res) => {
  try {
    const userId = req.headers['x-user-id'] || req.query.userId;
    if (!userId) return res.status(400).json({ error: 'userId required' });

    const sessions = getUserSessions(userId);
    const sessionDetails = sessions.map(sessionId => {
      const session = sessionData.get(sessionId);
      return {
        sessionId,
        deviceInfo: session?.deviceInfo || {},
        lastActive: session?.lastActive || Date.now(),
        createdAt: session?.createdAt || Date.now()
      };
    });

    res.json({
      success: true,
      userId,
      totalSessions: sessions.length,
      sessions: sessionDetails
    });
  } catch (e) {
    console.error('[UserSessions] Error:', e);
    res.status(500).json({ error: 'Failed to get user sessions', detail: e.message });
  }
});

// Force sync across all user sessions
app.post('/api/user/sync-all', async (req, res) => {
  try {
    const { userId, dataType } = req.body;
    if (!userId) return res.status(400).json({ error: 'userId required' });

    let syncData = {};

    switch (dataType) {
      case 'posts':
        syncData.posts = Array.from(syncStore.posts.values()).filter(p => p.author === userId);
        break;
      case 'points':
        syncData.points = syncStore.points.get(userId);
        break;
      case 'user':
        syncData.user = syncStore.users.get(userId);
        break;
      case 'all':
      default:
        syncData = {
          user: syncStore.users.get(userId),
          points: syncStore.points.get(userId),
          posts: Array.from(syncStore.posts.values()).filter(p => p.author === userId),
          timestamp: Date.now()
        };
    }

    // Broadcast to all sessions
    const successCount = broadcastToAllUserSessions(userId, 'data:sync', syncData);

    res.json({
      success: true,
      synced: true,
      sessionsNotified: successCount,
      dataType,
      timestamp: Date.now()
    });
  } catch (e) {
    console.error('[SyncAll] Error:', e);
    res.status(500).json({ error: 'Sync failed', detail: e.message });
  }
});

// Get dashboard statistics
app.get('/api/admin/dashboard-stats', requireAdmin, async (req, res) => {
  try {
    // In production: get real stats from database
    const pendingWithdrawals = syncStore.backups.filter(x => x.type === 'withdrawal' && x.data?.status === 'pending').length;
    const stats = {
      totalUsers: syncStore.users.size,
      activeUsers: new Set(Array.from(onlineSessions.values()).map(s => s.userId)).size,
      activeSessions: onlineSessions.size,
      totalPosts: syncStore.posts.size,
      reports: syncStore.backups.filter(x => x.type === 'report').length + Array.from(syncStore.posts.values()).filter(p => Number(p.reports || 0) > 0).length,
      pendingWithdrawals,
      totalWithdrawals: syncStore.backups.filter(x => x.type === 'withdrawal').length
    };
    res.json(stats);
  } catch (e) {
    res.status(500).json({ error: 'Failed to load dashboard stats' });
  }
});

// Get all users
app.get('/api/admin/users', requireAdmin, async (req, res) => {
  try {
    const users = Array.from(syncStore.users.values()).map(u => ({
      ...u,
      status: u.deleted ? 'deleted' : u.deactivated ? 'deactivated' : u.disabled ? 'disabled' : 'active'
    }));
    res.json(users);
  } catch (e) {
    res.status(500).json({ error: 'Failed to load users' });
  }
});

// Get specific user
app.get('/api/admin/users/:id', requireAdmin, async (req, res) => {
  try {
    const userId = req.params.id;
    const user = syncStore.users.get(userId);
    if (!user) return res.status(404).json({ error: 'User not found' });
    res.json(user);
  } catch (e) {
    res.status(500).json({ error: 'Failed to load user' });
  }
});

// Admin Login (JWT-based)
app.post('/api/admin/login',
  [
    body('userId').trim().notEmpty().withMessage('userId is required'),
    body('password').trim().notEmpty().withMessage('password is required')
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ error: 'Validation failed', details: errors.array() });
    }

    try {
      const { userId, password } = req.body;

      // Check if it's the admin account
      if (userId === ADMIN_ID && password === ADMIN_PASS) {
        const token = generateAdminToken(userId);
        res.json({
          success: true,
          token,
          userId,
          expiresIn: '24h'
        });
      } else {
        // Check if user exists and is admin
        const user = syncStore.users.get(String(userId));
        if (user && (user.isAdmin || user.is_admin) && user.password === password) {
          const token = generateAdminToken(userId);
          res.json({
            success: true,
            token,
            userId,
            expiresIn: '24h'
          });
        } else {
          res.status(401).json({ error: 'Invalid credentials' });
        }
      }
    } catch (e) {
      res.status(500).json({ error: 'Login failed', detail: e.message });
    }
  }
);

// Deactivate user
app.post('/api/admin/users/:id/deactivate', requireAdmin, async (req, res) => {
  try {
    const userId = req.params.id;
    const user = syncStore.users.get(userId);
    if (!user) return res.status(404).json({ error: 'User not found' });
    user.deactivated = true;
    user.updatedAt = Date.now();
    await persistUser(user).catch(e => console.error('[DeactivateUser] persistUser failed:', e));
    res.json({ success: true, user });
  } catch (e) {
    res.status(500).json({ error: 'Failed to deactivate user' });
  }
});

// Delete user
app.delete('/api/admin/users/:id', requireAdmin, async (req, res) => {
  try {
    const userId = req.params.id;
    const user = syncStore.users.get(userId);
    if (user) {
      user.deleted = true;
      user.deactivated = true;
      user.updatedAt = Date.now();
      await persistUser(user).catch(e => console.error('[DeleteUser] persistUser failed:', e));
    }
    res.json({ success: true });
  } catch (e) {
    res.status(500).json({ error: 'Failed to delete user' });
  }
});

// Get all content
app.get('/api/admin/content', requireAdmin, async (req, res) => {
  try {
    const content = Array.from(syncStore.posts.values()).map(p => ({
      ...p,
      title: p.text || p.type || 'Post',
      status: p.hidden ? 'hidden' : Number(p.reports || 0) > 0 ? 'reported' : 'active',
      mediaUrl: p.file || p.mediaUrl || ''
    }));
    res.json(content);
  } catch (e) {
    res.status(500).json({ error: 'Failed to load content' });
  }
});

// Get specific content
app.get('/api/admin/content/:id', requireAdmin, async (req, res) => {
  try {
    const contentId = req.params.id;
    const content = syncStore.posts.get(contentId);
    if (!content) return res.status(404).json({ error: 'Content not found' });
    res.json(content);
  } catch (e) {
    res.status(500).json({ error: 'Failed to load content' });
  }
});

// Delete content
app.delete('/api/admin/content/:id', requireAdmin, async (req, res) => {
  try {
    const contentId = req.params.id;
    syncStore.posts.delete(contentId);
    res.json({ success: true });
  } catch (e) {
    res.status(500).json({ error: 'Failed to delete content' });
  }
});

// ── Data Persistence API Routes ───────────────────────────────────────────
// Create post (centralized storage for cross-platform sync) - ENHANCED FOR 100% GLOBAL DISTRIBUTION
app.post('/api/posts/create',
  [
    body('post').isObject().withMessage('post object is required'),
    body('post.id').trim().notEmpty().withMessage('post id is required'),
    body('post.author').trim().notEmpty().withMessage('post author is required')
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ error: 'Validation failed', details: errors.array() });
    }

    try {
      const { post } = req.body;

      // Create unified post object with ENHANCED global distribution flags
      const savedPost = {
        ...(syncStore.posts.get(post.id) || {}),
        ...post,
        syncedAt: Date.now(),
        globalDistribution: true, // Ensure global distribution
        visibility: post.visibility || 'public', // Default to public
        published: post.published !== false, // Default to published
        forceGlobal: true, // Force global distribution flag
        distributedTo: ['all'], // Track distribution
        syncStatus: 'complete' // Track sync status
      };

      // Save to unified storage (single source of truth)
      unifiedStorage.setPost(post.id, savedPost);

      // Also save to syncStore for backward compatibility
      syncStore.posts.set(post.id, savedPost);
      await persistPost(savedPost);
      updateIndexes();

      // Also save to file-based permanent storage (Facebook/YouTube style persistence)
      sharedPosts.set(post.id, savedPost);
      savePostsToFile();
      console.log(`[PostCreate] Post ${post.id} saved to all storage systems with FORCE GLOBAL flag`);

      // Invalidate ALL post caches to ensure fresh data for all users
      await RedisCache.delPattern('posts:*');
      await RedisCache.delPattern('feed:*');
      await RedisCache.delPattern('global:*');
      console.log(`[PostCreate] All post caches invalidated for global consistency`);

      // Broadcast to ALL connected users (global feed like Facebook/YouTube/TikTok)
      broadcastToAllConnectedUsers('post:new', { post: savedPost, forceGlobal: true });
      console.log(`[PostCreate] Post ${post.id} broadcasted to ALL connected users globally with FORCE flag`);

      // Also broadcast to all sessions of the author for immediate sync
      if (savedPost.author) {
        broadcastToAllUserSessions(savedPost.author, 'post:created', { post: savedPost, forceGlobal: true });
        console.log(`[PostCreate] Post ${post.id} synced to all sessions of author ${savedPost.author}`);
      }

      // Also notify specific audience
      const author = syncStore.users.get(String(savedPost.author || '')) || {};
      const audience = new Set([...(author.followers || []), ...(author.following || []), ...(author.autoFriends || []), ...(author.forceFollowed || [])]);
      for (const userId of audience) {
        emitToUser(userId, 'notif:receive', { type: 'post', postId: savedPost.id, msg: `${author.name || 'Someone'} created a new post`, forceGlobal: true });
      }

      // Sync to Supabase if available
      if (supabaseState.reachable) {
        try {
          await supabaseReq('posts', 'POST', {
            id: savedPost.id,
            author_id: savedPost.author,
            type: savedPost.type,
            text: savedPost.text,
            file: savedPost.file,
            mimetype: savedPost.mimetype,
            hashtags: savedPost.hashtags,
            liked_by: savedPost.likedBy,
            reactions: savedPost.reactions,
            comments: savedPost.comments,
            views: savedPost.views,
            shares: savedPost.shares,
            pts: savedPost.pts,
            pinned: savedPost.pinned,
            created_at: new Date(savedPost.createdAt).toISOString(),
            visibility: savedPost.visibility,
            is_nft: savedPost.isNFT,
            scheduled_at: savedPost.scheduledAt ? new Date(savedPost.scheduledAt).toISOString() : null,
            published: savedPost.published,
            force_global: true
          });
          console.log(`[PostCreate] Post ${post.id} synced to Supabase with FORCE GLOBAL flag`);
        } catch (e) {
          console.warn('[PostCreate] Supabase sync failed:', e);
        }
      }

      // Sync to PostgreSQL if available
      if (pgPool) {
        try {
          const query = `
            INSERT INTO posts (id, author_id, type, text, file, mimetype, hashtags, visibility, published, force_global, created_at)
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, NOW())
            ON CONFLICT (id) DO UPDATE SET
              text = EXCLUDED.text,
              file = EXCLUDED.file,
              visibility = EXCLUDED.visibility,
              published = EXCLUDED.published,
              force_global = EXCLUDED.force_global
            RETURNING id
          `;
          await pgPool.query(query, [
            savedPost.id,
            savedPost.author,
            savedPost.type,
            savedPost.text,
            savedPost.file,
            savedPost.mimetype,
            JSON.stringify(savedPost.hashtags || []),
            savedPost.visibility,
            savedPost.published,
            true
          ]);
          console.log(`[PostCreate] Post ${post.id} synced to PostgreSQL with FORCE GLOBAL flag`);
        } catch (e) {
          console.warn('[PostCreate] PostgreSQL sync failed:', e);
        }
      }

      res.json({
        success: true,
        synced: true,
        id: post.id,
        totalPosts: unifiedStorage.getAllPosts().length,
        globalDistribution: true,
        forceGlobal: true,
        syncStatus: 'complete',
        message: 'Post created and distributed to all users globally'
      });
    } catch (e) {
      console.error('[PostCreate] Error:', e);
      res.status(500).json({ error: 'Post creation failed', detail: e.message });
    }
  });

// Get all posts (global feed - Facebook style timeline) - ENHANCED FOR 100% GLOBAL DISTRIBUTION
app.get('/api/posts/all', async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 0;
    const limit = parseInt(req.query.limit) || 20;
    const offset = page * limit;
    const contentType = req.query.type || 'all'; // all, text, photo, video, audio
    const userId = req.query.userId; // Optional: for personalized feed
    const forceRefresh = req.query.force === 'true'; // Force cache bypass

    console.log('[PostsAll] Fetching posts - page:', page, 'limit:', limit, 'type:', contentType, 'userId:', userId, 'forceRefresh:', forceRefresh);

    // BYPASS CACHE if forceRefresh is true to ensure 100% fresh data
    if (!forceRefresh) {
      const cacheKey = `posts:all:${page}:${limit}:${contentType}:${userId || 'global'}`;
      const cachedPosts = await RedisCache.get(cacheKey);
      if (cachedPosts && cachedPosts.length > 0) {
        console.log('[PostsAll] Returning cached posts:', cachedPosts.length);
        return res.json({
          success: true,
          posts: cachedPosts,
          cached: true,
          page,
          limit,
          total: cachedPosts.length,
          timestamp: Date.now(),
          globalDistribution: true
        });
      }
    }

    // Use unified storage as single source of truth
    const allPostsMap = new Map();

    // Get all posts from unified storage (single source of truth)
    const unifiedPosts = unifiedStorage.getAllPosts();
    unifiedPosts.forEach(post => {
      if (post && post.id && !allPostsMap.has(post.id)) {
        // FORCE VISIBILITY TO PUBLIC for global distribution
        post.visibility = post.visibility || 'public';
        post.published = post.published !== false; // Default to published
        post.forceGlobal = post.forceGlobal !== false; // Default to force global
        allPostsMap.set(post.id, post);
      }
    });

    // Also add from legacy storage systems for backward compatibility
    sharedPosts.forEach((post, id) => {
      if (post && !allPostsMap.has(id)) {
        post.visibility = post.visibility || 'public';
        post.published = post.published !== false;
        post.forceGlobal = post.forceGlobal !== false;
        allPostsMap.set(id, post);
      }
    });

    syncStore.posts.forEach((post, id) => {
      if (post && !allPostsMap.has(id)) {
        post.visibility = post.visibility || 'public';
        post.published = post.published !== false;
        post.forceGlobal = post.forceGlobal !== false;
        allPostsMap.set(id, post);
      }
    });

    console.log('[PostsAll] Total posts from all sources:', allPostsMap.size);

    // Filter posts with ENHANCED global distribution logic
    let filteredPosts = Array.from(allPostsMap.values())
      .filter(p => {
        // ENHANCED: Only filter out EXPLICITLY private posts (visibility === 'private')
        // Allow all other posts to be shown globally
        if (p.visibility === 'private') return false;

        // Only filter out if explicitly published === false
        if (p.published === false) return false;

        // Filter by content type if specified
        if (contentType !== 'all' && p.type !== contentType && p.category !== contentType) return false;

        // Filter out hidden/reported posts for regular users
        if (p.hidden || (p.reports && p.reports > 5)) return false;

        // ENHANCED: If forceGlobal is true, show regardless of other filters
        if (p.forceGlobal === true) return true;

        return true;
      });

    // Sort by createdAt (timeline style - newest first)
    filteredPosts.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));

    // Apply pagination
    const paginatedPosts = filteredPosts.slice(offset, offset + limit);

    // Enrich posts with author information
    const enrichedPosts = paginatedPosts.map(post => {
      const author = syncStore.users.get(String(post.author || '')) || {};
      return {
        ...post,
        author: {
          id: author.id,
          name: author.name || 'Anonymous',
          username: author.username || 'unknown',
          avatar: author.avatar || author.profilePic || '/icon-192.png',
          verified: author.verified || false,
          isAdmin: author.isAdmin || author.is_admin || false
        },
        engagement: {
          likes: post.likedBy ? post.likedBy.length : 0,
          comments: post.comments || 0,
          shares: post.shares || 0,
          views: post.views || 0
        },
        timeAgo: getTimeAgo(post.createdAt),
        syncedAt: post.syncedAt || null, // Add sync timestamp
        globalDistribution: post.globalDistribution || post.forceGlobal || true, // Ensure global flag
        syncStatus: post.syncStatus || 'complete'
      };
    });

    console.log('[PostsAll] Returning', enrichedPosts.length, 'posts out of', filteredPosts.length, 'total (ENHANCED GLOBAL MODE)');

    // Cache the response for better performance (only if not force refresh)
    if (!forceRefresh) {
      const cacheKey = `posts:all:${page}:${limit}:${contentType}:${userId || 'global'}`;
      await RedisCache.set(cacheKey, enrichedPosts, 30); // Cache for 30 seconds
    }

    res.json({
      success: true,
      posts: enrichedPosts,
      cached: false,
      pagination: {
        page,
        limit,
        total: filteredPosts.length,
        hasMore: offset + limit < filteredPosts.length
      },
      syncStatus: {
        source: 'unified-storage',
        timestamp: Date.now(),
        totalSources: allPostsMap.size,
        filtered: filteredPosts.length,
        returned: enrichedPosts.length,
        globalDistribution: true,
        forceGlobal: true,
        mode: 'enhanced-global-sync'
      },
      globalDistribution: true,
      forceGlobal: true,
      message: 'All posts returned with 100% global distribution enabled'
    });
  } catch (e) {
    console.error('[GetAllPosts] Error:', e);
    res.status(500).json({ error: 'Failed to load posts', detail: e.message });
  }
});

// Helper function to get time ago string
function getTimeAgo(timestamp) {
  if (!timestamp) return 'Just now';

  const seconds = Math.floor((Date.now() - timestamp) / 1000);

  if (seconds < 60) return 'Just now';
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
  if (seconds < 604800) return `${Math.floor(seconds / 86400)}d ago`;
  if (seconds < 2592000) return `${Math.floor(seconds / 604800)}w ago`;
  if (seconds < 31536000) return `${Math.floor(seconds / 2592000)}mo ago`;
  return `${Math.floor(seconds / 31536000)}y ago`;
}

// Enhanced global feed with filtering and personalization - ENHANCED FOR 100% GLOBAL DISTRIBUTION
app.get('/api/feed/global', async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 0;
    const limit = parseInt(req.query.limit) || 20;
    const offset = page * limit;
    const contentType = req.query.type || 'all';
    const sortBy = req.query.sortBy || 'recent'; // recent, popular, trending
    const currentUserId = req.query.userId;
    const forceRefresh = req.query.force === 'true';

    console.log('[FeedGlobal] Fetching global feed - page:', page, 'limit:', limit, 'type:', contentType, 'sortBy:', sortBy, 'forceRefresh:', forceRefresh);

    // Use unified storage as single source of truth
    const allPostsMap = new Map();

    // Get all posts from unified storage (single source of truth)
    const unifiedPosts = unifiedStorage.getAllPosts();
    unifiedPosts.forEach(post => {
      if (post && post.id && !allPostsMap.has(post.id)) {
        // FORCE GLOBAL FLAGS
        post.visibility = post.visibility || 'public';
        post.published = post.published !== false;
        post.forceGlobal = post.forceGlobal !== false;
        allPostsMap.set(post.id, post);
      }
    });

    // Also add from legacy storage systems for backward compatibility
    sharedPosts.forEach((post, id) => {
      if (post && !allPostsMap.has(id)) {
        post.visibility = post.visibility || 'public';
        post.published = post.published !== false;
        post.forceGlobal = post.forceGlobal !== false;
        allPostsMap.set(id, post);
      }
    });

    syncStore.posts.forEach((post, id) => {
      if (post && !allPostsMap.has(id)) {
        post.visibility = post.visibility || 'public';
        post.published = post.published !== false;
        post.forceGlobal = post.forceGlobal !== false;
        allPostsMap.set(id, post);
      }
    });

    console.log('[FeedGlobal] Total posts from all sources:', allPostsMap.size);

    // Filter and prepare posts with ENHANCED global distribution logic
    let feedPosts = Array.from(allPostsMap.values())
      .filter(p => {
        // ENHANCED: Only filter out EXPLICITLY private posts
        if (p.visibility === 'private') return false;

        // Only filter out if explicitly published === false
        if (p.published === false) return false;

        // Filter by content type if specified
        if (contentType !== 'all' && p.type !== contentType && p.category !== contentType) return false;

        // Filter out hidden/reported posts
        if (p.hidden || (p.reports && p.reports > 5)) return false;

        // ENHANCED: If forceGlobal is true, show regardless
        if (p.forceGlobal === true) return true;

        return true;
      })
      .map(post => {
        const author = syncStore.users.get(String(post.author || '')) || {};
        return {
          ...post,
          authorInfo: {
            id: author.id,
            name: author.name || 'Anonymous',
            username: author.username || 'unknown',
            avatar: author.avatar || author.profilePic || '/icon-192.png',
            verified: author.verified || false,
            isAdmin: author.isAdmin || author.is_admin || false
          },
          engagement: {
            likes: post.likedBy ? post.likedBy.length : 0,
            comments: post.comments || 0,
            shares: post.shares || 0,
            views: post.views || 0
          },
          globalDistribution: post.globalDistribution || post.forceGlobal || true,
          syncStatus: post.syncStatus || 'complete'
        };
      });

    // Sort based on preference
    switch (sortBy) {
      case 'popular':
        feedPosts.sort((a, b) => b.engagement.likes - a.engagement.likes);
        break;
      case 'trending':
        // Trending = recent + high engagement
        const now = Date.now();
        feedPosts.sort((a, b) => {
          const aAge = (now - (a.createdAt || 0)) / 3600000; // hours
          const bAge = (now - (b.createdAt || 0)) / 3600000;
          const aScore = a.engagement.likes / Math.max(1, aAge);
          const bScore = b.engagement.likes / Math.max(1, bAge);
          return bScore - aScore;
        });
        break;
      case 'recent':
      default:
        feedPosts.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
        break;
    }

    // Apply pagination
    const paginatedPosts = feedPosts.slice(offset, offset + limit);

    console.log('[FeedGlobal] Returning', paginatedPosts.length, 'posts out of', feedPosts.length, 'total (ENHANCED GLOBAL MODE)');

    res.json({
      success: true,
      feed: paginatedPosts,
      pagination: {
        page,
        limit,
        total: feedPosts.length,
        hasMore: offset + limit < feedPosts.length
      },
      filters: {
        contentType,
        sortBy
      },
      syncStatus: {
        source: 'unified-storage',
        timestamp: Date.now(),
        totalSources: allPostsMap.size,
        filtered: feedPosts.length,
        returned: paginatedPosts.length,
        globalDistribution: true,
        forceGlobal: true,
        mode: 'enhanced-global-sync'
      },
      globalDistribution: true,
      forceGlobal: true,
      message: 'Global feed returned with 100% global distribution enabled'
    });
  } catch (e) {
    console.error('[GlobalFeed] Error:', e);
    res.status(500).json({ error: 'Failed to load global feed', detail: e.message });
  }
});

// Real-time feed updates endpoint
app.get('/api/feed/updates', async (req, res) => {
  try {
    const since = parseInt(req.query.since) || 0;
    const currentUserId = req.query.userId;

    // Get posts created since the timestamp
    const newPosts = [];

    const allPostsMap = new Map();

    // Use unified storage as primary source
    const unifiedPosts = unifiedStorage.getAllPosts();
    unifiedPosts.forEach(post => allPostsMap.set(post.id, post));

    // Also check legacy storage for backward compatibility
    sharedPosts.forEach((post, id) => allPostsMap.set(id, post));
    syncStore.posts.forEach((post, id) => {
      if (!allPostsMap.has(id)) allPostsMap.set(id, post);
    });

    allPostsMap.forEach((post) => {
      if ((post.createdAt || 0) > since &&
        post.published !== false &&
        post.visibility !== 'private' &&
        !post.hidden) {
        const author = syncStore.users.get(String(post.author || '')) || {};
        newPosts.push({
          ...post,
          authorInfo: {
            id: author.id,
            name: author.name || 'Anonymous',
            username: author.username || 'unknown',
            avatar: author.avatar || author.profilePic || '/icon-192.png'
          }
        });
      }
    });

    // Sort by newest first
    newPosts.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));

    res.json({
      success: true,
      updates: newPosts,
      count: newPosts.length,
      timestamp: Date.now(),
      globalDistribution: true
    });
  } catch (e) {
    console.error('[FeedUpdates] Error:', e);
    res.status(500).json({ error: 'Failed to get feed updates', detail: e.message });
  }
});

// Force Sync Endpoint - 100% GLOBAL DISTRIBUTION GUARANTEE
// This endpoint ensures all posts are globally distributed to all users
app.post('/api/posts/force-sync', async (req, res) => {
  try {
    const { postId, userId, action = 'sync' } = req.body;

    console.log('[ForceSync] Force sync request - postId:', postId, 'userId:', userId, 'action:', action);

    // Invalidate ALL caches to ensure fresh data
    await RedisCache.delPattern('posts:*');
    await RedisCache.delPattern('feed:*');
    await RedisCache.delPattern('global:*');
    console.log('[ForceSync] All caches invalidated');

    if (action === 'sync' && postId) {
      // Sync specific post globally
      const allPostsMap = new Map();

      // Get post from all storage systems
      const unifiedPosts = unifiedStorage.getAllPosts();
      unifiedPosts.forEach(post => {
        if (post && post.id && !allPostsMap.has(post.id)) {
          post.visibility = post.visibility || 'public';
          post.published = post.published !== false;
          post.forceGlobal = true;
          allPostsMap.set(post.id, post);
        }
      });

      sharedPosts.forEach((post, id) => {
        if (post && !allPostsMap.has(id)) {
          post.visibility = post.visibility || 'public';
          post.published = post.published !== false;
          post.forceGlobal = true;
          allPostsMap.set(id, post);
        }
      });

      syncStore.posts.forEach((post, id) => {
        if (post && !allPostsMap.has(id)) {
          post.visibility = post.visibility || 'public';
          post.published = post.published !== false;
          post.forceGlobal = true;
          allPostsMap.set(id, post);
        }
      });

      const post = allPostsMap.get(postId);
      if (post) {
        // Update post with force global flags
        post.forceGlobal = true;
        post.globalDistribution = true;
        post.syncStatus = 'complete';
        post.syncedAt = Date.now();

        // Save to all storage systems
        unifiedStorage.setPost(postId, post);
        syncStore.posts.set(postId, post);
        sharedPosts.set(postId, post);
        await persistPost(post);
        savePostsToFile();

        // Broadcast to ALL connected users
        broadcastToAllConnectedUsers('post:force-synced', { post, forceGlobal: true });
        console.log('[ForceSync] Post', postId, 'force synced to all users globally');

        res.json({
          success: true,
          action: 'sync',
          postId,
          globalDistribution: true,
          forceGlobal: true,
          message: 'Post force synced to all users globally'
        });
      } else {
        res.status(404).json({ error: 'Post not found' });
      }
    } else if (action === 'sync-all') {
      // Sync ALL posts globally
      const allPostsMap = new Map();

      // Get all posts from all storage systems
      const unifiedPosts = unifiedStorage.getAllPosts();
      unifiedPosts.forEach(post => {
        if (post && post.id && !allPostsMap.has(post.id)) {
          post.visibility = post.visibility || 'public';
          post.published = post.published !== false;
          post.forceGlobal = true;
          allPostsMap.set(post.id, post);
        }
      });

      sharedPosts.forEach((post, id) => {
        if (post && !allPostsMap.has(id)) {
          post.visibility = post.visibility || 'public';
          post.published = post.published !== false;
          post.forceGlobal = true;
          allPostsMap.set(id, post);
        }
      });

      syncStore.posts.forEach((post, id) => {
        if (post && !allPostsMap.has(id)) {
          post.visibility = post.visibility || 'public';
          post.published = post.published !== false;
          post.forceGlobal = true;
          allPostsMap.set(id, post);
        }
      });

      // Update all posts with force global flags
      let syncedCount = 0;
      for (const [postId, post] of allPostsMap) {
        post.forceGlobal = true;
        post.globalDistribution = true;
        post.syncStatus = 'complete';
        post.syncedAt = Date.now();

        unifiedStorage.setPost(postId, post);
        syncStore.posts.set(postId, post);
        sharedPosts.set(postId, post);
        syncedCount++;
      }

      await persistAllPosts();
      savePostsToFile();

      // Broadcast to ALL connected users
      broadcastToAllConnectedUsers('posts:force-synced-all', { count: syncedCount, forceGlobal: true });
      console.log('[ForceSync] All', syncedCount, 'posts force synced globally');

      res.json({
        success: true,
        action: 'sync-all',
        syncedCount,
        globalDistribution: true,
        forceGlobal: true,
        message: `All ${syncedCount} posts force synced to all users globally`
      });
    } else {
      res.status(400).json({ error: 'Invalid action. Use "sync" or "sync-all"' });
    }
  } catch (e) {
    console.error('[ForceSync] Error:', e);
    res.status(500).json({ error: 'Force sync failed', detail: e.message });
  }
});

// Global Sync Verification Endpoint - 100% GLOBAL DISTRIBUTION VERIFICATION
// This endpoint verifies that all posts are properly distributed globally
app.get('/api/posts/verify-global-sync', async (req, res) => {
  try {
    console.log('[VerifyGlobalSync] Starting global sync verification...');

    // Get all posts from all storage systems
    const allPostsMap = new Map();

    // Get from unified storage
    const unifiedPosts = unifiedStorage.getAllPosts();
    unifiedPosts.forEach(post => {
      if (post && post.id) {
        post.visibility = post.visibility || 'public';
        post.published = post.published !== false;
        post.forceGlobal = post.forceGlobal !== false;
        allPostsMap.set(post.id, post);
      }
    });

    // Get from sharedPosts
    sharedPosts.forEach((post, id) => {
      if (post) {
        post.visibility = post.visibility || 'public';
        post.published = post.published !== false;
        post.forceGlobal = post.forceGlobal !== false;
        allPostsMap.set(id, post);
      }
    });

    // Get from syncStore
    syncStore.posts.forEach((post, id) => {
      if (post) {
        post.visibility = post.visibility || 'public';
        post.published = post.published !== false;
        post.forceGlobal = post.forceGlobal !== false;
        allPostsMap.set(id, post);
      }
    });

    const totalPosts = allPostsMap.size;
    let publicPosts = 0;
    let privatePosts = 0;
    let forceGlobalPosts = 0;
    let publishedPosts = 0;
    let unpublishedPosts = 0;

    // Analyze posts
    for (const [postId, post] of allPostsMap) {
      if (post.visibility === 'public') publicPosts++;
      if (post.visibility === 'private') privatePosts++;
      if (post.forceGlobal === true) forceGlobalPosts++;
      if (post.published !== false) publishedPosts++;
      if (post.published === false) unpublishedPosts++;
    }

    // Calculate global distribution percentage
    const globalDistributionPercentage = totalPosts > 0 ? ((publicPosts + forceGlobalPosts) / totalPosts) * 100 : 100;

    // Check if any posts need fixing
    const postsNeedingFix = [];
    for (const [postId, post] of allPostsMap) {
      if (post.visibility !== 'public' || post.published === false || post.forceGlobal !== true) {
        postsNeedingFix.push({
          id: postId,
          visibility: post.visibility,
          published: post.published,
          forceGlobal: post.forceGlobal
        });
      }
    }

    // Auto-fix posts if requested
    const autoFix = req.query.autofix === 'true';
    let fixedCount = 0;

    if (autoFix && postsNeedingFix.length > 0) {
      console.log('[VerifyGlobalSync] Auto-fixing', postsNeedingFix.length, 'posts for global distribution...');

      for (const postInfo of postsNeedingFix) {
        const post = allPostsMap.get(postInfo.id);
        if (post) {
          post.visibility = 'public';
          post.published = true;
          post.forceGlobal = true;
          post.globalDistribution = true;
          post.syncStatus = 'complete';
          post.syncedAt = Date.now();

          // Save to all storage systems
          unifiedStorage.setPost(post.id, post);
          syncStore.posts.set(post.id, post);
          sharedPosts.set(post.id, post);
          await persistPost(post);
          fixedCount++;
        }
      }

      savePostsToFile();
      await RedisCache.delPattern('posts:*');
      await RedisCache.delPattern('feed:*');
      await RedisCache.delPattern('global:*');

      console.log('[VerifyGlobalSync] Fixed', fixedCount, 'posts for global distribution');
    }

    res.json({
      success: true,
      verification: {
        timestamp: Date.now(),
        totalPosts,
        publicPosts,
        privatePosts,
        forceGlobalPosts,
        publishedPosts,
        unpublishedPosts,
        globalDistributionPercentage: globalDistributionPercentage.toFixed(2),
        postsNeedingFix: postsNeedingFix.length,
        autoFixed: autoFix ? fixedCount : 0
      },
      status: globalDistributionPercentage >= 99 ? 'EXCELLENT' : globalDistributionPercentage >= 90 ? 'GOOD' : 'NEEDS_FIX',
      message: globalDistributionPercentage >= 99
        ? '100% Global distribution verified - all posts are properly distributed globally'
        : `Global distribution at ${globalDistributionPercentage.toFixed(2)}% - some posts may not be visible to all users`,
      recommendations: postsNeedingFix.length > 0
        ? `Run with ?autofix=true to fix ${postsNeedingFix.length} posts for global distribution`
        : 'All posts are properly configured for global distribution'
    });
  } catch (e) {
    console.error('[VerifyGlobalSync] Error:', e);
    res.status(500).json({ error: 'Verification failed', detail: e.message });
  }
});

// Sync posts (legacy endpoint for backward compatibility) - enhanced for global sync
app.post('/api/posts/sync', requireCSRF,
  [
    body('id').trim().notEmpty().withMessage('Post id is required'),
    body('author').trim().notEmpty().withMessage('Author is required')
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ error: 'Validation failed', details: errors.array() });
    }

    try {
      const postData = req.body;

      // Ensure global visibility and sync properties
      const enhancedPost = {
        ...(syncStore.posts.get(postData.id) || {}),
        ...postData,
        visibility: postData.visibility || 'public', // Default to public for global visibility
        global: true,
        globalDistribution: true, // Ensure global distribution flag
        syncedAt: Date.now(),
        distributedAt: Date.now()
      };

      // Save to all storage systems for consistency
      syncStore.posts.set(enhancedPost.id, enhancedPost);
      sharedPosts.set(enhancedPost.id, enhancedPost);
      unifiedStorage.setPost(enhancedPost.id, enhancedPost);

      await persistPost(enhancedPost);
      savePostsToFile(); // Ensure file persistence
      updateIndexes();

      // Invalidate cache to force fresh data
      RedisCache.delPattern('global:posts:*').catch(e =>
        console.warn('[SyncPosts] Failed to invalidate cache:', e)
      );

      // Broadcast to ALL connected clients for real-time global sync
      broadcastToAllConnectedUsers('post:new', { post: enhancedPost, source: 'sync', timestamp: Date.now() });

      // Also broadcast to author's all sessions for cross-device sync
      broadcastToAllUserSessions(enhancedPost.author, 'post:synced', { post: enhancedPost, timestamp: Date.now() });

      // Notify followers
      const author = syncStore.users.get(String(enhancedPost.author || '')) || {};
      const audience = new Set([
        ...(author.followers || []),
        ...(author.following || []),
        ...(author.autoFriends || []),
        ...(author.forceFollowed || [])
      ]);

      for (const userId of audience) {
        emitToUser(userId, 'notif:receive', {
          type: 'post',
          postId: enhancedPost.id,
          msg: `${author.name || 'Someone'} created a new post`,
          timestamp: Date.now()
        });
      }

      const persisted = supabaseState.reachable;
      console.log(`[Sync] Post synced globally: ${enhancedPost.id} by ${enhancedPost.author}, visibility: ${enhancedPost.visibility}`);

      res.json({
        success: true,
        synced: true,
        persisted,
        fallback: !persisted,
        id: enhancedPost.id,
        totalPosts: syncStore.posts.size,
        globalDistribution: true,
        visibility: enhancedPost.visibility,
        timestamp: Date.now()
      });
    } catch (e) {
      console.error('[SyncPosts] Error:', e);
      res.status(500).json({ error: 'Post sync failed', detail: e.message });
    }
  });

// Client state is not an authoritative source for balances.
app.post('/api/points/sync', requireSupabaseUser, (_req, res) => {
  res.status(501).json({ error: 'Points sync is disabled until server-authoritative ledger support is available' });
});

// Sync user data - enhanced for cross-device consistency
app.post('/api/user-data/sync', async (req, res) => {
  try {
    const userData = req.body;
    const uid = userData.id || userData.userId || userData.key;
    if (!uid) return res.status(400).json({ error: 'user id required' });

    const mergedUser = mergeAccountIntoCanonical(userData);
    const canonicalId = mergedUser.id;
    const prev = syncStore.users.get(canonicalId) || {};
    const pointState = syncStore.points.get(canonicalId);
    const persistent = await getPersistentUser(uid).catch(() => null);

    // Merge points from all sources (maximum to prevent data loss)
    const mergedPoints = Math.max(
      Number(prev.points || 0),
      Number(userData.points || 0),
      Number(pointState?.points || 0),
      Number(persistent?.points || 0)
    );

    // Merge money from all sources (maximum to prevent data loss)
    const mergedMoney = Math.max(
      Number(prev.money || 0),
      Number(userData.money || 0),
      Number(persistent?.money || 0)
    );

    // Merge user data with server data (server takes precedence for consistency)
    const updatedUser = {
      ...prev,
      ...userData,
      points: mergedPoints,
      money: mergedMoney,
      posts: userData.posts || prev.posts || [],
      followers: [...new Set([...(prev.followers || []), ...(userData.followers || [])])],
      following: [...new Set([...(prev.following || []), ...(userData.following || [])])],
      autoFriends: [...new Set([...(prev.autoFriends || []), ...(userData.autoFriends || [])])],
      forceFollowed: [...new Set([...(prev.forceFollowed || []), ...(userData.forceFollowed || [])])],
      updatedAt: Date.now(),
      lastSync: Date.now(),
      syncedAt: Date.now(),
      crossDeviceSync: true // Mark as cross-device synced
    };

    // Update all storage systems for consistency
    syncStore.users.set(canonicalId, updatedUser);
    unifiedStorage.setUser(canonicalId, updatedUser);
    sharedUsers.set(canonicalId, updatedUser);
    saveUsersToFile(); // Persist to disk

    // Update points in all storage systems
    syncStore.points.set(canonicalId, {
      points: mergedPoints,
      money: mergedMoney,
      updatedAt: Date.now(),
      syncedAt: Date.now()
    });

    // Also update legacy points storage
    const mergedPointsData = {
      points: mergedPoints,
      money: mergedMoney,
      updatedAt: Date.now(),
      syncedAt: Date.now()
    };
    syncStore.points.set(canonicalId, mergedPointsData);

    // Invalidate user cache
    RedisCache.invalidateUserCache(canonicalId).catch(e =>
      console.warn('[UserSync] Failed to invalidate cache:', e)
    );

    // Broadcast to all connected sessions of this user for real-time cross-device sync
    emitToUser(canonicalId, 'user:synced', {
      user: updatedUser,
      points: mergedPoints,
      money: mergedMoney,
      timestamp: Date.now()
    });

    console.log('[UserSync] User data synced across all devices:', canonicalId, 'points:', mergedPoints, 'money:', mergedMoney);

    await persistUser(updatedUser).catch(e => console.error('[SyncUser] persistUser failed:', e));
    await setPersistentPoints(canonicalId, mergedPoints).catch(e => console.error('[SyncUser] setPersistentPoints failed:', e));

    res.json({
      success: true,
      synced: true,
      userId: canonicalId,
      points: mergedPoints,
      money: mergedMoney,
      crossDeviceSync: true,
      timestamp: Date.now()
    });
  } catch (e) {
    console.error('[UserSync] Error:', e);
    res.status(500).json({ error: 'User sync failed', detail: e.message });
  }
});

// Get user data (for cross-platform sync)
app.get('/api/users/:id', async (req, res) => {
  try {
    const userId = req.params.id;
    // Use file-based permanent storage for persistence (Facebook/YouTube style)
    const user = sharedUsers.get(userId) || syncStore.users.get(userId);
    if (!user) return res.status(404).json({ error: 'User not found' });

    const points = syncStore.points.get(userId)?.points || user.points || 0;

    res.json({
      success: true,
      user: {
        id: user.id,
        name: user.name,
        username: user.username,
        email: user.email,
        phone: user.phone,
        points: points,
        money: user.money || 0,
        posts: user.posts || [],
        followers: user.followers || [],
        following: user.following || [],
        autoFriends: user.autoFriends || [],
        forceFollowed: user.forceFollowed || [],
        avatar: user.avatar,
        bio: user.bio,
        isAdmin: user.isAdmin || user.is_admin || false,
        createdAt: user.createdAt,
        lastLogin: user.lastLogin,
        lastActive: user.lastActive
      },
      points: points
    });
  } catch (e) {
    console.error('[GetUser] Error:', e);
    res.status(500).json({ error: 'Failed to load user', detail: e.message });
  }
});

// Sync apps (for cross-platform consistency)
app.post('/api/apps/sync', async (req, res) => {
  try {
    const { apps, userId } = req.body;
    if (!userId) return res.status(400).json({ error: 'userId required' });

    // Store apps in syncStore
    if (!syncStore.apps) syncStore.apps = new Map();

    if (Array.isArray(apps)) {
      apps.forEach(app => {
        if (app && app.id) {
          const existing = syncStore.apps.get(app.id) || {};
          syncStore.apps.set(app.id, { ...existing, ...app, syncedAt: Date.now() });
        }
      });
    }

    // Broadcast new apps to all connected users (global feed like Facebook/YouTube/TikTok)
    if (Array.isArray(apps)) {
      apps.forEach(app => {
        if (app && app.id) {
          io.emit('app:new', { app });
          console.log(`[AppSync] App ${app.id} broadcasted to all connected users`);
        }
      });
    }

    // Sync to Supabase if available
    if (supabaseState.reachable && Array.isArray(apps)) {
      try {
        for (const app of apps) {
          if (app && app.id) {
            await supabaseReq('apps', 'POST', {
              id: app.id,
              name: app.name,
              link: app.link,
              desc: app.description || app.desc,
              icon: app.icon,
              version: app.version,
              category: app.category,
              store_type: app.storeType,
              store_label: app.storeLabel,
              store_icon: app.storeIcon,
              screenshots: app.screenshots,
              uploaded_by: app.uploadedBy,
              uploaded_at: new Date(app.uploadedAt).toISOString(),
              status: app.status,
              installed_by: app.installedBy,
              rating: app.rating,
              total_installs: app.totalInstalls,
              has_file: app.hasFile,
              file_name: app.fileName
            });
          }
        }
        console.log('[AppSync] Apps synced to Supabase');
      } catch (e) {
        console.warn('[AppSync] Supabase sync failed:', e);
      }
    }

    res.json({ success: true, synced: true, totalApps: syncStore.apps.size });
  } catch (e) {
    console.error('[AppSync] Error:', e);
    res.status(500).json({ error: 'App sync failed', detail: e.message });
  }
});

// Get all apps (global apps feed)
app.get('/api/apps/all', async (req, res) => {
  try {
    const allApps = Array.from(syncStore.apps?.values() || [])
      .filter(a => a.status !== 'deleted' && a.status !== 'rejected')
      .sort((a, b) => (b.uploadedAt || 0) - (a.uploadedAt || 0))
      .slice(0, 100);

    res.json({ success: true, apps: allApps, total: allApps.length });
  } catch (e) {
    console.error('[GetAllApps] Error:', e);
    res.status(500).json({ error: 'Failed to load apps', detail: e.message });
  }
});

// Sync media files (for cross-platform consistency of videos, audio, photos)
app.post('/api/media/sync', async (req, res) => {
  try {
    const { media, userId } = req.body;
    if (!userId) return res.status(400).json({ error: 'userId required' });

    // Store media in syncStore
    if (!syncStore.media) syncStore.media = new Map();

    if (Array.isArray(media)) {
      media.forEach(m => {
        if (m && m.id) {
          const existing = syncStore.media.get(m.id) || {};
          syncStore.media.set(m.id, { ...existing, ...m, syncedAt: Date.now() });

          // Also save to file-based permanent storage (Facebook/YouTube style persistence)
          sharedMedia.set(m.id, { ...existing, ...m, syncedAt: Date.now() });
        }
      });
      saveMediaToFile();
      console.log(`[MediaSync] ${media.length} media items saved to permanent file storage`);
    }

    // Broadcast new media to all connected users (global feed like Facebook/YouTube/TikTok)
    if (Array.isArray(media)) {
      media.forEach(m => {
        if (m && m.id) {
          io.emit('media:new', { media: m });
          console.log(`[MediaSync] Media ${m.id} broadcasted to all connected users`);
        }
      });
    }

    // Sync to Supabase if available
    if (supabaseState.reachable && Array.isArray(media)) {
      try {
        for (const m of media) {
          if (m && m.id) {
            await supabaseReq('media', 'POST', {
              id: m.id,
              post_id: m.postId,
              type: m.type,
              mimetype: m.mimetype,
              file: m.file,
              file_name: m.fileName,
              uploaded_by: userId,
              uploaded_at: new Date(m.uploadedAt || Date.now()).toISOString()
            });
          }
        }
        console.log('[MediaSync] Media synced to Supabase');
      } catch (e) {
        console.warn('[MediaSync] Supabase sync failed:', e);
      }
    }

    res.json({ success: true, synced: true, totalMedia: syncStore.media.size });
  } catch (e) {
    console.error('[MediaSync] Error:', e);
    res.status(500).json({ error: 'Media sync failed', detail: e.message });
  }
});

// Get all media (global media feed)
app.get('/api/media/all', async (req, res) => {
  try {
    // Use file-based permanent storage for persistence (Facebook/YouTube style)
    const allMedia = Array.from(sharedMedia.values())
      .sort((a, b) => (b.uploadedAt || 0) - (a.uploadedAt || 0))
      .slice(0, 200);

    // Also sync with in-memory store for real-time updates
    syncStore.media?.forEach((media, id) => {
      if (!sharedMedia.has(id)) {
        sharedMedia.set(id, media);
      }
    });

    res.json({ success: true, media: allMedia, total: allMedia.length });
  } catch (e) {
    console.error('[GetAllMedia] Error:', e);
    res.status(500).json({ error: 'Failed to load media', detail: e.message });
  }
});

app.post('/api/account/deactivate', requireAdmin, async (req, res) => {
  try {
    const { userId } = req.body || {};
    if (!userId) return res.status(400).json({ error: 'userId required' });
    const user = syncStore.users.get(userId) || await getPersistentUser(userId).catch(() => null);
    if (!user) return res.status(404).json({ error: 'User not found' });
    user.deactivated = true;
    user.updatedAt = Date.now();
    syncStore.users.set(userId, user);
    await persistUser(user).catch(e => console.error('[DeactivateAccount] persistUser failed:', e));
    res.json({ success: true, userId });
  } catch (e) {
    res.status(500).json({ error: 'Deactivate failed', detail: e.message });
  }
});

app.delete('/api/account/:id', requireAdmin, async (req, res) => {
  try {
    const userId = req.params.id;
    const user = syncStore.users.get(userId) || {};
    user.id = userId;
    user.deleted = true;
    user.deactivated = true;
    user.updatedAt = Date.now();
    syncStore.users.set(userId, user);
    syncStore.points.delete(userId);
    for (const [postId, post] of syncStore.posts) if (post.author === userId) syncStore.posts.delete(postId);
    await persistUser(user).catch(e => console.error('[DeleteAccount] persistUser failed:', e));
    res.json({ success: true, userId });
  } catch (e) {
    res.status(500).json({ error: 'Delete account failed', detail: e.message });
  }
});

app.post('/api/reports', async (req, res) => {
  try {
    const { from, postId = '', message = '', type = 'feedback' } = req.body || {};
    if (!from || !message) return res.status(400).json({ error: 'from and message required' });
    const report = { id: 'rep_' + Date.now() + '_' + crypto.randomBytes(3).toString('hex'), from, postId, message, type, status: 'open', at: Date.now() };
    syncStore.backups.unshift({ id: report.id, at: Date.now(), type: 'report', data: report });
    if (postId && syncStore.posts.has(postId)) {
      const post = syncStore.posts.get(postId);
      post.reports = Number(post.reports || 0) + 1;
      post.updatedAt = Date.now();
      await persistPost(post).catch(e => console.error('[ReportPost] persistPost failed:', e));
    }
    res.json({ success: true, report });
  } catch (e) {
    res.status(500).json({ error: 'Report failed', detail: e.message });
  }
});

app.post('/api/ledger/credit', async (req, res) => {
  try {
    const { userId, pts, label = 'Server credit', type = 'earn', id } = req.body || {};
    if (!userId || !Number.isFinite(Number(pts))) return res.status(400).json({ error: 'userId and pts required' });
    const result = await creditUserPoints(userId, pts, label, type, id || `${type}_${userId}_${Date.now()}`);
    res.json({ success: true, ...result });
  } catch (e) {
    res.status(500).json({ error: 'Credit failed', detail: e.message });
  }
});

app.post('/api/withdrawals/request', async (req, res) => {
  try {
    const { userId, amount, method = 'bkash', account = '' } = req.body || {};
    const amt = Math.trunc(Number(amount || 0));
    if (!userId || amt <= 0 || !account) return res.status(400).json({ error: 'userId, amount and account required' });
    let user = null;
    let persistentReady = true;
    try {
      user = await getPersistentUser(userId);
    } catch (e) {
      persistentReady = false;
      user = syncStore.users.get(userId) || null;
    }
    if (!user) return res.status(404).json({ error: 'User not found' });
    if (!(user.kyc_verified || user.kycVerified)) return res.status(403).json({ error: 'KYC verification required' });
    if (Number(user.points || 0) < amt) return res.status(400).json({ error: 'Insufficient points' });
    const wd = { id: 'wd_' + Date.now() + '_' + crypto.randomBytes(4).toString('hex'), user_id: userId, amount: amt, method, account, status: 'pending', created_at: new Date().toISOString() };
    if (persistentReady) {
      await supabaseRest('withdrawals', 'POST', wd, 'on_conflict=id', 'resolution=ignore-duplicates,return=representation');
      await creditUserPoints(userId, -amt, `Withdrawal request via ${method}`, 'withdraw', 'withdraw_' + wd.id);
    } else {
      const nextPoints = Math.max(0, Number(user.points || 0) - amt);
      user.points = nextPoints;
      syncStore.users.set(userId, user);
      syncStore.points.set(userId, {
        ...(syncStore.points.get(userId) || {}),
        points: nextPoints,
        updatedAt: Date.now(),
        history: [...(syncStore.points.get(userId)?.history || []).slice(-49), { points: -amt, label: `Withdrawal request via ${method}`, at: Date.now() }]
      });
    }
    syncStore.backups.unshift({ id: wd.id, at: Date.now(), type: 'withdrawal', data: wd });
    res.json({ success: true, withdrawal: wd, persisted: persistentReady, fallback: !persistentReady });
  } catch (e) {
    res.status(500).json({ error: 'Withdrawal request failed', detail: e.message });
  }
});

app.get('/api/admin/withdrawals', requireAdmin, async (req, res) => {
  try {
    let rows = [];
    try {
      rows = await supabaseRest('withdrawals', 'GET', null, 'select=*&order=created_at.desc&limit=200');
    } catch (e) {
      rows = syncStore.backups.filter(x => x.type === 'withdrawal').map(x => x.data).sort((a, b) => new Date(b.created_at || 0) - new Date(a.created_at || 0));
    }
    res.json({ success: true, withdrawals: rows });
  } catch (e) {
    res.status(500).json({ error: 'Failed to load withdrawals', detail: e.message });
  }
});

app.post('/api/admin/withdrawals/:id/:action', requireAdmin, async (req, res) => {
  try {
    const { id, action } = req.params;
    if (!['approve', 'reject'].includes(action)) return res.status(400).json({ error: 'action must be approve or reject' });
    const status = action === 'approve' ? 'approved' : 'rejected';
    const stamp = action === 'approve' ? 'approved_at' : 'rejected_at';
    let wd = null;
    try {
      const rows = await supabaseRest('withdrawals', 'GET', null, `id=eq.${encodeURIComponent(id)}&select=*`);
      wd = Array.isArray(rows) ? rows[0] : null;
      if (!wd) return res.status(404).json({ error: 'Withdrawal not found' });
      await supabaseRest('withdrawals', 'PATCH', { status, [stamp]: new Date().toISOString() }, `id=eq.${encodeURIComponent(id)}`, 'return=representation');
      if (action === 'reject') await creditUserPoints(wd.user_id, Number(wd.amount || 0), 'Withdrawal rejected refund', 'withdraw_refund', 'refund_' + id);
    } catch (e) {
      const entry = syncStore.backups.find(x => x.type === 'withdrawal' && x.id === id);
      wd = entry?.data;
      if (!wd) return res.status(404).json({ error: 'Withdrawal not found' });
      wd.status = status;
      wd[stamp] = new Date().toISOString();
      if (action === 'reject') {
        const user = syncStore.users.get(wd.user_id);
        if (user) {
          user.points = Number(user.points || 0) + Number(wd.amount || 0);
          syncStore.users.set(wd.user_id, user);
          syncStore.points.set(wd.user_id, { ...(syncStore.points.get(wd.user_id) || {}), points: user.points, updatedAt: Date.now() });
        }
      }
    }
    res.json({ success: true, withdrawal: { ...wd, status } });
  } catch (e) {
    res.status(500).json({ error: 'Withdrawal update failed', detail: e.message });
  }
});

// Sync media
app.post('/api/media/sync', async (req, res) => {
  try {
    const mediaData = req.body;
    if (!mediaData || !mediaData.id) return res.status(400).json({ error: 'media id required' });
    syncStore.media.set(mediaData.id, { ...(syncStore.media.get(mediaData.id) || {}), ...mediaData, syncedAt: Date.now() });
    supabaseRest('media_objects', 'POST', {
      id: mediaData.id,
      user_id: mediaData.userId || mediaData.user_id || null,
      post_id: mediaData.postId || mediaData.post_id || null,
      provider: mediaData.provider || 'local',
      url: mediaData.url || mediaData.data || '',
      mime: mediaData.type || mediaData.mime || '',
      size: Math.trunc(Number(mediaData.size || 0)),
      created_at: new Date(mediaData.at || Date.now()).toISOString()
    }, 'on_conflict=id', 'resolution=merge-duplicates,return=representation').catch(e => console.error('[SyncMedia] Supabase insert failed:', e));
    console.log(`[Sync] Media: ${mediaData.id} - ${mediaData.type}`);
    res.json({ success: true, synced: true, id: mediaData.id, storage: 'indexed-memory' });
  } catch (e) {
    res.status(500).json({ error: 'Media sync failed' });
  }
});

// Get sync status
app.get('/api/sync/status', async (req, res) => {
  try {
    const supabaseHealthy = await probeSupabaseConnectivity();
    res.json({
      lastSyncTime: Date.now(),
      pendingItems: 0,
      syncEnabled: true,
      persistenceMode: supabaseHealthy ? 'supabase' : 'local-fallback',
      supabase: {
        configured: supabaseState.configured,
        reachable: supabaseState.reachable,
        checkedAt: supabaseState.checkedAt,
        lastError: supabaseState.lastError,
        fallbackMode: supabaseState.fallbackMode,
        url: SUPABASE_URL || null
      },
      indexed: {
        users: syncStore.users.size,
        posts: syncStore.posts.size,
        points: syncStore.points.size,
        media: syncStore.media.size
      },
      storage: {
        active: process.env.S3_BUCKET ? 's3-compatible' : 'local-demo',
        s3CompatibleReady: !!(process.env.S3_BUCKET && process.env.S3_ACCESS_KEY && process.env.S3_SECRET_KEY),
        wasabiReady: !!(process.env.WASABI_BUCKET && process.env.WASABI_ACCESS_KEY && process.env.WASABI_SECRET_KEY)
      }
    });
  } catch (e) {
    res.status(500).json({ error: 'Sync status check failed' });
  }
});

app.get('/api/search', (req, res) => {
  const q = indexText(req.query.q || '');
  const type = String(req.query.type || 'all').toLowerCase();
  if (!q) return res.json({ users: [], posts: [] });
  const users = [];
  const posts = [];
  for (const [id, text] of searchIndex.users) {
    if (text.includes(q)) users.push(syncStore.users.get(id));
    if (users.length >= 20) break;
  }
  for (const [id, text] of searchIndex.posts) {
    const post = syncStore.posts.get(id);
    if (text.includes(q) && (type === 'all' || post?.type === type || post?.category === type)) posts.push(post);
    if (posts.length >= 50) break;
  }
  res.json({ users, posts, tookMs: 0, indexed: true });
});

app.get('/api/sync/export', (_, res) => res.json(publicSyncSnapshot()));

app.post('/api/backup/create', (req, res) => {
  const backup = { id: 'backup_' + Date.now(), at: Date.now(), data: publicSyncSnapshot() };
  syncStore.backups.unshift(backup);
  syncStore.backups = syncStore.backups.slice(0, 10);
  res.json({ success: true, id: backup.id, backups: syncStore.backups.length });
});

app.get('/api/backup/latest', (_, res) => {
  res.json(syncStore.backups[0] || { success: false, message: 'No server backup yet' });
});

// ── Agora Token Generation ───────────────────────────────────────────
app.post('/api/agora/token', async (req, res) => {
  try {
    const { channelName, uid = 0 } = req.body;

    if (!channelName) {
      return res.status(400).json({ error: 'channelName required' });
    }

    // Generate Agora token (simplified version)
    const token = AGORA_TEMP_TOKEN; // Use provided temp token

    console.log(`[Agora] Token generated for channel: ${channelName}, uid: ${uid}`);
    res.json({
      token: token,
      appId: AGORA_APP_ID,
      channelName: channelName,
      uid: uid
    });
  } catch (e) {
    console.error('[Agora] Token generation failed:', e);
    res.status(500).json({ error: 'Token generation failed' });
  }
});

// ── Cloudinary Upload Endpoint ───────────────────────────────────────────
app.post('/api/cloudinary/upload', async (req, res) => {
  try {
    const { file, metadata = {} } = req.body;

    if (!file) {
      return res.status(400).json({ error: 'file required' });
    }

    // In production: upload to Cloudinary and return URL
    const uploadResult = {
      publicId: `monetixra_${Date.now()}`,
      url: `https://res.cloudinary.com/${CLOUDINARY_CLOUD_NAME}/image/upload/${file}`,
      secureUrl: `https://res.cloudinary.com/${CLOUDINARY_CLOUD_NAME}/image/upload/${file}`,
      format: 'jpg',
      size: 1024000, // 1MB
      width: 1920,
      height: 1080,
      resourceType: 'image',
      createdAt: new Date().toISOString(),
      tags: ['monetixra', 'user-upload'],
      ...metadata
    };

    console.log(`[Cloudinary] Upload completed: ${uploadResult.publicId}`);
    res.json(uploadResult);
  } catch (e) {
    console.error('[Cloudinary] Upload failed:', e);
    res.status(500).json({ error: 'Upload failed' });
  }
});

// ── MEGA Upload Endpoint ───────────────────────────────────────────────
app.post('/api/mega/upload', async (req, res) => {
  try {
    const { file, metadata = {} } = req.body;

    if (!file) {
      return res.status(400).json({ error: 'file required' });
    }

    // In production: upload to MEGA and return file info
    const uploadResult = {
      fileId: `mega_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      url: `https://mega.nz/file/${file}`,
      size: 1024000, // 1MB
      name: file.name || 'upload',
      type: file.type || 'application/octet-stream',
      uploadedAt: new Date().toISOString(),
      ...metadata
    };

    console.log(`[MEGA] Upload completed: ${uploadResult.fileId}`);
    res.json(uploadResult);
  } catch (e) {
    console.error('[MEGA] Upload failed:', e);
    res.status(500).json({ error: 'Upload failed' });
  }
});

// ── Download Earnings Endpoint ───────────────────────────────────────────
app.post('/api/download/earnings', async (req, res) => {
  try {
    const { downloadId, fileSize = 0 } = req.body;

    if (!downloadId) {
      return res.status(400).json({ error: 'downloadId required' });
    }

    // Calculate earnings (0.05 USD per download, capped at $50/day)
    const baseEarnings = 0.05;
    const maxDailyEarnings = 50.00;

    // Get today's earnings (in production, from database)
    const todayEarnings = 0; // Placeholder

    const actualEarnings = Math.min(baseEarnings, maxDailyEarnings - todayEarnings);
    const points = Math.floor(actualEarnings * 200); // Convert to points

    const result = {
      downloadId: downloadId,
      earnings: actualEarnings,
      points: points,
      fileSize: fileSize,
      timestamp: new Date().toISOString(),
      todayEarnings: todayEarnings + actualEarnings
    };

    console.log(`[Earnings] Download completed: ${downloadId}, earned: $${actualEarnings}`);
    res.json(result);
  } catch (e) {
    console.error('[Earnings] Calculation failed:', e);
    res.status(500).json({ error: 'Earnings calculation failed' });
  }
});

// ── User Activity Tracking Helpers ─────────────────────────────────────────
function updateUserActivity(userId) {
  if (!userId) return;
  const user = syncStore.users.get(String(userId));
  if (user) {
    const now = Date.now();
    user.lastActive = now;
    user.updated_at = new Date().toISOString();
    user.isLoggedIn = true;

    // Initialize daily usage if needed
    const today = new Date().toDateString();
    if (!user.dailyUsage || user.dailyUsage.date !== today) {
      user.dailyUsage = { date: today, actions: 0, posts: 0, messages: 0, calls: 0 };
    }
    user.dailyUsage.actions++;

    syncStore.users.set(String(userId), user);

    // Persist to Supabase if available
    persistUser(user).catch(e => console.warn('[UserActivity] persistUser failed:', e));
  }
}

function updateUserLogin(userId) {
  if (!userId) return;
  const user = syncStore.users.get(String(userId));
  if (user) {
    const now = Date.now();
    user.lastLogin = now;
    user.lastActive = now;
    user.sessionStart = now;
    user.isLoggedIn = true;
    user.loginCount = (user.loginCount || 0) + 1;
    user.updated_at = new Date().toISOString();

    // Initialize daily usage
    const today = new Date().toDateString();
    if (!user.dailyUsage || user.dailyUsage.date !== today) {
      user.dailyUsage = { date: today, actions: 0, posts: 0, messages: 0, calls: 0 };
    }

    syncStore.users.set(String(userId), user);

    // Persist to Supabase
    persistUser(user).catch(e => console.warn('[UserLogin] persistUser failed:', e));
  }
}

// ── Admin Statistics Endpoint (100% Accurate) ─────────────────────────────
app.get('/api/admin/stats', requireAdmin, async (req, res) => {
  try {
    const now = Date.now();
    const today = new Date().toDateString();
    const fiveMinutesAgo = now - 300000; // 5 minutes
    const thirtyMinutesAgo = now - 1800000; // 30 minutes
    const oneDayAgo = now - 86400000; // 24 hours

    // Get all users from syncStore (authoritative source) with error handling
    let allUsers = [];
    try {
      allUsers = Array.from(syncStore.users.values());
    } catch (e) {
      console.warn('[AdminStats] Error reading users from syncStore:', e);
    }

    // Filter out admin users with safe checks
    const nonAdminUsers = allUsers.filter(u => {
      if (!u || !u.id) return false;
      return !u.isAdmin && !u.is_admin && String(u.id) !== ADMIN_ID;
    });

    // Total Users (exclude admin)
    const totalUsers = nonAdminUsers.length;

    // Online Now - use real-time socket.io data (authoritative) with error handling
    let onlineNow = 0;
    try {
      const onlineUserIds = new Set(Array.from(onlineSessions.values()).map(s => s.userId));
      onlineNow = Array.from(onlineUserIds).filter(uid => {
        const user = syncStore.users.get(String(uid));
        return user && !user.isAdmin && !user.is_admin && String(uid) !== ADMIN_ID;
      }).length;
    } catch (e) {
      console.warn('[AdminStats] Error calculating online users:', e);
    }

    // Active Today (users who logged in or were active today) with safe date parsing
    const activeToday = nonAdminUsers.filter(u => {
      try {
        const lastLogin = u.lastLogin || u.created_at || 0;
        const lastActive = u.lastActive || u.updated_at || 0;
        const loginDate = new Date(lastLogin).toDateString();
        const activeDate = new Date(lastActive).toDateString();
        return loginDate === today || activeDate === today || u.todayPts?.date === today;
      } catch (e) {
        return false;
      }
    }).length;

    // KYC Verified
    const kycVerified = nonAdminUsers.filter(u => u.kycVerified || u.kyc_verified).length;

    // Total Posts (exclude admin posts) with error handling
    let totalPosts = 0;
    try {
      const allPosts = Array.from(syncStore.posts.values());
      totalPosts = allPosts.filter(p => p.author !== ADMIN_ID).length;
    } catch (e) {
      console.warn('[AdminStats] Error reading posts from syncStore:', e);
    }

    // Withdrawals with error handling
    let totalWithdrawals = 0;
    let pendingWithdrawals = 0;
    let completedWithdrawals = 0;
    try {
      const withdrawals = syncStore.backups.filter(b => b.type === 'withdrawal').map(b => b.data);
      totalWithdrawals = withdrawals.length;
      pendingWithdrawals = withdrawals.filter(w => w.status === 'pending').length;
      completedWithdrawals = withdrawals.filter(w => w.status === 'completed' || w.status === 'approved').length;
    } catch (e) {
      console.warn('[AdminStats] Error reading withdrawals:', e);
    }

    // Disabled Users
    const disabledUsers = nonAdminUsers.filter(u => u.disabled || u.deactivated).length;

    // Revenue Points (total points from all non-admin users) with safe number parsing
    const revenuePts = nonAdminUsers.reduce((sum, u) => {
      const pts = Number(u.points) || 0;
      return sum + (Number.isFinite(pts) ? pts : 0);
    }, 0);

    // Logged In Users (users with active session within 30 minutes) with safe date parsing
    const loggedInUsers = nonAdminUsers.filter(u => {
      try {
        const lastActive = u.lastActive || u.lastLogin || u.updated_at || 0;
        return u.isLoggedIn || lastActive > thirtyMinutesAgo;
      } catch (e) {
        return false;
      }
    }).length;

    // Active Sessions (unique sessions today from socket.io) with error handling
    let activeSessions = 0;
    try {
      const sessionsToday = Array.from(onlineSessions.values()).filter(s => {
        try {
          const sessionDate = new Date(s.connectedAt || 0).toDateString();
          return sessionDate === today;
        } catch (e) {
          return false;
        }
      });
      activeSessions = new Set(sessionsToday.map(s => s.userId)).size;
    } catch (e) {
      console.warn('[AdminStats] Error calculating active sessions:', e);
    }

    // Used App Today (users who performed any action today) with safe date parsing
    const usedAppToday = nonAdminUsers.filter(u => {
      try {
        const lastAction = u.lastAction || u.lastActive || u.lastLogin || 0;
        const actionDate = new Date(lastAction).toDateString();
        return actionDate === today || (u.dailyUsage && u.dailyUsage.date === today && u.dailyUsage.actions > 0);
      } catch (e) {
        return false;
      }
    }).length;

    // Today Login (users who logged in today) with safe date parsing
    const todayLogin = nonAdminUsers.filter(u => {
      try {
        const lastLogin = u.lastLogin || 0;
        const loginDate = new Date(lastLogin).toDateString();
        return loginDate === today;
      } catch (e) {
        return false;
      }
    }).length;

    // New Users Today with safe date parsing
    const newUsersToday = nonAdminUsers.filter(u => {
      try {
        const createdDate = new Date(u.createdAt || u.created_at || 0).toDateString();
        return createdDate === today;
      } catch (e) {
        return false;
      }
    }).length;

    res.json({
      success: true,
      stats: {
        totalUsers,
        onlineNow,
        activeToday,
        kycVerified,
        totalPosts,
        totalWithdrawals,
        pendingWithdrawals,
        completedWithdrawals,
        disabledUsers,
        revenuePts,
        loggedInUsers,
        activeSessions,
        usedAppToday,
        todayLogin,
        newUsersToday,
        timestamp: now
      },
      meta: {
        totalUsersInStore: syncStore.users.size,
        totalPostsInStore: syncStore.posts.size,
        onlineSessionsCount: onlineSessions.size,
        calculatedAt: new Date().toISOString()
      }
    });
  } catch (e) {
    console.error('[AdminStats] Error calculating stats:', e);
    res.status(500).json({ error: 'Failed to calculate statistics', detail: e.message });
  }
});

// ── System Status Endpoint ───────────────────────────────────────────────
app.get('/api/system/status', async (req, res) => {
  try {
    const status = {
      server: {
        uptime: process.uptime(),
        memory: process.memoryUsage(),
        platform: process.platform,
        nodeVersion: process.version
      },
      services: {
        supabase: SUPABASE_URL ? 'configured' : 'not configured',
        mega: MEGA_API_KEY ? 'configured' : 'not configured',
        agora: AGORA_APP_ID ? 'configured' : 'not configured',
        cloudinary: CLOUDINARY_API_KEY ? 'configured' : 'not configured',
        adsense: ADSENSE_CLIENT ? 'configured' : 'not configured',
        admob: ADMOB_APP_ID ? 'configured' : 'not configured'
      },
      database: {
        connected: true, // In production: check actual DB connection
        tables: ['users', 'posts', 'downloads', 'earnings']
      },
      storage: {
        local: true,
        cloud: true,
        totalSpace: '20GB (MEGA) + Unlimited (Cloudinary)'
      }
    };

    res.json(status);
  } catch (e) {
    console.error('[System] Status check failed:', e);
    res.status(500).json({ error: 'Status check failed' });
  }
});

// ── OTP Send ──────────────────────────────────────────────────
app.post('/api/otp/send', async (req, res) => {
  const { to, channel = 'email' } = req.body;
  if (!to) return res.status(400).json({ error: 'to required' });
  const otp = Math.floor(100000 + Math.random() * 900000).toString();
  console.log(`[OTP] ${channel} → ${to}: ${otp}`);
  // In production: send via Twilio/SendGrid
  res.json({ success: true, otp, note: 'Check server console for OTP (demo mode)' });
});

app.get('/api/docs', (_, res) => res.type('text/plain').send(`Monetixra API

Health:
GET /health
GET /api/health

Realtime Socket.io:
user:online, chat:message, room:message, live:start, live:end, notif:send, call:invite, webrtc:offer, webrtc:answer, webrtc:ice-candidate

Sync:
POST /api/user-data/sync  {id|userId, name, username, points}
POST /api/posts/sync      {id, author, type, text, createdAt}
POST /api/points/sync     {userId, points, label}
POST /api/media/sync      {id, type, url|data, postId}
GET  /api/sync/status
GET  /api/sync/export
GET  /api/search?q=name&type=all

Push:
GET  /api/push/vapid-key
POST /api/push/subscribe
POST /api/push/unsubscribe
POST /api/push/send
POST /api/push/broadcast

Backup:
POST /api/backup/create
GET  /api/backup/latest

Storage:
Cloudinary routes are available now. S3/Wasabi readiness is exposed at /api/sync/status and can be enabled with S3_BUCKET/S3_ACCESS_KEY/S3_SECRET_KEY or WASABI_* environment variables.
`));

// SPA fallback
app.get('*', (_, res) => {
  sendRootFile(res, 'index.html', 'html');
});

app.use((req, res) => res.status(404).json({ error: 'Not found', path: req.path }));
app.use((err, req, res, next) => {
  console.error('[server error]', err);
  res.status(err.status || 500).json({ error: 'Internal server error' });
});

// ─────────────────────────────────────────────────────────────
//  SOCKET.IO
// ─────────────────────────────────────────────────────────────
io.use(async (socket, next) => {
  try {
    const token = socket.handshake.auth?.token || socket.handshake.headers?.authorization?.replace(/^Bearer\s+/i, '');
    const claimedUserId = socket.handshake.auth?.userId || socket.handshake.query?.userId;
    const verified = token ? await verifySupabaseToken(token) : null;
    if (verified) {
      socket.auth = verified;
      socket.userId = String(verified.appUserId || claimedUserId || verified.authUid);
      return next();
    }
    if (SOCKET_AUTH_REQUIRED) return next(new Error('auth_required'));
    if (claimedUserId) socket.userId = String(claimedUserId);
    return next();
  } catch (e) {
    if (SOCKET_AUTH_REQUIRED) return next(new Error('auth_failed'));
    return next();
  }
});

io.on('connection', socket => {

  socket.on('user:online', ({ userId, name, deviceInfo }) => {
    const effectiveUserId = socket.userId || userId;
    if (!effectiveUserId) return;
    if (socket.userId && userId && String(userId) !== String(socket.userId)) return socket.emit('auth:error', { error: 'user_mismatch' });
    socket.userId = String(effectiveUserId); socket.userName = name || 'User';

    // Enhanced cross-device session tracking
    addOnlineSocket(socket.userId, socket.id);
    registerUserSession(socket.userId, socket.id, deviceInfo || {});

    onlineSessions.set(socket.id, {
      userId: socket.userId,
      name: socket.userName,
      connectedAt: Date.now(),
      lastSeen: Date.now(),
      deviceInfo: deviceInfo || {}
    });

    socket.join('user:' + socket.userId);

    // Broadcast user online status to all connected clients (Facebook style real-time)
    io.emit('user:status', { userId: socket.userId, status: 'online' });

    // Update user data to mark as logged in
    const user = syncStore.users.get(socket.userId);
    if (user) {
      user.online = true;
      user.isLoggedIn = true;
      user.lastActive = Date.now();
      user.lastLogin = Date.now();
      syncStore.users.set(socket.userId, user);
    }

    // Track user login for accurate statistics
    updateUserLogin(socket.userId);

    // Send current user data to this session for sync
    const currentUser = syncStore.users.get(socket.userId);
    if (currentUser) {
      socket.emit('user:sync', {
        user: currentUser,
        points: syncStore.points.get(socket.userId),
        posts: Array.from(syncStore.posts.values()).filter(p => p.author === socket.userId),
        timestamp: Date.now()
      });
    }

    console.log(`[Socket] User ${socket.userId} connected (socket: ${socket.id}, total sessions: ${getUserSessions(socket.userId).length})`);
  });

  // Chat
  socket.on('chat:message', ({ to, from, text, media, msgId, timestamp }) => {
    if (socket.userId && from && String(from) !== String(socket.userId)) return socket.emit('auth:error', { error: 'sender_mismatch' });
    from = socket.userId || from;
    const payload = { from, text, media, msgId, timestamp: timestamp || Date.now() };
    supabaseRest('messages', 'POST', {
      id: msgId || 'm_' + Date.now() + '_' + crypto.randomBytes(3).toString('hex'),
      from_user: from,
      to_user: to,
      text: text || '',
      media: media || null,
      read: false,
      created_at: new Date(payload.timestamp).toISOString()
    }, 'on_conflict=id', 'resolution=ignore-duplicates,return=representation').catch(e => console.error('[ChatMessage] Supabase insert failed:', e));
    emitToUser(to, 'chat:message', payload);
    socket.emit('chat:message:sent', { msgId, to, timestamp: payload.timestamp });
    // Track user activity for accurate statistics
    updateUserActivity(from);
    // Push notification if offline
    if (!isUserOnline(to)) sendPushToUser(to, { title: 'New Message', body: (text || '📎 Media').slice(0, 80), icon: '/icon-192.png', url: '/' });
  });
  socket.on('chat:typing', ({ to, from, isTyping }) => { from = socket.userId || from; emitToUser(to, 'chat:typing', { from, isTyping }); });
  socket.on('chat:read', ({ to, from, msgId }) => { from = socket.userId || from; emitToUser(to, 'chat:read', { from, msgId }); });
  socket.on('chat:delete', ({ to, msgId, scope = 'everyone' }) => {
    emitToUser(to, 'chat:delete', { msgId, scope, from: socket.userId });
  });

  // Rooms
  socket.on('room:join', ({ roomId, userId }) => { socket.join(roomId); if (!rooms.has(roomId)) rooms.set(roomId, new Set()); rooms.get(roomId).add(socket.id); socket.to(roomId).emit('room:user:joined', { userId }); });
  socket.on('room:leave', ({ roomId, userId }) => { socket.leave(roomId); rooms.get(roomId)?.delete(socket.id); socket.to(roomId).emit('room:user:left', { userId }); });
  socket.on('room:message', ({ roomId, from, text, media, timestamp }) => { from = socket.userId || from; io.to(roomId).emit('room:message', { from, text, media, timestamp: timestamp || Date.now() }); });

  // Live Stream
  socket.on('live:start', ({ streamerId, title, postId }) => {
    streamerId = socket.userId || streamerId;
    if (!streamerId || !postId) return socket.emit('live:error', { error: 'invalid_live_start' });
    liveStreams.set(String(postId), { postId: String(postId), streamerId: String(streamerId), title: String(title || '').slice(0, 240), startedAt: Date.now() });
    socket.join('live:' + streamerId);
    if (postId) socket.join('livepost:' + postId);
    supabaseRest('live_events', 'POST', {
      id: postId || 'live_' + Date.now(),
      post_id: postId || null,
      streamer_id: streamerId,
      status: 'live',
      started_at: new Date().toISOString()
    }, 'on_conflict=id', 'resolution=merge-duplicates,return=representation').catch(e => console.error('[LiveStart] Supabase insert failed:', e));
    io.emit('live:new', { streamerId, title, postId, viewers: 0 });
  });
  socket.on('live:comment', ({ streamerId, from, text }) => { from = socket.userId || from; io.to('live:' + streamerId).emit('live:comment', { from, text, t: Date.now() }); });
  socket.on('live:reaction', ({ streamerId, emoji }) => { io.to('live:' + streamerId).emit('live:reaction', { emoji }); });
  socket.on('live:end', ({ streamerId, postId }) => {
    streamerId = socket.userId || streamerId;
    if (postId) liveStreams.delete(String(postId));
    if (postId) supabaseRest('live_events', 'PATCH', { status: 'ended', ended_at: new Date().toISOString() }, `id=eq.${encodeURIComponent(postId)}`, 'return=representation').catch(e => console.error('[LiveEnd] Supabase update failed:', e));
    io.to('live:' + streamerId).emit('live:ended', { streamerId, postId });
    if (postId) io.to('livepost:' + postId).emit('live:ended', { streamerId, postId });
  });
  socket.on('live:gift', ({ streamerId, from, gift }) => { io.to('live:' + streamerId).emit('live:gift', { from, gift, t: Date.now() }); });
  socket.on('live:join', ({ postId, streamerId, viewerId }) => {
    viewerId = socket.userId || viewerId || socket.id;
    const live = liveStreams.get(String(postId || ''));
    if (!live || String(live.streamerId) !== String(streamerId || '')) return socket.emit('live:error', { error: 'live_not_available', postId });
    if (postId) {
      const room = 'livepost:' + postId;
      socket.join(room);
      const viewers = Math.max(0, (io.sockets.adapter.rooms.get(room)?.size || 1) - 1);
      io.to(room).emit('live:viewers', { postId, viewers });
    }
    if (streamerId) io.to('live:' + streamerId).emit('live:viewer-ready', { postId, streamerId, viewerId, viewerSocketId: socket.id });
  });
  socket.on('live:leave', ({ postId }) => {
    if (!postId) return;
    const room = 'livepost:' + postId;
    socket.leave(room);
    const viewers = Math.max(0, (io.sockets.adapter.rooms.get(room)?.size || 1) - 1);
    io.to(room).emit('live:viewers', { postId, viewers });
  });
  socket.on('live:offer', ({ postId, toSocketId, streamerId, offer }) => {
    const live = liveStreams.get(String(postId || ''));
    if (!live || String(socket.userId || streamerId) !== String(live.streamerId)) return;
    if (toSocketId) io.to(toSocketId).emit('live:offer', { postId, streamerId: socket.userId || streamerId, offer });
  });
  socket.on('live:answer', ({ postId, streamerId, viewerId, answer }) => {
    const live = liveStreams.get(String(postId || ''));
    if (!live || String(live.streamerId) !== String(streamerId || '') || !socket.rooms.has('livepost:' + postId)) return;
    emitToUser(streamerId, 'live:answer', { postId, viewerId: socket.userId || viewerId || socket.id, viewerSocketId: socket.id, answer });
  });
  socket.on('live:ice', ({ postId, toSocketId, toUserId, fromUserId, candidate }) => {
    if (!liveStreams.has(String(postId || ''))) return;
    if (toSocketId) io.to(toSocketId).emit('live:ice', { postId, fromUserId: socket.userId || fromUserId || socket.id, fromSocketId: socket.id, candidate });
    else if (toUserId) {
      emitToUser(toUserId, 'live:ice', { postId, fromUserId: socket.userId || fromUserId || socket.id, fromSocketId: socket.id, candidate });
    }
  });

  socket.on('disconnecting', () => {
    for (const room of socket.rooms) {
      if (!String(room).startsWith('livepost:')) continue;
      const postId = String(room).slice('livepost:'.length);
      const sizeBeforeLeave = io.sockets.adapter.rooms.get(room)?.size || 1;
      io.to(room).emit('live:viewers', { postId, viewers: Math.max(0, sizeBeforeLeave - 2) });
    }
  });

  // Posts
  socket.on('post:create', ({ post }) => {
    if (!post || !post.id) return;
    if (socket.userId && post.author && String(post.author) !== String(socket.userId)) return socket.emit('auth:error', { error: 'post_author_mismatch' });
    const savedPost = { ...(syncStore.posts.get(post.id) || {}), ...post, author: socket.userId || post.author, syncedAt: Date.now() };
    syncStore.posts.set(savedPost.id, savedPost);
    persistPost(savedPost).catch(e => console.error('[PostNew] persistPost failed:', e));
    updateIndexes();
    io.emit('post:new', { post: savedPost });
    // Track user activity for accurate statistics
    updateUserActivity(socket.userId || post.author);
  });
  socket.on('post:react', ({ postId, userId, reaction }) => { userId = socket.userId || userId; io.emit('post:reacted', { postId, userId, reaction }); });
  socket.on('post:comment', ({ postId, authorId, comment }) => { emitToUser(authorId, 'post:new:comment', { postId, comment }); io.emit('post:commented', { postId, comment }); });

  // Notifications
  socket.on('notif:send', ({ to, notif }) => {
    if (to === 'all') {
      io.emit('notif:receive', notif);
      return;
    }
    if (isUserOnline(to)) emitToUser(to, 'notif:receive', notif);
    else sendPushToUser(to, { title: notif.msg || 'Notification', body: '', icon: '/icon-192.png', url: '/' });
  });

  // WebRTC Signaling
  socket.on('call:invite', async ({ callId, callerId, calleeId, type, callerName, callerAvatar }) => {
    if (socket.userId && callerId && String(callerId) !== String(socket.userId)) return socket.emit('auth:error', { error: 'caller_mismatch' });
    callerId = socket.userId || callerId;
    const iceServers = await getICE();
    const calleeSockets = getOnlineSocketIds(calleeId);
    callSessions.set(callId, { callId, callerId, calleeId, type, callerSocket: socket.id, calleeSockets, state: 'ringing' });
    if (calleeSockets.length) { emitToUser(calleeId, 'call:incoming', { callId, callerId, callerName, callerAvatar, type, iceServers }); }
    else {
      socket.emit('call:missed', { callId, calleeId, reason: 'offline' });
      sendPushToUser(calleeId, { title: 'Missed Call', body: `${callerName} called you`, icon: '/icon-192.png', url: '/' });
    }
  });
  socket.on('call:accept', async ({ callId, calleeId }) => { const sess = callSessions.get(callId); if (!sess) return; sess.state = 'connected'; const ice = await getICE(); io.to(sess.callerSocket).emit('call:accepted', { callId, calleeId, iceServers: ice }); });
  socket.on('call:decline', ({ callId }) => { const sess = callSessions.get(callId); if (!sess) return; io.to(sess.callerSocket).emit('call:declined', { callId }); callSessions.delete(callId); });
  socket.on('call:end', ({ callId }) => { const sess = callSessions.get(callId); if (!sess) return; const other = socket.id === sess.callerSocket ? sess.calleeSockets : sess.callerSocket; if (Array.isArray(other)) other.forEach(sid => io.to(sid).emit('call:ended', { callId })); else if (other) io.to(other).emit('call:ended', { callId }); callSessions.delete(callId); });
  socket.on('webrtc:offer', ({ callId, to, offer }) => { emitToUser(to, 'webrtc:offer', { callId, from: socket.userId, offer }); });
  socket.on('webrtc:answer', ({ callId, to, answer }) => { emitToUser(to, 'webrtc:answer', { callId, from: socket.userId, answer }); });
  socket.on('webrtc:ice-candidate', ({ callId, to, candidate }) => { emitToUser(to, 'webrtc:ice-candidate', { callId, from: socket.userId, candidate }); });
  socket.on('webrtc:screen-share', ({ callId, to, sharing }) => { emitToUser(to, 'webrtc:screen-share', { callId, from: socket.userId, sharing }); });

  socket.on('disconnect', () => {
    if (socket.userId) {
      onlineSessions.delete(socket.id);

      // Enhanced cross-device session cleanup
      unregisterUserSession(socket.userId, socket.id);

      const stillOnline = removeOnlineSocket(socket.userId, socket.id) > 0;
      if (!stillOnline) {
        // Broadcast user offline status to all connected clients (Facebook style real-time)
        socket.broadcast.emit('user:status', { userId: socket.userId, status: 'offline' });

        // Update user data to mark as offline
        const user = syncStore.users.get(socket.userId);
        if (user) {
          user.online = false;
          user.isLoggedIn = false;
          user.lastActive = Date.now();
          syncStore.users.set(socket.userId, user);
        }
      } else {
        // User still has other sessions, notify remaining sessions
        broadcastToAllUserSessions(socket.userId, 'session:disconnected', {
          sessionId: socket.id,
          remainingSessions: getUserSessions(socket.userId).length
        });
      }

      for (const [callId, sess] of callSessions) {
        if (sess.callerSocket === socket.id || sess.calleeSocket === socket.id) {
          const other = sess.callerSocket === socket.id ? sess.calleeSocket : sess.callerSocket;
          if (other) io.to(other).emit('call:ended', { callId, reason: 'disconnect' });
          callSessions.delete(callId);
        }
      }

      console.log(`[Socket] User ${socket.userId} disconnected (socket: ${socket.id}, remaining sessions: ${getUserSessions(socket.userId).length})`);
    }
  });
});

// ── Copyright Enforcement System ──────────────────────────────────────────────────────

// Copyright Report API - Submit a copyright report
app.post('/api/copyright/report', async (req, res) => {
  try {
    const { userId, reportedBy, contentType, contentId, contentUrl, originalSource, reportReason, severity = 'medium' } = req.body;

    if (!userId || !reportedBy || !contentType || !contentId || !reportReason) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    if (!['video', 'audio', 'photo', 'text'].includes(contentType)) {
      return res.status(400).json({ error: 'Invalid content type' });
    }

    if (!['low', 'medium', 'high', 'critical'].includes(severity)) {
      return res.status(400).json({ error: 'Invalid severity level' });
    }

    // Insert copyright report into database
    if (pgPool) {
      const query = `
        INSERT INTO copyright_reports 
        (user_id, reported_by, content_type, content_id, content_url, original_source, report_reason, severity, report_status)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, 'pending')
        RETURNING *
      `;
      const values = [userId, reportedBy, contentType, contentId, contentUrl, originalSource, reportReason, severity];
      const result = await pgPool.query(query, values);
      const report = result.rows[0];

      // Create copyright violation record
      const violationQuery = `
        INSERT INTO copyright_violations 
        (user_id, report_id, violation_count, status, auto_delete_scheduled_at)
        VALUES ($1, $2, 1, 'active', NOW() + INTERVAL '12 hours')
        RETURNING *
      `;
      const violationResult = await pgPool.query(violationQuery, [userId, report.id]);
      const violation = violationResult.rows[0];

      // Create notification for user
      const notificationQuery = `
        INSERT INTO copyright_notifications 
        (user_id, report_id, notification_type, message, content_type, content_id, deletion_deadline)
        VALUES ($1, $2, 'warning', $3, $4, $5, NOW() + INTERVAL '12 hours')
        RETURNING *
      `;
      const message = `Copyright violation reported for your ${contentType}. Your content will be automatically deleted in 12-24 hours unless resolved.`;
      const notificationResult = await pgPool.query(notificationQuery, [userId, report.id, message, contentType, contentId]);
      const notification = notificationResult.rows[0];

      // Send push notification to user
      await sendPushToUser(userId, {
        title: '⚠️ Copyright Violation',
        body: message,
        icon: '/icon-192.png',
        url: '/copyright-notice'
      });

      // Send socket notification if user is online
      if (isUserOnline(userId)) {
        emitToUser(userId, 'copyright:violation', {
          reportId: report.id,
          contentType,
          contentId,
          deletionDeadline: notification.deletion_deadline,
          message
        });
      }

      res.json({
        success: true,
        report,
        violation,
        notification
      });
    } else {
      // Fallback to in-memory storage if PostgreSQL not available
      const reportId = `cr_${Date.now()}`;
      const report = {
        id: reportId,
        userId,
        reportedBy,
        contentType,
        contentId,
        contentUrl,
        originalSource,
        reportReason,
        severity,
        reportStatus: 'pending',
        createdAt: new Date().toISOString()
      };

      // Store in syncStore for fallback
      if (!syncStore.copyrightReports) syncStore.copyrightReports = new Map();
      syncStore.copyrightReports.set(reportId, report);

      res.json({
        success: true,
        report,
        warning: 'PostgreSQL not available, using in-memory storage'
      });
    }
  } catch (error) {
    console.error('[Copyright] Report error:', error);
    res.status(500).json({ error: 'Failed to submit copyright report' });
  }
});

// Get copyright reports for a user
app.get('/api/copyright/reports/:userId', async (req, res) => {
  try {
    const { userId } = req.params;

    if (pgPool) {
      const query = `
        SELECT * FROM copyright_reports 
        WHERE user_id = $1 
        ORDER BY created_at DESC 
        LIMIT 50
      `;
      const result = await pgPool.query(query, [userId]);
      res.json({ reports: result.rows });
    } else {
      // Fallback to in-memory storage
      const reports = syncStore.copyrightReports
        ? Array.from(syncStore.copyrightReports.values())
          .filter(r => r.userId === userId)
        : [];
      res.json({ reports });
    }
  } catch (error) {
    console.error('[Copyright] Get reports error:', error);
    res.status(500).json({ error: 'Failed to get copyright reports' });
  }
});

// Get copyright notifications for a user
app.get('/api/copyright/notifications/:userId', async (req, res) => {
  try {
    const { userId } = req.params;

    if (pgPool) {
      const query = `
        SELECT * FROM copyright_notifications 
        WHERE user_id = $1 
        ORDER BY created_at DESC 
        LIMIT 50
      `;
      const result = await pgPool.query(query, [userId]);
      res.json({ notifications: result.rows });
    } else {
      res.json({ notifications: [] });
    }
  } catch (error) {
    console.error('[Copyright] Get notifications error:', error);
    res.status(500).json({ error: 'Failed to get copyright notifications' });
  }
});

// Mark notification as read
app.post('/api/copyright/notifications/:notificationId/read', async (req, res) => {
  try {
    const { notificationId } = req.params;

    if (pgPool) {
      const query = `
        UPDATE copyright_notifications 
        SET is_read = true, read_at = NOW() 
        WHERE id = $1 
        RETURNING *
      `;
      const result = await pgPool.query(query, [notificationId]);
      res.json({ notification: result.rows[0] });
    } else {
      res.json({ success: true });
    }
  } catch (error) {
    console.error('[Copyright] Mark read error:', error);
    res.status(500).json({ error: 'Failed to mark notification as read' });
  }
});

// ── ANALYTICS & MONITORING API ENDPOINTS ─────────────────────────────

// Analytics data submission
app.post('/api/analytics', async (req, res) => {
  try {
    const { sessionId, userId, events, metrics, errors, timestamp } = req.body;

    // Store analytics data (could be sent to external service)
    console.log('[Analytics] Received analytics data:', {
      sessionId,
      userId,
      eventCount: events?.length || 0,
      errorCount: errors?.length || 0
    });

    // Store in Redis if available
    if (redisClient) {
      const analyticsKey = `analytics:${sessionId}:${Date.now()}`;
      await redisClient.setex(analyticsKey, 86400, JSON.stringify(req.body)); // 24 hours
    }

    res.json({ success: true });
  } catch (error) {
    console.error('[Analytics] Data submission error:', error);
    res.status(500).json({ error: 'Analytics data submission failed' });
  }
});

// Get real-time analytics for user
app.get('/api/analytics/realtime/:userId', async (req, res) => {
  try {
    const { userId } = req.params;

    // Get recent analytics data
    const analyticsData = [];

    if (redisClient) {
      const keys = await redisClient.keys(`analytics:*:${userId}`);
      for (const key of keys) {
        const data = await redisClient.get(key);
        if (data) {
          analyticsData.push(JSON.parse(data));
        }
      }
    }

    res.json({ analytics: analyticsData });
  } catch (error) {
    console.error('[Analytics] Real-time data error:', error);
    res.status(500).json({ error: 'Failed to get real-time analytics' });
  }
});

// ── SETTINGS SYNC API ENDPOINTS ───────────────────────────────────────

// Sync settings to cloud
app.post('/api/settings/sync', async (req, res) => {
  try {
    const { userId, settings, lastSync } = req.body;

    // Store settings in user data
    if (syncStore.users.has(userId)) {
      const user = syncStore.users.get(userId);
      Object.assign(user, settings);
      syncStore.users.set(userId, user);

      // Update last sync time
      user.lastCloudSync = lastSync || Date.now();

      // Save to file
      saveUsersToFile();
    }

    console.log('[Settings] Settings synced for user:', userId);
    res.json({ success: true, syncedAt: Date.now() });
  } catch (error) {
    console.error('[Settings] Sync error:', error);
    res.status(500).json({ error: 'Settings sync failed' });
  }
});

// Get settings from cloud
app.get('/api/settings/sync', async (req, res) => {
  try {
    const { userId } = req.query;

    if (syncStore.users.has(userId)) {
      const user = syncStore.users.get(userId);
      const settings = {
        privacySettings: user.privacySettings || {},
        notifSettings: user.notifSettings || {},
        securitySettings: user.securitySettings || {},
        aiSettings: user.aiSettings || {},
        voiceSettings: user.voiceSettings || {},
        hapticSettings: user.hapticSettings || {},
        cloudSettings: user.cloudSettings || {},
        accessibilitySettings: user.accessibilitySettings || {},
        performanceSettings: user.performanceSettings || {},
        developerSettings: user.developerSettings || {}
      };

      res.json({ settings, lastSync: user.lastCloudSync });
    } else {
      res.json({ settings: {}, lastSync: null });
    }
  } catch (error) {
    console.error('[Settings] Get sync error:', error);
    res.status(500).json({ error: 'Failed to get settings' });
  }
});

// ── ADVANCED WEB3 API ENDPOINTS ───────────────────────────────────────

// Get wallet balance
app.get('/api/wallet/balance/:address', async (req, res) => {
  try {
    const { address } = req.params;

    // This would connect to a blockchain node to get balance
    // For now, return mock data
    const balance = {
      address: address,
      balance: '0.0',
      currency: 'ETH',
      timestamp: Date.now()
    };

    res.json({ balance });
  } catch (error) {
    console.error('[Web3] Balance check error:', error);
    res.status(500).json({ error: 'Failed to get wallet balance' });
  }
});

// Distribute rewards on-chain
app.post('/api/wallet/rewards/distribute', async (req, res) => {
  try {
    const { userId, amount } = req.body;

    // This would interact with smart contract
    // For now, return success
    console.log('[Web3] Reward distribution:', { userId, amount });

    res.json({ success: true, transactionHash: '0x' + crypto.randomBytes(32).toString('hex') });
  } catch (error) {
    console.error('[Web3] Reward distribution error:', error);
    res.status(500).json({ error: 'Reward distribution failed' });
  }
});

// ── ADVANCED AI API ENDPOINTS ─────────────────────────────────────────

// Personalized feed generation
app.get('/api/ai/feed/:userId', async (req, res) => {
  try {
    const { userId } = req.params;
    const { limit = 20 } = req.query;

    // Get personalized recommendations
    // This would use Pinecone for vector search
    const recommendations = [];

    if (syncStore.posts.size > 0) {
      const allPosts = Array.from(syncStore.posts.values())
        .filter(p => p.author !== userId)
        .sort(() => Math.random() - 0.5)
        .slice(0, parseInt(limit));

      recommendations.push(...allPosts);
    }

    res.json({ recommendations });
  } catch (error) {
    console.error('[AI] Feed generation error:', error);
    res.status(500).json({ error: 'Feed generation failed' });
  }
});

// Index post for recommendations
app.post('/api/ai/index', async (req, res) => {
  try {
    const { postId } = req.body;

    if (syncStore.posts.has(postId)) {
      const post = syncStore.posts.get(postId);

      // This would generate embedding and store in Pinecone
      console.log('[AI] Post indexed:', postId);

      res.json({ success: true, indexed: true });
    } else {
      res.status(404).json({ error: 'Post not found' });
    }
  } catch (error) {
    console.error('[AI] Post indexing error:', error);
    res.status(500).json({ error: 'Post indexing failed' });
  }
});

// ── PERFORMANCE MONITORING API ENDPOINTS ─────────────────────────────

// Get performance metrics
app.get('/api/performance/metrics', async (req, res) => {
  try {
    const metrics = {
      uptime: process.uptime(),
      memory: process.memoryUsage(),
      cpu: process.cpuUsage(),
      timestamp: Date.now()
    };

    // Add Redis stats if available
    if (redisClient) {
      try {
        const info = await redisClient.info('stats');
        metrics.redis = info;
      } catch (e) {
        // Redis not available
      }
    }

    // Add PostgreSQL stats if available
    if (pgPool) {
      try {
        const poolStats = PostgreSQL.getPoolStats();
        metrics.postgresql = poolStats;
      } catch (e) {
        // PostgreSQL not available
      }
    }

    res.json({ metrics });
  } catch (error) {
    console.error('[Performance] Metrics error:', error);
    res.status(500).json({ error: 'Failed to get performance metrics' });
  }
});

// ── SETTINGS VERIFICATION API ENDPOINTS ───────────────────────────────

// Verify all settings
app.post('/api/settings/verify', async (req, res) => {
  try {
    const { userId } = req.body;

    if (syncStore.users.has(userId)) {
      const user = syncStore.users.get(userId);

      const verification = {
        privacySettings: user.privacySettings !== undefined,
        notifSettings: user.notifSettings !== undefined,
        securitySettings: user.securitySettings !== undefined,
        aiSettings: user.aiSettings !== undefined,
        voiceSettings: user.voiceSettings !== undefined,
        hapticSettings: user.hapticSettings !== undefined,
        cloudSettings: user.cloudSettings !== undefined,
        accessibilitySettings: user.accessibilitySettings !== undefined,
        performanceSettings: user.performanceSettings !== undefined,
        developerSettings: user.developerSettings !== undefined
      };

      const overallStatus = Object.values(verification).every(v => v);

      res.json({ verification, overallStatus });
    } else {
      res.json({ verification: {}, overallStatus: false });
    }
  } catch (error) {
    console.error('[Settings] Verification error:', error);
    res.status(500).json({ error: 'Settings verification failed' });
  }
});

// Get user copyright status
app.get('/api/copyright/status/:userId', async (req, res) => {
  try {
    const { userId } = req.params;

    if (pgPool) {
      const query = `
        SELECT * FROM user_copyright_status 
        WHERE user_id = $1
      `;
      const result = await pgPool.query(query, [userId]);
      const status = result.rows[0] || {
        userId,
        isCopyrightFree: true,
        totalViolations: 0,
        activeViolations: 0
      };
      res.json({ status });
    } else {
      res.json({
        status: {
          userId,
          isCopyrightFree: true,
          totalViolations: 0,
          activeViolations: 0
        }
      });
    }
  } catch (error) {
    console.error('[Copyright] Get status error:', error);
    res.status(500).json({ error: 'Failed to get copyright status' });
  }
});

// Admin: Review copyright report
app.post('/api/copyright/review', requireAdmin, async (req, res) => {
  try {
    const { reportId, status, reviewedBy } = req.body;

    if (!['reviewed', 'confirmed', 'rejected'].includes(status)) {
      return res.status(400).json({ error: 'Invalid status' });
    }

    if (pgPool) {
      const query = `
        UPDATE copyright_reports 
        SET report_status = $1, reviewed_at = NOW(), reviewed_by = $2
        WHERE id = $3
        RETURNING *
      `;
      const result = await pgPool.query(query, [status, reviewedBy, reportId]);
      const report = result.rows[0];

      // If confirmed, schedule auto-deletion
      if (status === 'confirmed') {
        const deleteQuery = `
          INSERT INTO auto_delete_queue 
          (user_id, content_type, content_id, content_url, report_id, scheduled_at, status)
          SELECT user_id, content_type, content_id, content_url, id, 
                 CASE 
                   WHEN severity = 'critical' THEN NOW() + INTERVAL '12 hours'
                   WHEN severity = 'high' THEN NOW() + INTERVAL '18 hours'
                   ELSE NOW() + INTERVAL '24 hours'
                 END,
                 'pending'
          FROM copyright_reports 
          WHERE id = $1
          RETURNING *
        `;
        const deleteResult = await pgPool.query(deleteQuery, [reportId]);

        // Update notification to deletion notice
        const notifQuery = `
          UPDATE copyright_notifications 
          SET notification_type = 'deletion_notice',
              message = 'Your content has been confirmed for copyright violation and will be deleted automatically.',
              deletion_deadline = (SELECT scheduled_at FROM auto_delete_queue WHERE report_id = $1 LIMIT 1)
          WHERE report_id = $1
          RETURNING *
        `;
        await pgPool.query(notifQuery, [reportId]);

        // Send deletion notice
        if (report.user_id) {
          await sendPushToUser(report.user_id, {
            title: '🚫 Content Deletion Notice',
            body: 'Your content will be automatically deleted due to copyright violation.',
            icon: '/icon-192.png',
            url: '/copyright-notice'
          });
        }
      }

      res.json({ success: true, report });
    } else {
      res.json({ success: true, warning: 'PostgreSQL not available' });
    }
  } catch (error) {
    console.error('[Copyright] Review error:', error);
    res.status(500).json({ error: 'Failed to review copyright report' });
  }
});

// Auto-delete scheduler - runs every hour
const autoDeleteScheduler = setInterval(async () => {
  if (!pgPool) return;

  try {
    console.log('[Copyright] Running auto-delete scheduler...');

    // Get pending deletions that are due
    const query = `
      SELECT * FROM auto_delete_queue 
      WHERE status = 'pending' 
      AND scheduled_at <= NOW()
      LIMIT 100
    `;
    const result = await pgPool.query(query);
    const pendingDeletions = result.rows;

    for (const deletion of pendingDeletions) {
      try {
        // Mark as processing
        await pgPool.query(
          'UPDATE auto_delete_queue SET status = $1, processed_at = NOW() WHERE id = $2',
          ['processing', deletion.id]
        );

        // Delete content from syncStore (in-memory)
        let deleted = false;

        if (deletion.content_type === 'post' || deletion.content_type === 'text') {
          const post = syncStore.posts.get(deletion.content_id);
          if (post) {
            syncStore.posts.delete(deletion.content_id);
            deleted = true;
            console.log(`[Copyright] Deleted post: ${deletion.content_id}`);
          }
        } else if (deletion.content_type === 'media' || deletion.content_type === 'video' || deletion.content_type === 'audio' || deletion.content_type === 'photo') {
          const media = syncStore.media.get(deletion.content_id);
          if (media) {
            syncStore.media.delete(deletion.content_id);
            deleted = true;
            console.log(`[Copyright] Deleted media: ${deletion.content_id}`);
          }
        }

        // If content was deleted from Cloudinary, you would add that logic here
        // For now, we'll just update the database

        // Mark as completed
        if (deleted) {
          await pgPool.query(
            'UPDATE auto_delete_queue SET status = $1 WHERE id = $2',
            ['completed', deletion.id]
          );

          // Update violation status
          await pgPool.query(
            'UPDATE copyright_violations SET status = $1, auto_delete_completed_at = NOW() WHERE report_id = $2',
            ['resolved', deletion.report_id]
          );

          // Send final notification
          await sendPushToUser(deletion.user_id, {
            title: '✅ Content Deleted',
            body: 'Your copyrighted content has been automatically removed.',
            icon: '/icon-192.png',
            url: '/copyright-notice'
          });

          // Check if user should be marked as copyright-free
          const activeViolationsQuery = `
            SELECT COUNT(*) as count FROM copyright_violations 
            WHERE user_id = $1 AND status = 'active'
          `;
          const activeResult = await pgPool.query(activeViolationsQuery, [deletion.user_id]);
          const activeCount = parseInt(activeResult.rows[0].count);

          if (activeCount === 0) {
            await pgPool.query('SELECT mark_user_copyright_free($1)', [deletion.user_id]);
            console.log(`[Copyright] User ${deletion.user_id} marked as copyright-free`);
          }
        } else {
          // Mark as failed with retry
          await pgPool.query(
            'UPDATE auto_delete_queue SET status = $1, error_message = $2, retry_count = retry_count + 1 WHERE id = $3',
            ['failed', 'Content not found in syncStore', deletion.id]
          );
        }
      } catch (error) {
        console.error(`[Copyright] Error processing deletion ${deletion.id}:`, error);
        await pgPool.query(
          'UPDATE auto_delete_queue SET status = $1, error_message = $2, retry_count = retry_count + 1 WHERE id = $3',
          ['failed', error.message, deletion.id]
        );
      }
    }

    console.log(`[Copyright] Auto-delete scheduler completed. Processed ${pendingDeletions.length} items.`);
  } catch (error) {
    console.error('[Copyright] Scheduler error:', error);
  }
}, 60 * 60 * 1000); // Run every hour

// Get auto-delete queue status (admin)
app.get('/api/copyright/delete-queue', requireAdmin, async (req, res) => {
  try {
    if (pgPool) {
      const query = `
        SELECT * FROM auto_delete_queue 
        ORDER BY scheduled_at ASC 
        LIMIT 100
      `;
      const result = await pgPool.query(query);
      res.json({ queue: result.rows });
    } else {
      res.json({ queue: [] });
    }
  } catch (error) {
    console.error('[Copyright] Get queue error:', error);
    res.status(500).json({ error: 'Failed to get delete queue' });
  }
});

// Manual trigger for content deletion (admin)
app.post('/api/copyright/delete-now', requireAdmin, async (req, res) => {
  try {
    const { contentId, contentType, userId } = req.body;

    // Delete from syncStore
    let deleted = false;
    if (contentType === 'post' || contentType === 'text') {
      if (syncStore.posts.has(contentId)) {
        syncStore.posts.delete(contentId);
        deleted = true;
      }
    } else if (syncStore.media && syncStore.media.has(contentId)) {
      syncStore.media.delete(contentId);
      deleted = true;
    }

    if (deleted) {
      // Send notification
      if (userId) {
        await sendPushToUser(userId, {
          title: '🚫 Content Removed',
          body: 'Your content has been removed due to copyright violation.',
          icon: '/icon-192.png',
          url: '/copyright-notice'
        });
      }

      res.json({ success: true, message: 'Content deleted successfully' });
    } else {
      res.status(404).json({ error: 'Content not found' });
    }
  } catch (error) {
    console.error('[Copyright] Manual delete error:', error);
    res.status(500).json({ error: 'Failed to delete content' });
  }
});

// ── ADVANCED COPYRIGHT FEATURES ──────────────────────────────────────────────

// AI-based Content Detection System
app.post('/api/copyright/ai-detect', async (req, res) => {
  try {
    const { contentId, contentType, contentData, contentUrl } = req.body;

    if (!contentId || !contentType) {
      return res.status(400).json({ error: 'contentId and contentType required' });
    }

    // AI Detection using OpenAI or TensorFlow
    let detectionResult = {
      isFlagged: false,
      confidenceScore: 0,
      flagReason: '',
      detectionType: 'copyright'
    };

    if (OPENAI_KEY && contentData) {
      try {
        const prompt = `Analyze this content for potential copyright violations. Respond with JSON: {"isFlagged": boolean, "confidenceScore": number (0-100), "flagReason": string, "detectionType": string}. Content: ${typeof contentData === 'string' ? contentData.substring(0, 500) : '[binary data]'}`;

        const response = await fetch('https://api.openai.com/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${OPENAI_KEY}`
          },
          body: JSON.stringify({
            model: 'gpt-4o-mini',
            messages: [{ role: 'user', content: prompt }],
            max_tokens: 200,
            temperature: 0.3
          })
        });

        const data = await response.json();
        if (data.choices && data.choices[0]) {
          try {
            const aiResult = JSON.parse(data.choices[0].message.content);
            detectionResult = {
              isFlagged: aiResult.isFlagged || false,
              confidenceScore: aiResult.confidenceScore || 0,
              flagReason: aiResult.flagReason || '',
              detectionType: aiResult.detectionType || 'copyright'
            };
          } catch (parseError) {
            console.error('[Copyright] AI response parse error:', parseError);
          }
        }
      } catch (aiError) {
        console.error('[Copyright] AI detection error:', aiError);
      }
    }

    // Store detection result in database
    if (pgPool) {
      const query = `
        INSERT INTO ai_detection_results 
        (content_id, content_type, detection_type, confidence_score, is_flagged, flag_reason, model_used, model_version, detection_metadata)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
        RETURNING *
      `;
      const values = [
        contentId,
        contentType,
        detectionResult.detectionType,
        detectionResult.confidenceScore,
        detectionResult.isFlagged,
        detectionResult.flagReason,
        'gpt-4o-mini',
        '1.0',
        JSON.stringify({ contentUrl, timestamp: new Date().toISOString() })
      ];
      const result = await pgPool.query(query, values);
      detectionResult.id = result.rows[0].id;
    }

    // If flagged with high confidence, auto-report
    if (detectionResult.isFlagged && detectionResult.confidenceScore > 70) {
      const userId = req.body.userId || 'system';
      await pgPool.query(`
        INSERT INTO copyright_reports 
        (user_id, reported_by, content_type, content_id, content_url, report_reason, severity, report_status)
        VALUES ($1, $2, $3, $4, $5, $6, $7, 'pending')
      `, [userId, 'ai_system', contentType, contentId, contentUrl, `AI detected: ${detectionResult.flagReason}`, detectionResult.confidenceScore > 90 ? 'critical' : 'high']);
    }

    res.json({ success: true, detection: detectionResult });
  } catch (error) {
    console.error('[Copyright] AI detection error:', error);
    res.status(500).json({ error: 'AI detection failed' });
  }
});

// Content Fingerprinting for Duplicate Detection
app.post('/api/copyright/fingerprint', async (req, res) => {
  try {
    const { contentId, contentType, contentData } = req.body;

    if (!contentId || !contentType || !contentData) {
      return res.status(400).json({ error: 'contentId, contentType, and contentData required' });
    }

    // Generate fingerprint hash
    const crypto = require('crypto');
    const fingerprintHash = crypto
      .createHash('sha256')
      .update(typeof contentData === 'string' ? contentData : JSON.stringify(contentData))
      .digest('hex');

    // Check if fingerprint already exists (duplicate detection)
    let isDuplicate = false;
    let existingContent = null;

    if (pgPool) {
      const existingQuery = `
        SELECT * FROM content_fingerprints 
        WHERE fingerprint_hash = $1 AND is_blacklisted = true
        LIMIT 1
      `;
      const existingResult = await pgPool.query(existingQuery, [fingerprintHash]);

      if (existingResult.rows.length > 0) {
        isDuplicate = true;
        existingContent = existingResult.rows[0];
      }

      // Insert new fingerprint
      const insertQuery = `
        INSERT INTO content_fingerprints 
        (content_id, content_type, fingerprint_hash, fingerprint_algorithm, metadata, confidence_score)
        VALUES ($1, $2, $3, $4, $5, $6)
        ON CONFLICT (fingerprint_hash) DO UPDATE SET
          last_scanned_at = NOW(),
          content_id = $1
        RETURNING *
      `;
      const insertResult = await pgPool.query(insertQuery, [
        contentId,
        contentType,
        fingerprintHash,
        'sha256',
        JSON.stringify({ size: typeof contentData === 'string' ? contentData.length : 'binary' }),
        isDuplicate ? 100 : 0
      ]);

      res.json({
        success: true,
        fingerprint: insertResult.rows[0],
        isDuplicate,
        existingContent,
        warning: isDuplicate ? 'This content matches blacklisted content' : null
      });
    } else {
      res.json({ success: true, fingerprintHash, isDuplicate: false });
    }
  } catch (error) {
    console.error('[Copyright] Fingerprint error:', error);
    res.status(500).json({ error: 'Fingerprint generation failed' });
  }
});

// Real-time Content Scanning Queue
app.post('/api/copyright/scan', async (req, res) => {
  try {
    const { contentId, contentType, contentUrl, scanType = 'all', priority = 5 } = req.body;

    if (!contentId || !contentType) {
      return res.status(400).json({ error: 'contentId and contentType required' });
    }

    if (pgPool) {
      const query = `
        INSERT INTO content_scan_queue 
        (content_id, content_type, content_url, scan_type, priority, status)
        VALUES ($1, $2, $3, $4, $5, 'pending')
        RETURNING *
      `;
      const result = await pgPool.query(query, [contentId, contentType, contentUrl, scanType, priority]);

      res.json({ success: true, scanTask: result.rows[0] });
    } else {
      res.json({ success: true, warning: 'PostgreSQL not available' });
    }
  } catch (error) {
    console.error('[Copyright] Scan queue error:', error);
    res.status(500).json({ error: 'Failed to add to scan queue' });
  }
});

// Process Scan Queue (runs every 5 minutes)
const scanQueueProcessor = setInterval(async () => {
  if (!pgPool) return;

  try {
    console.log('[Copyright] Processing scan queue...');

    const query = `
      SELECT * FROM content_scan_queue 
      WHERE status = 'pending' 
      ORDER BY priority ASC, created_at ASC 
      LIMIT 20
    `;
    const result = await pgPool.query(query);
    const pendingScans = result.rows;

    for (const scan of pendingScans) {
      try {
        // Mark as scanning
        await pgPool.query(
          'UPDATE content_scan_queue SET status = $1, started_at = NOW() WHERE id = $2',
          ['scanning', scan.id]
        );

        // Perform AI detection
        const detectionResponse = await fetch('http://localhost:3000/api/copyright/ai-detect', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            contentId: scan.content_id,
            contentType: scan.content_type,
            contentUrl: scan.content_url,
            scanType: scan.scan_type
          })
        });

        const detectionData = await detectionResponse.json();

        // Update scan result
        await pgPool.query(
          'UPDATE content_scan_queue SET status = $1, scan_result = $2, completed_at = NOW() WHERE id = $3',
          ['completed', JSON.stringify(detectionData), scan.id]
        );

        console.log(`[Copyright] Scan completed for ${scan.content_id}`);
      } catch (error) {
        console.error(`[Copyright] Scan error for ${scan.content_id}:`, error);
        await pgPool.query(
          'UPDATE content_scan_queue SET status = $1, error_message = $2, retry_count = retry_count + 1 WHERE id = $3',
          ['failed', error.message, scan.id]
        );
      }
    }

    console.log(`[Copyright] Scan queue processed ${pendingScans.length} items`);
  } catch (error) {
    console.error('[Copyright] Scan queue processor error:', error);
  }
}, 5 * 60 * 1000); // Every 5 minutes

// Multi-level Warning System
app.post('/api/copyright/warning', requireAdmin, async (req, res) => {
  try {
    const { userId, warningType, warningMessage, warningLevel = 1, expiresInDays = 30 } = req.body;

    if (!userId || !warningType || !warningMessage) {
      return res.status(400).json({ error: 'userId, warningType, and warningMessage required' });
    }

    if (pgPool) {
      const expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + expiresInDays);

      const query = `
        INSERT INTO user_warnings 
        (user_id, warning_level, warning_type, warning_message, expires_at, is_active)
        VALUES ($1, $2, $3, $4, $5, true)
        RETURNING *
      `;
      const result = await pgPool.query(query, [userId, warningLevel, warningType, warningMessage, expiresAt]);

      // Send notification to user
      await sendPushToUser(userId, {
        title: `⚠️ Warning Level ${warningLevel}`,
        body: warningMessage,
        icon: '/icon-192.png',
        url: '/warnings'
      });

      res.json({ success: true, warning: result.rows[0] });
    } else {
      res.json({ success: true, warning: 'PostgreSQL not available' });
    }
  } catch (error) {
    console.error('[Copyright] Warning error:', error);
    res.status(500).json({ error: 'Failed to create warning' });
  }
});

// Get User Warnings
app.get('/api/copyright/warnings/:userId', async (req, res) => {
  try {
    const { userId } = req.params;

    if (pgPool) {
      const query = `
        SELECT * FROM user_warnings 
        WHERE user_id = $1 AND is_active = true 
        ORDER BY created_at DESC
      `;
      const result = await pgPool.query(query, [userId]);
      res.json({ warnings: result.rows });
    } else {
      res.json({ warnings: [] });
    }
  } catch (error) {
    console.error('[Copyright] Get warnings error:', error);
    res.status(500).json({ error: 'Failed to get warnings' });
  }
});

// User Reputation System
app.get('/api/copyright/reputation/:userId', async (req, res) => {
  try {
    const { userId } = req.params;

    if (pgPool) {
      const query = `
        SELECT * FROM user_reputation 
        WHERE user_id = $1
      `;
      const result = await pgPool.query(query, [userId]);
      const reputation = result.rows[0] || {
        userId,
        reputationScore: 100,
        trustLevel: 'trusted',
        totalReportsSubmitted: 0,
        accurateReports: 0,
        falseReports: 0,
        reportAccuracyRate: 100.00,
        totalViolations: 0,
        consecutiveCleanDays: 0
      };
      res.json({ reputation });
    } else {
      res.json({
        reputation: {
          userId,
          reputationScore: 100,
          trustLevel: 'trusted'
        }
      });
    }
  } catch (error) {
    console.error('[Copyright] Get reputation error:', error);
    res.status(500).json({ error: 'Failed to get reputation' });
  }
});

// Update User Reputation
app.post('/api/copyright/reputation/update', requireAdmin, async (req, res) => {
  try {
    const { userId, action, metadata = {} } = req.body;

    if (!userId || !action) {
      return res.status(400).json({ error: 'userId and action required' });
    }

    if (pgPool) {
      let scoreChange = 0;
      let trustLevelChange = null;

      switch (action) {
        case 'accurate_report':
          scoreChange = 5;
          break;
        case 'false_report':
          scoreChange = -10;
          break;
        case 'violation':
          scoreChange = -20;
          break;
        case 'clean_day':
          scoreChange = 1;
          break;
        case 'appeal_approved':
          scoreChange = 15;
          break;
        default:
          scoreChange = 0;
      }

      const query = `
        INSERT INTO user_reputation 
        (user_id, reputation_score, trust_level, total_reports_submitted, accurate_reports, false_reports, total_violations, consecutive_clean_days, reputation_history)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
        ON CONFLICT (user_id) DO UPDATE SET
          reputation_score = GREATEST(0, LEAST(100, user_reputation.reputation_score + $2)),
          trust_level = CASE 
            WHEN user_reputation.reputation_score + $2 >= 80 THEN 'trusted'
            WHEN user_reputation.reputation_score + $2 >= 50 THEN 'warning'
            WHEN user_reputation.reputation_score + $2 >= 20 THEN 'suspicious'
            ELSE 'blocked'
          END,
          total_reports_submitted = user_reputation.total_reports_submitted + $4,
          accurate_reports = user_reputation.accurate_reports + $5,
          false_reports = user_reputation.false_reports + $6,
          total_violations = user_reputation.total_violations + $7,
          consecutive_clean_days = user_reputation.consecutive_clean_days + $8,
          reputation_history = user_reputation.reputation_history || $9,
          last_activity_date = NOW()
        RETURNING *
      `;

      const values = [
        userId,
        scoreChange,
        'trusted',
        action === 'accurate_report' || action === 'false_report' ? 1 : 0,
        action === 'accurate_report' ? 1 : 0,
        action === 'false_report' ? 1 : 0,
        action === 'violation' ? 1 : 0,
        action === 'clean_day' ? 1 : 0,
        JSON.stringify([{ action, scoreChange, timestamp: new Date().toISOString(), metadata }])
      ];

      const result = await pgPool.query(query, values);
      res.json({ success: true, reputation: result.rows[0] });
    } else {
      res.json({ success: true, warning: 'PostgreSQL not available' });
    }
  } catch (error) {
    console.error('[Copyright] Update reputation error:', error);
    res.status(500).json({ error: 'Failed to update reputation' });
  }
});

// Appeal System
app.post('/api/copyright/appeal', async (req, res) => {
  try {
    const { reportId, userId, appealReason, evidenceUrls = [] } = req.body;

    if (!reportId || !userId || !appealReason) {
      return res.status(400).json({ error: 'reportId, userId, and appealReason required' });
    }

    if (pgPool) {
      const query = `
        INSERT INTO copyright_appeals 
        (report_id, user_id, appeal_reason, evidence_urls, appeal_status)
        VALUES ($1, $2, $3, $4, 'pending')
        RETURNING *
      `;
      const result = await pgPool.query(query, [reportId, userId, appealReason, evidenceUrls]);

      // Notify admins about new appeal
      // (In production, you'd send to specific admin users)

      res.json({ success: true, appeal: result.rows[0] });
    } else {
      res.json({ success: true, warning: 'PostgreSQL not available' });
    }
  } catch (error) {
    console.error('[Copyright] Appeal error:', error);
    res.status(500).json({ error: 'Failed to submit appeal' });
  }
});

// Review Appeal (Admin)
app.post('/api/copyright/appeal/review', requireAdmin, async (req, res) => {
  try {
    const { appealId, status, adminNotes, reviewedBy } = req.body;

    if (!appealId || !status || !['approved', 'rejected'].includes(status)) {
      return res.status(400).json({ error: 'Invalid appeal status' });
    }

    if (pgPool) {
      const query = `
        UPDATE copyright_appeals 
        SET appeal_status = $1, admin_notes = $2, reviewed_by = $3, reviewed_at = NOW(), updated_at = NOW()
        WHERE id = $4
        RETURNING *
      `;
      const result = await pgPool.query(query, [status, adminNotes, reviewedBy, appealId]);
      const appeal = result.rows[0];

      // If approved, restore content and update reputation
      if (status === 'approved') {
        // Get the original report
        const reportQuery = 'SELECT * FROM copyright_reports WHERE id = $1';
        const reportResult = await pgPool.query(reportQuery, [appeal.report_id]);
        const report = reportResult.rows[0];

        if (report) {
          // Update reputation
          await pgPool.query('SELECT mark_user_copyright_free($1)', [report.user_id]);

          // Update reputation score
          await fetch('http://localhost:3000/api/copyright/reputation/update', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              userId: report.user_id,
              action: 'appeal_approved',
              metadata: { appealId, reportId: report.id }
            })
          });

          // Notify user
          await sendPushToUser(report.user_id, {
            title: '✅ Appeal Approved',
            body: 'Your copyright appeal has been approved. Your reputation has been restored.',
            icon: '/icon-192.png',
            url: '/copyright-notice'
          });
        }
      }

      res.json({ success: true, appeal });
    } else {
      res.json({ success: true, warning: 'PostgreSQL not available' });
    }
  } catch (error) {
    console.error('[Copyright] Appeal review error:', error);
    res.status(500).json({ error: 'Failed to review appeal' });
  }
});

// Content Whitelist System
app.post('/api/copyright/whitelist', requireAdmin, async (req, res) => {
  try {
    const { contentId, contentType, whitelistedBy, whitelistReason, isPermanent = false, expiryDays = 30 } = req.body;

    if (!contentId || !contentType || !whitelistedBy) {
      return res.status(400).json({ error: 'contentId, contentType, and whitelistedBy required' });
    }

    if (pgPool) {
      const expiryDate = isPermanent ? null : new Date(Date.now() + expiryDays * 24 * 60 * 60 * 1000);

      const query = `
        INSERT INTO content_whitelist 
        (content_id, content_type, whitelisted_by, whitelist_reason, expiry_date, is_permanent)
        VALUES ($1, $2, $3, $4, $5, $6)
        RETURNING *
      `;
      const result = await pgPool.query(query, [contentId, contentType, whitelistedBy, whitelistReason, expiryDate, isPermanent]);

      res.json({ success: true, whitelist: result.rows[0] });
    } else {
      res.json({ success: true, warning: 'PostgreSQL not available' });
    }
  } catch (error) {
    console.error('[Copyright] Whitelist error:', error);
    res.status(500).json({ error: 'Failed to whitelist content' });
  }
});

// Check if content is whitelisted
app.get('/api/copyright/whitelist/check/:contentId', async (req, res) => {
  try {
    const { contentId } = req.params;

    if (pgPool) {
      const query = `
        SELECT * FROM content_whitelist 
        WHERE content_id = $1 
        AND (is_permanent = true OR expiry_date > NOW())
        LIMIT 1
      `;
      const result = await pgPool.query(query, [contentId]);
      const isWhitelisted = result.rows.length > 0;

      res.json({ isWhitelisted, whitelist: isWhitelisted ? result.rows[0] : null });
    } else {
      res.json({ isWhitelisted: false });
    }
  } catch (error) {
    console.error('[Copyright] Whitelist check error:', error);
    res.status(500).json({ error: 'Failed to check whitelist' });
  }
});

// Blacklisted Sources Management
app.post('/api/copyright/blacklist-source', requireAdmin, async (req, res) => {
  try {
    const { sourceName, sourceUrl, sourceType, blacklistReason, addedBy, severity = 'medium' } = req.body;

    if (!sourceName || !sourceType || !blacklistReason || !addedBy) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    if (pgPool) {
      const query = `
        INSERT INTO blacklisted_sources 
        (source_name, source_url, source_type, blacklist_reason, added_by, severity)
        VALUES ($1, $2, $3, $4, $5, $6)
        ON CONFLICT (source_name) DO UPDATE SET
          source_url = $2,
          blacklist_reason = $4,
          severity = $6,
          is_active = true,
          updated_at = NOW()
        RETURNING *
      `;
      const result = await pgPool.query(query, [sourceName, sourceUrl, sourceType, blacklistReason, addedBy, severity]);

      res.json({ success: true, blacklistedSource: result.rows[0] });
    } else {
      res.json({ success: true, warning: 'PostgreSQL not available' });
    }
  } catch (error) {
    console.error('[Copyright] Blacklist source error:', error);
    res.status(500).json({ error: 'Failed to blacklist source' });
  }
});

// Check if source is blacklisted
app.get('/api/copyright/blacklist/check/:sourceName', async (req, res) => {
  try {
    const { sourceName } = req.params;

    if (pgPool) {
      const query = `
        SELECT * FROM blacklisted_sources 
        WHERE source_name = $1 AND is_active = true
        LIMIT 1
      `;
      const result = await pgPool.query(query, [sourceName]);
      const isBlacklisted = result.rows.length > 0;

      res.json({ isBlacklisted, source: isBlacklisted ? result.rows[0] : null });
    } else {
      res.json({ isBlacklisted: false });
    }
  } catch (error) {
    console.error('[Copyright] Blacklist check error:', error);
    res.status(500).json({ error: 'Failed to check blacklist' });
  }
});

// Advanced Analytics Dashboard
app.get('/api/copyright/analytics', requireAdmin, async (req, res) => {
  try {
    const { startDate, endDate, period = 'daily' } = req.query;

    if (pgPool) {
      let query = `
        SELECT * FROM copyright_analytics 
        WHERE date >= $1 AND date <= $2
        ORDER BY date DESC
      `;

      const start = startDate || new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
      const end = endDate || new Date().toISOString().split('T')[0];

      const result = await pgPool.query(query, [start, end]);

      // Calculate summary statistics
      const summary = {
        totalReports: result.rows.reduce((sum, row) => sum + (row.total_reports || 0), 0),
        confirmedViolations: result.rows.reduce((sum, row) => sum + (row.confirmed_violations || 0), 0),
        falseReports: result.rows.reduce((sum, row) => sum + (row.false_reports || 0), 0),
        autoDeletions: result.rows.reduce((sum, row) => sum + (row.auto_deletions || 0), 0),
        manualDeletions: result.rows.reduce((sum, row) => sum + (row.manual_deletions || 0), 0),
        appealsSubmitted: result.rows.reduce((sum, row) => sum + (row.appeals_submitted || 0), 0),
        appealsApproved: result.rows.reduce((sum, row) => sum + (row.appeals_approved || 0), 0),
        usersFlagged: result.rows.reduce((sum, row) => sum + (row.users_flagged || 0), 0),
        usersCleared: result.rows.reduce((sum, row) => sum + (row.users_cleared || 0), 0),
        accuracyRate: result.rows.length > 0 ?
          (result.rows.reduce((sum, row) => sum + (row.confirmed_violations || 0), 0) /
            Math.max(1, result.rows.reduce((sum, row) => sum + (row.total_reports || 0), 0)) * 100).toFixed(2) : 0
      };

      res.json({
        analytics: result.rows,
        summary,
        period: { start, end, granularity: period }
      });
    } else {
      res.json({ analytics: [], summary: {} });
    }
  } catch (error) {
    console.error('[Copyright] Analytics error:', error);
    res.status(500).json({ error: 'Failed to get analytics' });
  }
});

// Daily Analytics Aggregation (runs at midnight)
const dailyAnalyticsAggregator = setInterval(async () => {
  if (!pgPool) return;

  try {
    const today = new Date().toISOString().split('T')[0];

    // Check if analytics already exist for today
    const existingQuery = 'SELECT id FROM copyright_analytics WHERE date = $1';
    const existingResult = await pgPool.query(existingQuery, [today]);

    if (existingResult.rows.length > 0) {
      console.log('[Copyright] Analytics already exist for today, skipping');
      return;
    }

    // Aggregate today's data
    const reportsQuery = `
      SELECT 
        COUNT(*) as total_reports,
        COUNT(*) FILTER (WHERE report_status = 'confirmed') as confirmed_violations,
        COUNT(*) FILTER (WHERE report_status = 'rejected') as false_reports,
        COUNT(*) FILTER (WHERE severity = 'critical') as critical_count,
        COUNT(*) FILTER (WHERE severity = 'high') as high_count,
        COUNT(*) FILTER (WHERE severity = 'medium') as medium_count,
        COUNT(*) FILTER (WHERE severity = 'low') as low_count
      FROM copyright_reports 
      WHERE DATE(created_at) = $1
    `;
    const reportsResult = await pgPool.query(reportsQuery, [today]);
    const reportsData = reportsResult.rows[0];

    const deletionsQuery = `
      SELECT 
        COUNT(*) FILTER (WHERE status = 'completed') as auto_deletions,
        COUNT(*) FILTER (WHERE status = 'completed' AND error_message IS NULL) as manual_deletions
      FROM auto_delete_queue 
      WHERE DATE(processed_at) = $1
    `;
    const deletionsResult = await pgPool.query(deletionsQuery, [today]);
    const deletionsData = deletionsResult.rows[0];

    const appealsQuery = `
      SELECT 
        COUNT(*) as appeals_submitted,
        COUNT(*) FILTER (WHERE appeal_status = 'approved') as appeals_approved
      FROM copyright_appeals 
      WHERE DATE(created_at) = $1
    `;
    const appealsResult = await pgPool.query(appealsQuery, [today]);
    const appealsData = appealsResult.rows[0];

    const usersQuery = `
      SELECT 
        COUNT(DISTINCT user_id) FILTER (WHERE report_status = 'confirmed') as users_flagged,
        COUNT(DISTINCT user_id) FILTER (WHERE is_copyright_free = true) as users_cleared
      FROM copyright_reports cr
      LEFT JOIN user_copyright_status ucs ON cr.user_id = ucs.user_id
      WHERE DATE(cr.created_at) = $1
    `;
    const usersResult = await pgPool.query(usersQuery, [today]);
    const usersData = usersResult.rows[0];

    const contentTypeQuery = `
      SELECT 
        content_type,
        COUNT(*) as count
      FROM copyright_reports 
      WHERE DATE(created_at) = $1
      GROUP BY content_type
    `;
    const contentTypeResult = await pgPool.query(contentTypeQuery, [today]);
    const contentTypeBreakdown = {};
    contentTypeResult.rows.forEach(row => {
      contentTypeBreakdown[row.content_type] = row.count;
    });

    const insertQuery = `
      INSERT INTO copyright_analytics 
      (date, total_reports, confirmed_violations, false_reports, auto_deletions, manual_deletions, 
       appeals_submitted, appeals_approved, users_flagged, users_cleared, content_type_breakdown, severity_breakdown)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
    `;

    const severityBreakdown = {
      critical: reportsData.critical_count || 0,
      high: reportsData.high_count || 0,
      medium: reportsData.medium_count || 0,
      low: reportsData.low_count || 0
    };

    await pgPool.query(insertQuery, [
      today,
      reportsData.total_reports || 0,
      reportsData.confirmed_violations || 0,
      reportsData.false_reports || 0,
      deletionsData.auto_deletions || 0,
      deletionsData.manual_deletions || 0,
      appealsData.appeals_submitted || 0,
      appealsData.appeals_approved || 0,
      usersData.users_flagged || 0,
      usersData.users_cleared || 0,
      JSON.stringify(contentTypeBreakdown),
      JSON.stringify(severityBreakdown)
    ]);

    console.log('[Copyright] Daily analytics aggregated successfully');
  } catch (error) {
    console.error('[Copyright] Analytics aggregation error:', error);
  }
}, 24 * 60 * 60 * 1000); // Every 24 hours

// ── Start ──────────────────────────────────────────────────────
// Lazy initialization for faster startup
async function lazyInit() {
  // Initialize unified storage system (single source of truth) - delayed
  setTimeout(async () => {
    try {
      await unifiedStorage.init();
      console.log('   ✅ Unified Storage System (Single Source of Truth)');

      // Sync existing data from syncStore to unified storage - lazy
      console.log('   🔄 Migrating existing data to unified storage...');

      // Migrate users
      syncStore.users.forEach((userData, userId) => {
        unifiedStorage.setUser(userId, userData);
      });

      // Migrate posts
      syncStore.posts.forEach((postData, postId) => {
        unifiedStorage.setPost(postId, postData);
      });

      // Migrate points
      syncStore.points.forEach((pointsData, userId) => {
        unifiedStorage.setPoints(userId, pointsData);
      });

      // Migrate media
      syncStore.media.forEach((mediaData, mediaId) => {
        unifiedStorage.setMedia(mediaId, mediaData);
      });

      console.log('   ✅ Data migration completed');
    } catch (error) {
      console.error('   ❌ Unified storage initialization failed:', error.message);
    }
  }, 2000); // Delay by 2 seconds to allow server to start faster

  // Initialize video transcoder - lazy
  setTimeout(async () => {
    try {
      const ffmpegAvailable = await videoTranscoder.init();
      if (ffmpegAvailable) {
        console.log('   ✅ FFmpeg Video Transcoding System');
      } else {
        console.log('   ⚠️ FFmpeg not available - video transcoding disabled');
      }
    } catch (error) {
      console.error('   ❌ Video transcoder initialization failed:', error.message);
    }
  }, 3000); // Delay by 3 seconds

  // Load cross-device session data - lazy
  setTimeout(() => {
    try {
      loadSessionsFromFile();
      console.log('   ✅ Cross-device sessions loaded');
    } catch (error) {
      console.error('   ❌ Failed to load sessions:', error.message);
    }
  }, 1000); // Delay by 1 second

  // Initialize ICE servers - lazy
  setTimeout(async () => {
    try {
      await getICE();
      console.log('   ✅ ICE servers initialized');
    } catch (error) {
      console.error('   ❌ ICE initialization failed:', error.message);
    }
  }, 4000); // Delay by 4 seconds

  // Hydrate persistent sync store - lazy
  setTimeout(async () => {
    try {
      await hydratePersistentSyncStore();
      console.log('   ✅ Persistent sync store hydrated');
    } catch (error) {
      console.error('   ❌ Persistent sync store hydration failed:', error.message);
    }
  }, 5000); // Delay by 5 seconds

  // Initialize advanced persistence backup system - lazy
  setTimeout(() => {
    try {
      console.log('   ✅ Advanced Persistence Backup System Ready');
      setupAdvancedPersistenceEndpoints();
    } catch (error) {
      console.error('   ❌ Advanced persistence initialization failed:', error.message);
    }
  }, 6000); // Delay by 6 seconds
}

// Advanced persistence API endpoints
function setupAdvancedPersistenceEndpoints() {
  // Get user data versions
  app.get('/api/persistence/versions/:userId', async (req, res) => {
    try {
      const { userId } = req.params;
      const userPosts = unifiedStorage.getPostsByAuthor(userId);
      const user = unifiedStorage.getUser(userId);

      const versions = {
        userId: userId,
        posts: userPosts.map(post => ({
          id: post.id,
          lastModified: post.lastUpdated || post.createdAt,
          version: post.version || 1
        })),
        user: user ? {
          id: user.id,
          lastModified: user.lastUpdated || Date.now(),
          version: user.version || 1
        } : null,
        timestamp: Date.now()
      };

      res.json({ success: true, versions });
    } catch (error) {
      console.error('[Persistence] Get versions error:', error);
      res.status(500).json({ error: 'Failed to get versions' });
    }
  });

  // Create backup
  app.post('/api/persistence/backup', async (req, res) => {
    try {
      const { userId, type = 'manual' } = req.body;

      if (!userId) {
        return res.status(400).json({ error: 'userId required' });
      }

      const backupData = {
        id: `backup_${Date.now()}_${userId}`,
        userId: userId,
        type: type,
        timestamp: Date.now(),
        data: {
          user: unifiedStorage.getUser(userId),
          posts: unifiedStorage.getPostsByAuthor(userId),
          points: unifiedStorage.getPoints(userId)
        }
      };

      // Save backup to file system
      const backupDir = path.join(__dirname, 'data', 'backups');
      if (!fs.existsSync(backupDir)) {
        fs.mkdirSync(backupDir, { recursive: true });
      }

      const backupFile = path.join(backupDir, `${backupData.id}.json`);
      fs.writeFileSync(backupFile, JSON.stringify(backupData, null, 2));

      console.log('[Persistence] Backup created:', backupData.id);
      res.json({ success: true, backup: backupData });
    } catch (error) {
      console.error('[Persistence] Backup error:', error);
      res.status(500).json({ error: 'Backup failed' });
    }
  });

  // Restore backup
  app.post('/api/persistence/restore', async (req, res) => {
    try {
      const { backupId } = req.body;

      if (!backupId) {
        return res.status(400).json({ error: 'backupId required' });
      }

      const backupFile = path.join(__dirname, 'data', 'backups', `${backupId}.json`);

      if (!fs.existsSync(backupFile)) {
        return res.status(404).json({ error: 'Backup not found' });
      }

      const backupData = JSON.parse(fs.readFileSync(backupFile, 'utf8'));

      // Restore data
      if (backupData.data.user) {
        unifiedStorage.setUser(backupData.data.user.id, backupData.data.user);
      }

      if (backupData.data.posts) {
        backupData.data.posts.forEach(post => {
          unifiedStorage.setPost(post.id, post);
        });
      }

      if (backupData.data.points) {
        unifiedStorage.setPoints(backupData.userId, backupData.data.points);
      }

      console.log('[Persistence] Backup restored:', backupId);
      res.json({ success: true, restored: backupData });
    } catch (error) {
      console.error('[Persistence] Restore error:', error);
      res.status(500).json({ error: 'Restore failed' });
    }
  });

  // List backups
  app.get('/api/persistence/backups/:userId', async (req, res) => {
    try {
      const { userId } = req.params;
      const backupDir = path.join(__dirname, 'data', 'backups');

      if (!fs.existsSync(backupDir)) {
        return res.json({ success: true, backups: [] });
      }

      const backupFiles = fs.readdirSync(backupDir)
        .filter(file => file.includes(userId) && file.endsWith('.json'))
        .map(file => {
          const filePath = path.join(backupDir, file);
          const stats = fs.statSync(filePath);
          const backupData = JSON.parse(fs.readFileSync(filePath, 'utf8'));

          return {
            id: backupData.id,
            type: backupData.type,
            timestamp: backupData.timestamp,
            size: stats.size,
            createdAt: new Date(backupData.timestamp).toISOString()
          };
        })
        .sort((a, b) => b.timestamp - a.timestamp)
        .slice(0, 20); // Last 20 backups

      res.json({ success: true, backups: backupFiles });
    } catch (error) {
      console.error('[Persistence] List backups error:', error);
      res.status(500).json({ error: 'Failed to list backups' });
    }
  });

  // Sync data
  app.post('/api/persistence/sync', async (req, res) => {
    try {
      const { userId, data, type } = req.body;

      if (!userId || !data) {
        return res.status(400).json({ error: 'userId and data required' });
      }

      let result;
      switch (type) {
        case 'post':
          result = unifiedStorage.setPost(data.id, data);
          break;
        case 'user':
          result = unifiedStorage.setUser(userId, data);
          break;
        case 'points':
          result = unifiedStorage.setPoints(userId, data);
          break;
        default:
          return res.status(400).json({ error: 'Invalid sync type' });
      }

      console.log('[Persistence] Data synced:', type, userId);
      res.json({ success: true, result });
    } catch (error) {
      console.error('[Persistence] Sync error:', error);
      res.status(500).json({ error: 'Sync failed' });
    }
  });

  // Health check
  app.get('/api/persistence/health', async (req, res) => {
    try {
      const stats = unifiedStorage.getStats();
      const backupDir = path.join(__dirname, 'data', 'backups');

      let backupCount = 0;
      if (fs.existsSync(backupDir)) {
        backupCount = fs.readdirSync(backupDir).filter(file => file.endsWith('.json')).length;
      }

      const health = {
        status: 'healthy',
        timestamp: Date.now(),
        storage: stats,
        backups: backupCount,
        uptime: process.uptime(),
        memory: process.memoryUsage()
      };

      res.json({ success: true, health });
    } catch (error) {
      console.error('[Persistence] Health check error:', error);
      res.status(500).json({ error: 'Health check failed' });
    }
  });

  // Global Feed API endpoints
  app.post('/api/posts/sync', async (req, res) => {
    try {
      const { post, userId, timestamp } = req.body;

      if (!post || !userId) {
        return res.status(400).json({ error: 'post and userId required' });
      }

      // Save post to unified storage
      unifiedStorage.setPost(post.id, post);

      // Broadcast to all connected clients
      io.emit('new_post', post);

      console.log('[GlobalFeed] Post synced and broadcasted:', post.id);
      res.json({ success: true, broadcast: true });
    } catch (error) {
      console.error('[GlobalFeed] Post sync error:', error);
      res.status(500).json({ error: 'Post sync failed' });
    }
  });

  app.post('/api/posts/delete-sync', async (req, res) => {
    try {
      const { postId, userId, timestamp } = req.body;

      if (!postId || !userId) {
        return res.status(400).json({ error: 'postId and userId required' });
      }

      // Delete post from unified storage
      unifiedStorage.deletePost(postId);

      // Broadcast to all connected clients
      io.emit('post_deleted', postId);

      console.log('[GlobalFeed] Post deletion synced and broadcasted:', postId);
      res.json({ success: true, broadcast: true });
    } catch (error) {
      console.error('[GlobalFeed] Post deletion sync error:', error);
      res.status(500).json({ error: 'Post deletion sync failed' });
    }
  });

  app.post('/api/users/points-sync', async (req, res) => {
    try {
      const { userId, points, timestamp } = req.body;

      if (!userId || points === undefined) {
        return res.status(400).json({ error: 'userId and points required' });
      }

      // Update points in unified storage
      unifiedStorage.setPoints(userId, { points: points });

      // Update user data if exists
      const user = unifiedStorage.getUser(userId);
      if (user) {
        unifiedStorage.setUser(userId, { ...user, points: points });
      }

      // Broadcast to all connected clients
      io.emit('points_updated', { userId, points });

      console.log('[GlobalFeed] Points synced and broadcasted:', userId, points);
      res.json({ success: true, broadcast: true });
    } catch (error) {
      console.error('[GlobalFeed] Points sync error:', error);
      res.status(500).json({ error: 'Points sync failed' });
    }
  });

  app.get('/api/feed/global', async (req, res) => {
    try {
      const { userId, limit = 50 } = req.query;

      // Get all posts from unified storage
      const allPosts = unifiedStorage.getAllPosts();

      // Sort by creation time
      allPosts.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));

      // Limit results
      const limitedPosts = allPosts.slice(0, parseInt(limit));

      // Add user information to posts
      const postsWithUsers = limitedPosts.map(post => {
        const author = unifiedStorage.getUser(post.author);
        return {
          ...post,
          authorName: author ? author.name : 'Unknown',
          authorUsername: author ? author.username : 'unknown'
        };
      });

      console.log('[GlobalFeed] Global feed sent:', postsWithUsers.length, 'posts');
      res.json({ success: true, posts: postsWithUsers });
    } catch (error) {
      console.error('[GlobalFeed] Global feed error:', error);
      res.status(500).json({ error: 'Failed to get global feed' });
    }
  });

  console.log('[Persistence] Advanced persistence endpoints configured');
  console.log('[GlobalFeed] Global feed endpoints configured');
}

// Start lazy initialization
lazyInit();

// ── GraphQL Server Setup ─────────────────────────────────────────────
async function setupGraphQL() {
  try {
    const { setupGraphQLServer } = require('./graphql/server');
    await setupGraphQLServer(app, server);
    console.log('[GraphQL] ✅ GraphQL server initialized');
  } catch (error) {
    console.error('[GraphQL] ❌ Failed to initialize GraphQL server:', error.message);
    console.log('[GraphQL] Continuing without GraphQL support');
  }
}

// Only start server in worker processes or development mode
if (!cluster.isMaster || process.env.NODE_ENV !== 'production') {
  // Setup GraphQL before starting server
  setupGraphQL().then(() => {
    server.listen(PORT, () => {
      console.log(`\n🚀 Monetixra v8.0 — Port ${PORT}`);
      console.log(`   ✅ Socket.io Real-time`);
      console.log(`   ✅ WebRTC Video/Audio`);
      console.log(`   ✅ OpenAI + DeepSeek AI`);
      console.log(`   ✅ Google Translate + Vision`);
      console.log(`   ✅ GraphQL API`);
      console.log(`   ✅ Supabase Database`);
      console.log(`   ✅ Redis Caching`);
      console.log(`   ✅ PostgreSQL Pooling`);
      console.log(`   ✅ Metered TURN Server`);
      console.log(`   ✅ Web Push Notifications`);
      console.log(`   ${BKASH_APP_KEY ? '✅' : '⚠️ '} bKash Payment`);
      console.log(`   ${NAGAD_MERCHANT ? '✅' : '⚠️ '} Nagad Payment`);
      console.log(`   ✅ Rate Limiting + Security`);
      console.log(`   ✅ Cross-Device Synchronization`);
      console.log(`   ✅ Performance Optimizations Active`);
      console.log(`   ✅ Cluster Mode: ${process.env.NODE_ENV === 'production' ? 'Enabled' : 'Disabled'}\n`);

      // Load cross-device session data
      loadSessionsFromFile();
      getICE().catch(e => console.error('[Startup] getICE failed:', e));
      hydratePersistentSyncStore().catch(e => console.error('[Startup] hydratePersistentSyncStore failed:', e));
    });
  }).catch(error => {
    console.error('[Startup] GraphQL setup failed, starting server without GraphQL:', error);
    server.listen(PORT, () => {
      console.log(`\n🚀 Monetixra v8.0 — Port ${PORT}`);
      console.log(`   ✅ Socket.io Real-time`);
      console.log(`   ✅ WebRTC Video/Audio`);
      console.log(`   ✅ OpenAI + DeepSeek AI`);
      console.log(`   ✅ Google Translate + Vision`);
      console.log(`   ⚠️ GraphQL API (Failed to initialize)`);
      console.log(`   ✅ Supabase Database`);
      console.log(`   ✅ Redis Caching`);
      console.log(`   ✅ PostgreSQL Pooling`);
      console.log(`   ✅ Metered TURN Server`);
      console.log(`   ✅ Web Push Notifications`);
      console.log(`   ✅ Rate Limiting + Security`);
      console.log(`   ✅ Cross-Device Synchronization`);
      console.log(`   ✅ Performance Optimizations Active`);
      console.log(`   ✅ Cluster Mode: ${process.env.NODE_ENV === 'production' ? 'Enabled' : 'Disabled'}\n`);

      // Load cross-device session data
      loadSessionsFromFile();
      getICE().catch(e => console.error('[Startup] getICE failed:', e));
      hydratePersistentSyncStore().catch(e => console.error('[Startup] hydratePersistentSyncStore failed:', e));
    });
  });
}

module.exports = { app, server, io };

// ── Stripe Payment ─────────────────────────────────────────
app.post('/api/payment/stripe/create-session', async (req, res) => {
  const STRIPE_SECRET = process.env.STRIPE_SECRET_KEY || '';
  if (!STRIPE_SECRET) return res.json({ demo: true, message: 'Stripe not configured' });
  try {
    const { amount, currency = 'usd', description, userId } = req.body;
    if (!userId) return res.status(400).json({ error: 'userId required' });
    const cents = Math.max(50, Math.trunc(Number(amount || 0)));
    const points = Math.round((cents / 100) * PTS_PER_USD);
    const params = new URLSearchParams();
    params.set('payment_method_types[]', 'card');
    params.set('line_items[0][price_data][currency]', currency);
    params.set('line_items[0][price_data][product_data][name]', description || 'Monetixra Top-up');
    params.set('line_items[0][price_data][unit_amount]', String(cents));
    params.set('line_items[0][quantity]', '1');
    params.set('mode', 'payment');
    params.set('success_url', (process.env.BASE_URL || 'http://localhost:3000') + '/?stripe=success&uid=' + userId);
    params.set('cancel_url', (process.env.BASE_URL || 'http://localhost:3000') + '/?stripe=cancel');
    params.set('metadata[userId]', userId);
    params.set('metadata[description]', description || '');
    params.set('metadata[points]', String(points));
    const r = await fetch('https://api.stripe.com/v1/checkout/sessions', {
      method: 'POST',
      headers: { Authorization: `Bearer ${STRIPE_SECRET}`, 'Content-Type': 'application/x-www-form-urlencoded' },
      body: params
    });
    const session = await r.json();
    if (!r.ok) return res.status(400).json({ error: session.error?.message || 'Stripe session failed' });
    res.json({ sessionId: session.id, url: session.url });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Stripe webhook
app.post('/api/payment/stripe/webhook', express.raw({ type: 'application/json' }), async (req, res) => {
  const STRIPE_SECRET = process.env.STRIPE_SECRET_KEY || '';
  const STRIPE_WH_SEC = process.env.STRIPE_WEBHOOK_SECRET || '';
  if (!STRIPE_SECRET) return res.json({ received: true });
  try {
    const sig = req.headers['stripe-signature'];
    const rawBody = req.rawBody || (Buffer.isBuffer(req.body) ? req.body : Buffer.from(JSON.stringify(req.body || {})));
    if (STRIPE_WH_SEC && !verifyStripeSignature(rawBody, sig, STRIPE_WH_SEC)) return res.status(400).send('Webhook Error: invalid signature');
    const event = JSON.parse(rawBody.toString('utf8'));
    if (event.type === 'checkout.session.completed') {
      const session = event.data.object;
      const userId = session.metadata?.userId;
      const amt = session.amount_total; // cents
      const points = Math.round(Number(session.metadata?.points || ((amt / 100) * PTS_PER_USD)));
      console.log(`[Stripe] Payment completed: $${amt / 100} by ${userId}`);
      if (userId && points > 0) {
        await creditUserPoints(userId, points, `Stripe top-up $${(amt / 100).toFixed(2)}`, 'topup', 'stripe_' + session.id);
      }
    }
    res.json({ received: true });
  } catch (e) { res.status(400).send(`Webhook Error: ${e.message}`); }
});

// ── Video/Audio Transcoding API (FFmpeg) ─────────────────────────────
const transcodingJobs = new Map(); // jobId -> {status, progress, outputUrl}

// Resolution settings for video transcoding
const videoResolutions = {
  '240p': { width: 426, height: 240, bitrate: '500k', vcodec: 'libx264', acodec: 'aac', abitrate: '128k' },
  '360p': { width: 640, height: 360, bitrate: '800k', vcodec: 'libx264', acodec: 'aac', abitrate: '128k' },
  '480p': { width: 854, height: 480, bitrate: '1200k', vcodec: 'libx264', acodec: 'aac', abitrate: '128k' },
  '640p': { width: 854, height: 480, bitrate: '1500k', vcodec: 'libx264', acodec: 'aac', abitrate: '192k' },
  '720p': { width: 1280, height: 720, bitrate: '2500k', vcodec: 'libx264', acodec: 'aac', abitrate: '192k' },
  '1080p': { width: 1920, height: 1080, bitrate: '5000k', vcodec: 'libx264', acodec: 'aac', abitrate: '192k' },
  '2K': { width: 2560, height: 1440, bitrate: '8000k', vcodec: 'libx264', acodec: 'aac', abitrate: '256k' }
};

const audioQualities = {
  '144kbps': { bitrate: '144k', codec: 'libmp3lame' },
  '240kbps': { bitrate: '240k', codec: 'libmp3lame' },
  '320kbps': { bitrate: '320k', codec: 'libmp3lame' }
};

// Check if FFmpeg is available
async function checkFFmpeg() {
  try {
    await execAsync('ffmpeg -version');
    console.log('[FFmpeg] Available ✅');
    return true;
  } catch (e) {
    console.warn('[FFmpeg] Not available - transcoding will be simulated');
    return false;
  }
}

// Transcode video to specified resolution
async function transcodeVideo(inputPath, outputPath, resolution, width, height, bitrate) {
  const res = videoResolutions[resolution] || videoResolutions['720p'];
  const targetWidth = width || res.width;
  const targetHeight = height || res.height;
  const targetBitrate = bitrate || res.bitrate;
  const command = `ffmpeg -i "${inputPath}" -vf scale=${targetWidth}:${targetHeight} -b:v ${targetBitrate} -c:v ${res.vcodec} -c:a ${res.acodec} -b:a ${res.abitrate} -movflags +faststart "${outputPath}" -y`;

  try {
    await execAsync(command);
    return { success: true, outputPath };
  } catch (error) {
    console.error('[FFmpeg] Transcoding error:', error);
    throw error;
  }
}

// Transcode audio to specified quality
async function transcodeAudio(inputPath, outputPath, quality, bitrate) {
  const q = audioQualities[quality] || audioQualities['320kbps'];
  const targetBitrate = bitrate || q.bitrate;
  const command = `ffmpeg -i "${inputPath}" -b:a ${targetBitrate} -c:a ${q.codec} "${outputPath}" -y`;

  try {
    await execAsync(command);
    return { success: true, outputPath };
  } catch (error) {
    console.error('[FFmpeg] Audio transcoding error:', error);
    throw error;
  }
}

// Unified transcoding endpoint
app.post('/api/transcode', async (req, res) => {
  const { type, url, quality, width, height, bitrate } = req.body;

  if (!type || !url || !quality) {
    return res.status(400).json({ error: 'type, url, and quality required' });
  }

  const jobId = `job_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  transcodingJobs.set(jobId, {
    status: 'starting',
    progress: 0,
    type,
    quality,
    width,
    height,
    bitrate,
    createdAt: Date.now()
  });

  // Return job ID immediately
  res.json({ jobId, status: 'started' });

  // Start transcoding in background
  processTranscodingJob(jobId, type, url, quality, width, height, bitrate).catch(err => {
    console.error('[Transcode] Job failed:', jobId, err);
    transcodingJobs.set(jobId, {
      ...transcodingJobs.get(jobId),
      status: 'failed',
      error: err.message
    });
  });
});

// Start transcoding job (legacy endpoint)
app.post('/api/transcode/start', async (req, res) => {
  const { type, url, quality, postId } = req.body;

  if (!type || !url || !quality) {
    return res.status(400).json({ error: 'type, url, and quality required' });
  }

  const jobId = `job_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  transcodingJobs.set(jobId, {
    status: 'starting',
    progress: 0,
    type,
    quality,
    createdAt: Date.now()
  });

  // Return job ID immediately
  res.json({ jobId, status: 'started' });

  // Start transcoding in background
  processTranscodingJob(jobId, type, url, quality, postId).catch(err => {
    console.error('[Transcode] Job failed:', jobId, err);
    transcodingJobs.set(jobId, {
      ...transcodingJobs.get(jobId),
      status: 'failed',
      error: err.message
    });
  });
});

// Process transcoding job
async function processTranscodingJob(jobId, type, url, quality, width, height, bitrate, postId) {
  const ffmpegAvailable = await checkFFmpeg();

  if (!ffmpegAvailable) {
    // Simulate transcoding for demo
    transcodingJobs.set(jobId, { status: 'processing', progress: 0 });

    for (let i = 0; i <= 100; i += 10) {
      await new Promise(resolve => setTimeout(resolve, 200));
      transcodingJobs.set(jobId, {
        status: 'processing',
        progress: i,
        outputUrl: url // Return original URL
      });
    }

    transcodingJobs.set(jobId, {
      status: 'completed',
      progress: 100,
      outputUrl: url,
      downloadUrl: url,
      simulated: true
    });
    return;
  }

  // Real transcoding with FFmpeg
  try {
    const inputPath = path.join(__dirname, 'temp', `input_${jobId}`);
    const outputPath = path.join(__dirname, 'temp', `output_${jobId}.${type === 'video' ? 'mp4' : 'mp3'}`);

    // Ensure temp directory exists
    const tempDir = path.join(__dirname, 'temp');
    if (!fs.existsSync(tempDir)) {
      fs.mkdirSync(tempDir, { recursive: true });
    }

    // Download file
    transcodingJobs.set(jobId, { status: 'downloading', progress: 10 });
    const response = await fetch(url);
    const buffer = Buffer.from(await response.arrayBuffer());
    fs.writeFileSync(inputPath, buffer);

    transcodingJobs.set(jobId, { status: 'transcoding', progress: 30 });

    if (type === 'video') {
      await transcodeVideo(inputPath, outputPath, quality, width, height, bitrate);
    } else if (type === 'audio') {
      await transcodeAudio(inputPath, outputPath, quality, bitrate);
    }

    // Clean up input file
    fs.unlinkSync(inputPath);

    // In production, upload to cloud storage and return URL
    // For now, return local path
    transcodingJobs.set(jobId, {
      status: 'completed',
      progress: 100,
      outputPath,
      outputUrl: `/api/transcode/download/${jobId}`,
      downloadUrl: `/api/transcode/download/${jobId}`
    });

  } catch (error) {
    transcodingJobs.set(jobId, {
      status: 'failed',
      progress: 0,
      error: error.message
    });
  }
}

// Get transcoding job status
app.get('/api/transcode/status/:jobId', (req, res) => {
  const { jobId } = req.params;
  const job = transcodingJobs.get(jobId);

  if (!job) {
    return res.status(404).json({ error: 'Job not found' });
  }

  res.json(job);
});

// Progress polling endpoint (for download system)
app.get('/api/transcode/progress/:jobId', (req, res) => {
  const { jobId } = req.params;
  const job = transcodingJobs.get(jobId);

  if (!job) {
    return res.status(404).json({ error: 'Job not found' });
  }

  res.json({
    status: job.status,
    progress: job.progress || 0,
    error: job.error || null,
    downloadUrl: job.downloadUrl || null
  });
});

// Download transcoded file
app.get('/api/transcode/download/:jobId', (req, res) => {
  const { jobId } = req.params;
  const job = transcodingJobs.get(jobId);

  if (!job || job.status !== 'completed') {
    return res.status(404).json({ error: 'File not ready' });
  }

  if (job.simulated) {
    // Redirect to original URL
    return res.redirect(job.outputUrl);
  }

  if (job.outputPath && fs.existsSync(job.outputPath)) {
    res.download(job.outputPath);
  } else {
    res.status(404).json({ error: 'File not found' });
  }
});

// Clean up old transcoding jobs
setInterval(() => {
  const now = Date.now();
  for (const [jobId, job] of transcodingJobs) {
    // Delete jobs older than 1 hour
    if (now - job.createdAt > 3600000) {
      transcodingJobs.delete(jobId);
      // Clean up output file if exists
      if (job.outputPath && fs.existsSync(job.outputPath)) {
        fs.unlinkSync(job.outputPath);
      }
    }
  }
}, 300000); // Check every 5 minutes

// ── Shared Posts API (Facebook-style feed without Supabase) ─────────────
// Ensure data directory exists
try {
  if (!fs.existsSync(path.join(__dirname, 'data'))) {
    fs.mkdirSync(path.join(__dirname, 'data'), { recursive: true });
  }
  if (!fs.existsSync(POSTS_BACKUP_DIR)) {
    fs.mkdirSync(POSTS_BACKUP_DIR, { recursive: true });
  }
  if (!fs.existsSync(MEDIA_BACKUP_DIR)) {
    fs.mkdirSync(MEDIA_BACKUP_DIR, { recursive: true });
  }
} catch (e) {
  console.warn('[PostsDB] Failed to create data directories:', e.message);
}

// Load functions for file-based storage
function loadPostsFromFile() {
  try {
    if (fs.existsSync(POSTS_DB_FILE)) {
      const data = fs.readFileSync(POSTS_DB_FILE, 'utf8');
      const posts = JSON.parse(data);
      // Clear and update global sharedPosts instead of reassigning
      sharedPosts.clear();
      Object.entries(posts).forEach(([id, post]) => {
        sharedPosts.set(id, post);
      });
      console.log('[PostsDB] Loaded', sharedPosts.size, 'posts from file');

      // Migrate shared posts to unified storage after loading
      sharedPosts.forEach((postData, postId) => {
        unifiedStorage.setPost(postId, postData);
      });
      console.log('[PostsDB] Migrated', sharedPosts.size, 'posts to unified storage');
    } else {
      console.log('[PostsDB] No existing posts file, starting fresh');
    }
  } catch (e) {
    console.error('[PostsDB] Failed to load posts:', e.message);
    // Clear sharedPosts on error
    sharedPosts.clear();
  }
}

function loadUsersFromFile() {
  try {
    if (fs.existsSync(USERS_DB_FILE)) {
      const data = fs.readFileSync(USERS_DB_FILE, 'utf8');
      const users = JSON.parse(data);
      // Clear and reload from global sharedUsers
      sharedUsers.clear();
      Object.entries(users).forEach(([id, user]) => {
        sharedUsers.set(id, user);
      });
      console.log('[UsersDB] Loaded', sharedUsers.size, 'users from file');
    } else {
      console.log('[UsersDB] No existing users file, starting fresh');
    }
  } catch (e) {
    console.error('[UsersDB] Failed to load users:', e.message);
    sharedUsers.clear();
  }
}

function loadMediaFromFile() {
  try {
    if (fs.existsSync(MEDIA_DB_FILE)) {
      const data = fs.readFileSync(MEDIA_DB_FILE, 'utf8');
      const media = JSON.parse(data);
      // Clear and reload from global sharedMedia
      sharedMedia.clear();
      Object.entries(media).forEach(([id, mediaItem]) => {
        sharedMedia.set(id, mediaItem);
      });
      console.log('[MediaDB] Loaded', sharedMedia.size, 'media items from file');
    } else {
      console.log('[MediaDB] No existing media file, starting fresh');
    }
  } catch (e) {
    console.error('[MediaDB] Failed to load media:', e.message);
    sharedMedia.clear();
  }
}

// Load data on server startup
loadPostsFromFile();
loadUsersFromFile();
loadMediaFromFile();

// Sync user data (points, money, etc.) to permanent storage
app.post('/api/users/sync', (req, res) => {
  const { user } = req.body;
  if (!user || !user.id) {
    return res.status(400).json({ error: 'User data required' });
  }

  // Save to unified storage (single source of truth)
  unifiedStorage.setUser(user.id, user);

  // Also save to legacy storage
  syncStore.users.set(user.id, user);
  syncStore.points.set(user.id, { points: user.points || 0, updatedAt: Date.now() });

  console.log('[UserSync] User data synced:', user.id);
  res.json({ success: true, synced: true });
});

// Get full sync data for cross-device synchronization
app.get('/api/sync/full', (req, res) => {
  const since = parseInt(req.query.since) || 0;
  const userId = req.query.userId;

  try {
    // Get full sync from unified storage
    const syncData = unifiedStorage.getFullSync(since);

    // If userId is specified, filter data for that user
    if (userId) {
      const userPosts = syncData.posts ? Object.values(syncData.posts).filter(p => p.author === userId) : [];
      const userData = syncData.users ? syncData.users[userId] : null;
      const userPoints = syncData.points ? syncData.points[userId] : null;

      return res.json({
        success: true,
        user: userData,
        posts: userPosts,
        points: userPoints,
        timestamp: syncData.timestamp,
        source: 'unified'
      });
    }

    res.json({
      success: true,
      ...syncData,
      source: 'unified'
    });
  } catch (error) {
    console.error('[SyncFull] Error:', error);
    res.status(500).json({ error: 'Sync failed', detail: error.message });
  }
});

// Apply sync data from client (for cross-device consistency)
app.post('/api/sync/apply', (req, res) => {
  const { syncData } = req.body;
  if (!syncData) {
    return res.status(400).json({ error: 'Sync data required' });
  }

  try {
    const updates = unifiedStorage.applySync(syncData);

    // Also update legacy storage for consistency
    if (syncData.users) {
      Object.entries(syncData.users).forEach(([key, userData]) => {
        syncStore.users.set(key, userData);
      });
    }

    if (syncData.posts) {
      Object.entries(syncData.posts).forEach(([key, postData]) => {
        syncStore.posts.set(key, postData);
        sharedPosts.set(key, postData);
      });
    }

    if (syncData.points) {
      Object.entries(syncData.points).forEach(([key, pointsData]) => {
        syncStore.points.set(key, pointsData);
      });
    }

    savePostsToFile();

    console.log('[SyncApply] Applied', updates, 'updates from client');
    res.json({ success: true, updates, source: 'unified' });
  } catch (error) {
    console.error('[SyncApply] Error:', error);
    res.status(500).json({ error: 'Sync apply failed', detail: error.message });
  }
});

// Get user data by ID
app.get('/api/users/:userId', (req, res) => {
  const { userId } = req.params;
  const user = sharedUsers.get(userId);

  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }

  res.json({ success: true, user });
});

// Save post to shared storage (permanent) - with enhanced global synchronization
app.post('/api/posts/create', (req, res) => {
  const { post } = req.body;
  if (!post || !post.id) {
    return res.status(400).json({ error: 'Post data required' });
  }

  // Ensure post has required fields for global distribution
  const enhancedPost = {
    ...post,
    global: true, // Mark as globally distributed
    visibility: post.visibility || 'public', // Default to public
    syncedAt: Date.now(),
    distributedAt: Date.now()
  };

  // Save to unified storage (single source of truth)
  unifiedStorage.setPost(enhancedPost.id, enhancedPost);

  // Also save to legacy storage
  sharedPosts.set(enhancedPost.id, enhancedPost);
  syncStore.posts.set(enhancedPost.id, enhancedPost); // Add to syncStore for backward compatibility
  savePostsToFile(); // Persist to disk

  console.log('[PostsDB] Post saved permanently:', enhancedPost.id, 'by', enhancedPost.author, 'visibility:', enhancedPost.visibility);

  // Broadcast to ALL connected socket.io clients for real-time global distribution
  io.emit('post:new', { post: enhancedPost, source: 'global', timestamp: Date.now() });

  // Also broadcast to specific user's all sessions for cross-device sync
  if (enhancedPost.author) {
    emitToUser(enhancedPost.author, 'post:created', { post: enhancedPost, timestamp: Date.now() });
  }

  // Invalidate live feed cache to force refresh
  RedisCache.delPattern('live:feed:*').catch(e => console.warn('[PostsDB] Failed to invalidate cache:', e));

  res.json({
    success: true,
    postId: enhancedPost.id,
    globalDistribution: true,
    visibility: enhancedPost.visibility,
    timestamp: Date.now()
  });
});

// GET /api/sync/status - Check synchronization status across all storage systems
app.get('/api/sync/status', (req, res) => {
  try {
    const unifiedPosts = unifiedStorage.getAllPosts();
    const legacyPosts = Array.from(sharedPosts.values());
    const syncStorePosts = Array.from(syncStore.posts.values());
    const unifiedUsers = unifiedStorage.getAllUsers();
    const legacyUsers = Array.from(sharedUsers.values());
    const syncStoreUsers = Array.from(syncStore.users.values());

    // Deduplicate posts
    const allPostsMap = new Map();
    unifiedPosts.forEach(post => { if (post && post.id) allPostsMap.set(post.id, post); });
    legacyPosts.forEach(post => { if (post && post.id && !allPostsMap.has(post.id)) allPostsMap.set(post.id, post); });
    syncStorePosts.forEach(post => { if (post && post.id && !allPostsMap.has(post.id)) allPostsMap.set(post.id, post); });

    // Deduplicate users
    const allUsersMap = new Map();
    unifiedUsers.forEach(user => { if (user && user.id) allUsersMap.set(user.id, user); });
    legacyUsers.forEach(user => { if (user && user.id && !allUsersMap.has(user.id)) allUsersMap.set(user.id, user); });
    syncStoreUsers.forEach(user => { if (user && user.id && !allUsersMap.has(user.id)) allUsersMap.set(user.id, user); });

    const publicPosts = Array.from(allPostsMap.values())
      .filter(post => post.visibility === 'public' || post.visibility === 'global');

    res.json({
      success: true,
      syncStatus: {
        timestamp: Date.now(),
        healthy: true,
        storageSystems: {
          unified: {
            posts: unifiedPosts.length,
            users: unifiedUsers.length
          },
          legacy: {
            posts: legacyPosts.length,
            users: legacyUsers.length
          },
          syncStore: {
            posts: syncStorePosts.length,
            users: syncStoreUsers.length
          }
        },
        consolidated: {
          totalPosts: allPostsMap.size,
          publicPosts: publicPosts.length,
          totalUsers: allUsersMap.size
        },
        consistency: {
          postsDeduplicated: allPostsMap.size,
          usersDeduplicated: allUsersMap.size,
          deduplicationRate: {
            posts: ((allPostsMap.size / (unifiedPosts.length + legacyPosts.length + syncStorePosts.length)) * 100).toFixed(2) + '%',
            users: ((allUsersMap.size / (unifiedUsers.length + legacyUsers.length + syncStoreUsers.length)) * 100).toFixed(2) + '%'
          }
        },
        cache: {
          redis: redisClient ? 'connected' : 'disconnected',
          nodeCache: 'active'
        }
      }
    });
  } catch (error) {
    console.error('[SyncStatus] Error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to get sync status',
      detail: error.message
    });
  }
});

// Get posts by author
app.get('/api/posts/author/:authorId', (req, res) => {
  const { authorId } = req.params;
  const posts = Array.from(sharedPosts.values())
    .filter(p => p.author === authorId)
    .sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
  res.json({ posts });
});

// Delete post from shared storage
app.delete('/api/posts/:postId', (req, res) => {
  const { postId } = req.params;
  const deleted = sharedPosts.delete(postId);

  if (deleted) {
    savePostsToFile(); // Persist deletion to disk
    io.emit('post:deleted', { postId });
    res.json({ success: true });
  } else {
    res.status(404).json({ error: 'Post not found' });
  }
});

// Update post (likes, comments, views, etc.)
app.put('/api/posts/:postId', (req, res) => {
  const { postId } = req.params;
  const updates = req.body;

  const existingPost = sharedPosts.get(postId);
  if (!existingPost) {
    return res.status(404).json({ error: 'Post not found' });
  }

  // Merge updates
  const updatedPost = { ...existingPost, ...updates };
  sharedPosts.set(postId, updatedPost);
  savePostsToFile(); // Persist updates to disk

  // Broadcast to all connected socket.io clients for real-time sync
  io.emit('post:updated', { postId, updates });
  console.log('[PostsDB] Post updated and broadcasted:', postId);

  res.json({ success: true, post: updatedPost });
});

// Clean up old posts (keep last 1000)
setInterval(() => {
  if (sharedPosts.size > 1000) {
    const posts = Array.from(sharedPosts.entries())
      .sort((a, b) => (b[1].createdAt || 0) - (a[1].createdAt || 0));

    // Delete oldest posts beyond 1000
    for (let i = 1000; i < posts.length; i++) {
      sharedPosts.delete(posts[i][0]);
    }

    savePostsToFile(); // Persist cleanup to disk
    console.log('[PostsDB] Cleaned up, now has', sharedPosts.size, 'posts');
  }
}, 60000); // Check every minute
