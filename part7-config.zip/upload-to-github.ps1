# GitHub Upload Automation Script for Monetixra
# This script will initialize Git, commit all files, and prepare for GitHub upload

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Monetixra GitHub Upload Automation" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Check if Git is installed
Write-Host "Step 1: Checking Git installation..." -ForegroundColor Yellow
try {
    $gitVersion = git --version
    Write-Host "✓ Git is installed: $gitVersion" -ForegroundColor Green
} catch {
    Write-Host "✗ Git is not installed. Please install Git first." -ForegroundColor Red
    exit 1
}

# Navigate to project directory
$projectPath = "D:\monetixra-main 27-09-2026"
Write-Host "Step 2: Navigating to project directory..." -ForegroundColor Yellow
Write-Host "Path: $projectPath" -ForegroundColor Gray
Set-Location $projectPath
Write-Host "✓ Directory changed" -ForegroundColor Green
Write-Host ""

# Initialize Git repository
Write-Host "Step 3: Initializing Git repository..." -ForegroundColor Yellow
if (Test-Path ".git") {
    Write-Host "⚠ Git repository already exists" -ForegroundColor Yellow
    $response = Read-Host "Do you want to reinitialize? (y/n)"
    if ($response -eq 'y' -or $response -eq 'Y') {
        Remove-Item -Recurse -Force .git
        git init
        Write-Host "✓ Git repository reinitialized" -ForegroundColor Green
    }
} else {
    git init
    Write-Host "✓ Git repository initialized" -ForegroundColor Green
}
Write-Host ""

# Configure Git (if not configured)
Write-Host "Step 4: Configuring Git..." -ForegroundColor Yellow
$gitUserName = git config --get user.name
$gitUserEmail = git config --get user.email

if (-not $gitUserName -or -not $gitUserEmail) {
    Write-Host "Git user configuration not found." -ForegroundColor Yellow
    $name = Read-Host "Enter your Git username"
    $email = Read-Host "Enter your Git email"
    git config user.name $name
    git config user.email $email
    Write-Host "✓ Git configured" -ForegroundColor Green
} else {
    Write-Host "✓ Git already configured" -ForegroundColor Green
    Write-Host "  Name: $gitUserName" -ForegroundColor Gray
    Write-Host "  Email: $gitUserEmail" -ForegroundColor Gray
}
Write-Host ""

# Add all files
Write-Host "Step 5: Adding files to Git..." -ForegroundColor Yellow
git add .
$addedFiles = git diff --cached --name-only
Write-Host "✓ Added $($addedFiles.Count) files" -ForegroundColor Green
Write-Host ""

# Create commit
Write-Host "Step 6: Creating commit..." -ForegroundColor Yellow
$commitMessage = @"
🎉 Initial commit - Monetixra v8.0 with all advanced features

Features:
- GraphQL API with subscriptions
- AI-powered content moderation
- Advanced analytics dashboard
- Blockchain NFT rewards system
- Storage verification system
- Advanced security (2FA, encryption, audit logging)
- CDN integration (Cloudflare)
- Microservices architecture
- Security hardening (ad guard, withdraw guard, chat guard)
"@

git commit -m $commitMessage
Write-Host "✓ Commit created" -ForegroundColor Green
Write-Host ""

# Add remote repository
Write-Host "Step 7: Setting up GitHub remote..." -ForegroundColor Yellow
$existingRemote = git remote get-url origin 2>$null
if ($existingRemote) {
    Write-Host "⚠ Remote 'origin' already exists: $existingRemote" -ForegroundColor Yellow
    $response = Read-Host "Do you want to change it? (y/n)"
    if ($response -eq 'y' -or $response -eq 'Y') {
        git remote remove origin
    } else {
        Write-Host "✓ Using existing remote" -ForegroundColor Green
    }
}

if (-not $existingRemote -or ($response -eq 'y' -or $response -eq 'Y')) {
    $githubUsername = Read-Host "Enter your GitHub username"
    $remoteUrl = "https://github.com/$githubUsername/monetixra.git"
    git remote add origin $remoteUrl
    Write-Host "✓ Remote added: $remoteUrl" -ForegroundColor Green
}
Write-Host ""

# Set main branch
Write-Host "Step 8: Setting main branch..." -ForegroundColor Yellow
git branch -M main
Write-Host "✓ Main branch set" -ForegroundColor Green
Write-Host ""

# Instructions for push
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Ready to Push to GitHub!" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Before pushing, make sure you have:" -ForegroundColor Yellow
Write-Host "1. Created a GitHub repository named 'monetixra'" -ForegroundColor White
Write-Host "2. Generated a Personal Access Token (if using HTTPS)" -ForegroundColor White
Write-Host ""
Write-Host "To push to GitHub, run:" -ForegroundColor Yellow
Write-Host "git push -u origin main" -ForegroundColor Green
Write-Host ""
Write-Host "Or use GitHub CLI:" -ForegroundColor Yellow
Write-Host "gh auth login" -ForegroundColor White
Write-Host "git push -u origin main" -ForegroundColor Green
Write-Host ""
Write-Host "Authentication Tips:" -ForegroundColor Yellow
Write-Host "- If asked for password, use your Personal Access Token" -ForegroundColor White
Write-Host "- Or install GitHub CLI: winget install --id GitHub.cli" -ForegroundColor White
Write-Host "  Then run: gh auth login" -ForegroundColor White
Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Ask if user wants to push now
$pushNow = Read-Host "Do you want to push to GitHub now? (y/n)"
if ($pushNow -eq 'y' -or $pushNow -eq 'Y') {
    Write-Host "Pushing to GitHub..." -ForegroundColor Yellow
    git push -u origin main
    Write-Host "✓ Pushed to GitHub!" -ForegroundColor Green
    Write-Host ""
    Write-Host "Your repository is now live at:" -ForegroundColor Cyan
    $remoteUrl = git remote get-url origin
    Write-Host $remoteUrl -ForegroundColor Green
} else {
    Write-Host "Skipped push. You can push later with:" -ForegroundColor Yellow
    Write-Host "git push -u origin main" -ForegroundColor Green
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Script Complete!" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
