@echo off
echo ========================================
echo   Monetixra GitHub Upload
echo ========================================
echo.

cd /d "D:\monetixra-main 27-09-2026"

echo Step 1: Authenticate with GitHub...
echo Browser will open. Login and authorize.
echo.
"C:\Program Files\GitHub CLI\gh.exe" auth login

if %errorlevel% neq 0 (
    echo Authentication failed. Please try again.
    pause
    exit /b 1
)

echo.
echo Step 2: Creating repository and uploading...
echo This may take a few minutes...
echo.

"C:\Program Files\GitHub CLI\gh.exe" repo create matiurm/monetixra --public --description "Complete Social Earn Platform with AI, Crypto, NFT, Blockchain & Live Streaming" --source=. --remote=origin --push

if %errorlevel% equ 0 (
    echo.
    echo ========================================
    echo   SUCCESS! Upload Complete!
    echo ========================================
    echo.
    echo Visit: https://github.com/matiurm/monetixra
    echo.
) else (
    echo.
    echo Upload failed. Please check error above.
    echo.
)

pause
