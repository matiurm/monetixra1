@echo off
echo ========================================
echo   Creating Monetixra ZIP File
echo ========================================
echo.

cd /d "D:\monetixra-main 27-09-2026"

echo Compressing files...
echo This may take a few minutes...
echo.

powershell -Command "Compress-Archive -Path '.\*' -DestinationPath '.\monetixra-complete.zip' -Force"

if %errorlevel% equ 0 (
    echo.
    echo ========================================
    echo   ZIP File Created Successfully!
    echo ========================================
    echo.
    echo Location: D:\monetixra-main 27-09-2026\monetixra-complete.zip
    echo.
    echo Upload this file to GitHub:
    echo https://github.com/matiurm/monetixra
    echo.
) else (
    echo.
    echo Failed to create ZIP file.
    echo.
)

pause
