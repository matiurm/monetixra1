-- ═══════════════════════════════════════════════════════
-- Monetixra New Features Database Schema
-- Supabase/PostgreSQL Integration
-- ═══════════════════════════════════════════════════════

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ═══════════════════════════════════════════════════════
-- Groups Table
-- ═══════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS groups (
  id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
  name TEXT NOT NULL,
  description TEXT,
  type TEXT DEFAULT 'public' CHECK (type IN ('public', 'private', 'secret')),
  cover_image TEXT,
  profile_image TEXT,
  category TEXT DEFAULT 'general',
  location JSONB,
  created_by TEXT REFERENCES users(id) ON DELETE CASCADE,
  member_count INTEGER DEFAULT 1,
  post_count INTEGER DEFAULT 0,
  rules JSONB DEFAULT '[]'::JSONB,
  tags TEXT[] DEFAULT ARRAY[]::TEXT[],
  settings JSONB DEFAULT '{"allowGuestPosts": false, "requireApproval": false, "moderatePosts": true}'::JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes for groups
CREATE INDEX IF NOT EXISTS idx_groups_type ON groups(type);
CREATE INDEX IF NOT EXISTS idx_groups_category ON groups(category);
CREATE INDEX IF NOT EXISTS idx_groups_created_by ON groups(created_by);
CREATE INDEX IF NOT EXISTS idx_groups_created_at ON groups(created_at DESC);

-- ═══════════════════════════════════════════════════════
-- Pages Table
-- ═══════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS pages (
  id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
  name TEXT NOT NULL,
  username TEXT UNIQUE,
  description TEXT,
  type TEXT DEFAULT 'business' CHECK (type IN ('business', 'brand', 'community', 'entertainment', 'creator')),
  cover_image TEXT,
  profile_image TEXT,
  category TEXT DEFAULT 'business',
  location JSONB,
  website TEXT,
  phone TEXT,
  email TEXT,
  created_by TEXT REFERENCES users(id) ON DELETE CASCADE,
  follower_count INTEGER DEFAULT 1,
  post_count INTEGER DEFAULT 0,
  verified BOOLEAN DEFAULT FALSE,
  tags TEXT[] DEFAULT ARRAY[]::TEXT[],
  settings JSONB DEFAULT '{"allowMessages": true, "showReviews": true, "allowPosts": false}'::JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes for pages
CREATE INDEX IF NOT EXISTS idx_pages_type ON pages(type);
CREATE INDEX IF NOT EXISTS idx_pages_category ON pages(category);
CREATE INDEX IF NOT EXISTS idx_pages_created_by ON pages(created_by);
CREATE INDEX IF NOT EXISTS idx_pages_username ON pages(username);
CREATE INDEX IF NOT EXISTS idx_pages_created_at ON pages(created_at DESC);

-- ═══════════════════════════════════════════════════════
-- Group Members Table
-- ═══════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS group_members (
  id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
  group_id TEXT REFERENCES groups(id) ON DELETE CASCADE,
  user_id TEXT REFERENCES users(id) ON DELETE CASCADE,
  role TEXT DEFAULT 'member' CHECK (role IN ('admin', 'moderator', 'member')),
  joined_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(group_id, user_id)
);

-- Indexes for group_members
CREATE INDEX IF NOT EXISTS idx_group_members_group_id ON group_members(group_id);
CREATE INDEX IF NOT EXISTS idx_group_members_user_id ON group_members(user_id);
CREATE INDEX IF NOT EXISTS idx_group_members_role ON group_members(role);

-- ═══════════════════════════════════════════════════════
-- Page Followers Table
-- ═══════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS page_followers (
  id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
  page_id TEXT REFERENCES pages(id) ON DELETE CASCADE,
  user_id TEXT REFERENCES users(id) ON DELETE CASCADE,
  role TEXT DEFAULT 'member' CHECK (role IN ('admin', 'member')),
  followed_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(page_id, user_id)
);

-- Indexes for page_followers
CREATE INDEX IF NOT EXISTS idx_page_followers_page_id ON page_followers(page_id);
CREATE INDEX IF NOT EXISTS idx_page_followers_user_id ON page_followers(user_id);
CREATE INDEX IF NOT EXISTS idx_page_followers_role ON page_followers(role);

-- ═══════════════════════════════════════════════════════
-- Group Invites Table
-- ═══════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS group_invites (
  id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
  group_id TEXT REFERENCES groups(id) ON DELETE CASCADE,
  inviter_id TEXT REFERENCES users(id) ON DELETE CASCADE,
  invitee_id TEXT REFERENCES users(id) ON DELETE CASCADE,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'declined')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes for group_invites
CREATE INDEX IF NOT EXISTS idx_group_invites_group_id ON group_invites(group_id);
CREATE INDEX IF NOT EXISTS idx_group_invites_invitee_id ON group_invites(invitee_id);
CREATE INDEX IF NOT EXISTS idx_group_invites_status ON group_invites(status);

-- ═══════════════════════════════════════════════════════
-- Events Table
-- ═══════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS events (
  id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
  title TEXT NOT NULL,
  description TEXT,
  type TEXT DEFAULT 'in_person' CHECK (type IN ('online', 'in_person', 'hybrid')),
  category TEXT DEFAULT 'social' CHECK (category IN ('music', 'sports', 'business', 'education', 'entertainment', 'social', 'technology', 'arts', 'food', 'other')),
  cover_image TEXT,
  location JSONB,
  online_link TEXT,
  start_date TIMESTAMP WITH TIME ZONE NOT NULL,
  end_date TIMESTAMP WITH TIME ZONE,
  timezone TEXT DEFAULT 'UTC',
  is_all_day BOOLEAN DEFAULT FALSE,
  organizer_id TEXT REFERENCES users(id) ON DELETE CASCADE,
  organizer_name TEXT,
  attendee_count INTEGER DEFAULT 0,
  interested_count INTEGER DEFAULT 0,
  capacity INTEGER,
  is_public BOOLEAN DEFAULT TRUE,
  is_free BOOLEAN DEFAULT TRUE,
  price DECIMAL(10, 2) DEFAULT 0,
  currency TEXT DEFAULT 'USD',
  tags TEXT[] DEFAULT ARRAY[]::TEXT[],
  settings JSONB DEFAULT '{"allowGuests": true, "requireApproval": false, "showAttendees": true}'::JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes for events
CREATE INDEX IF NOT EXISTS idx_events_type ON events(type);
CREATE INDEX IF NOT EXISTS idx_events_category ON events(category);
CREATE INDEX IF NOT EXISTS idx_events_organizer_id ON events(organizer_id);
CREATE INDEX IF NOT EXISTS idx_events_start_date ON events(start_date);
CREATE INDEX IF NOT EXISTS idx_events_is_public ON events(is_public);
CREATE INDEX IF NOT EXISTS idx_events_created_at ON events(created_at DESC);

-- ═══════════════════════════════════════════════════════
-- Event Attendees Table
-- ═══════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS event_attendees (
  id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
  event_id TEXT REFERENCES events(id) ON DELETE CASCADE,
  user_id TEXT REFERENCES users(id) ON DELETE CASCADE,
  status TEXT DEFAULT 'interested' CHECK (status IN ('going', 'interested', 'maybe', 'not_going')),
  joined_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(event_id, user_id)
);

-- Indexes for event_attendees
CREATE INDEX IF NOT EXISTS idx_event_attendees_event_id ON event_attendees(event_id);
CREATE INDEX IF NOT EXISTS idx_event_attendees_user_id ON event_attendees(user_id);
CREATE INDEX IF NOT EXISTS idx_event_attendees_status ON event_attendees(status);

-- ═══════════════════════════════════════════════════════
-- Notifications Table
-- ═══════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS notifications (
  id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
  recipient_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  sender_id TEXT REFERENCES users(id) ON DELETE SET NULL,
  sender_name TEXT,
  sender_avatar TEXT,
  type TEXT NOT NULL CHECK (type IN ('like', 'comment', 'share', 'follow', 'mention', 'message', 'post', 'live', 'event', 'group', 'page', 'system', 'ad')),
  title TEXT,
  message TEXT,
  data JSONB DEFAULT '{}'::JSONB,
  priority INTEGER DEFAULT 2 CHECK (priority IN (1, 2, 3, 4)),
  is_read BOOLEAN DEFAULT FALSE,
  is_seen BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  expires_at TIMESTAMP WITH TIME ZONE,
  action_url TEXT,
  action_text TEXT
);

-- Indexes for notifications
CREATE INDEX IF NOT EXISTS idx_notifications_recipient_id ON notifications(recipient_id);
CREATE INDEX IF NOT EXISTS idx_notifications_type ON notifications(type);
CREATE INDEX IF NOT EXISTS idx_notifications_is_read ON notifications(is_read);
CREATE INDEX IF NOT EXISTS idx_notifications_created_at ON notifications(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_notifications_priority ON notifications(priority);

-- ═══════════════════════════════════════════════════════
-- Notification Settings Table
-- ═══════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS notification_settings (
  id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
  user_id TEXT UNIQUE NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  push_enabled BOOLEAN DEFAULT TRUE,
  email_enabled BOOLEAN DEFAULT FALSE,
  in_app_enabled BOOLEAN DEFAULT TRUE,
  like_notifications BOOLEAN DEFAULT TRUE,
  comment_notifications BOOLEAN DEFAULT TRUE,
  follow_notifications BOOLEAN DEFAULT TRUE,
  mention_notifications BOOLEAN DEFAULT TRUE,
  message_notifications BOOLEAN DEFAULT TRUE,
  live_notifications BOOLEAN DEFAULT TRUE,
  quiet_hours_enabled BOOLEAN DEFAULT FALSE,
  quiet_hours_start TEXT DEFAULT '22:00',
  quiet_hours_end TEXT DEFAULT '08:00',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes for notification_settings
CREATE INDEX IF NOT EXISTS idx_notification_settings_user_id ON notification_settings(user_id);

-- ═══════════════════════════════════════════════════════
-- Saved Posts Table
-- ═══════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS saved_posts (
  id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  post_id TEXT NOT NULL,
  collection_id TEXT REFERENCES collections(id) ON DELETE SET NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(user_id, post_id)
);

-- Indexes for saved_posts
CREATE INDEX IF NOT EXISTS idx_saved_posts_user_id ON saved_posts(user_id);
CREATE INDEX IF NOT EXISTS idx_saved_posts_post_id ON saved_posts(post_id);
CREATE INDEX IF NOT EXISTS idx_saved_posts_collection_id ON saved_posts(collection_id);
CREATE INDEX IF NOT EXISTS idx_saved_posts_created_at ON saved_posts(created_at DESC);

-- ═══════════════════════════════════════════════════════
-- Collections Table
-- ═══════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS collections (
  id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  description TEXT,
  cover_image TEXT,
  is_private BOOLEAN DEFAULT TRUE,
  post_count INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes for collections
CREATE INDEX IF NOT EXISTS idx_collections_user_id ON collections(user_id);
CREATE INDEX IF NOT EXISTS idx_collections_is_private ON collections(is_private);
CREATE INDEX IF NOT EXISTS idx_collections_created_at ON collections(created_at DESC);

-- ═══════════════════════════════════════════════════════
-- Post Targeting Rules Table
-- ═══════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS post_targeting_rules (
  id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
  post_id TEXT NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  type TEXT DEFAULT 'public' CHECK (type IN ('public', 'friends', 'friends_except', 'specific_friends', 'group', 'location', 'age_range', 'gender', 'interests', 'custom')),
  audience TEXT[] DEFAULT ARRAY[]::TEXT[],
  except TEXT[] DEFAULT ARRAY[]::TEXT[],
  location JSONB,
  age_range JSONB,
  gender TEXT,
  interests TEXT[] DEFAULT ARRAY[]::TEXT[],
  groups TEXT[] DEFAULT ARRAY[]::TEXT[],
  custom_criteria JSONB DEFAULT '{}'::JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes for post_targeting_rules
CREATE INDEX IF NOT EXISTS idx_post_targeting_rules_post_id ON post_targeting_rules(post_id);
CREATE INDEX IF NOT EXISTS idx_post_targeting_rules_type ON post_targeting_rules(type);

-- ═══════════════════════════════════════════════════════
-- Watch History Table
-- ═══════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS watch_history (
  id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  video_id TEXT NOT NULL,
  first_watched_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  last_watched_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  total_watch_time INTEGER DEFAULT 0,
  watch_count INTEGER DEFAULT 1,
  UNIQUE(user_id, video_id)
);

-- Indexes for watch_history
CREATE INDEX IF NOT EXISTS idx_watch_history_user_id ON watch_history(user_id);
CREATE INDEX IF NOT EXISTS idx_watch_history_video_id ON watch_history(video_id);
CREATE INDEX IF NOT EXISTS idx_watch_history_last_watched_at ON watch_history(last_watched_at DESC);

-- ═══════════════════════════════════════════════════════
-- Video Bookmarks Table
-- ═══════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS video_bookmarks (
  id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  video_id TEXT NOT NULL,
  timestamp INTEGER NOT NULL,
  note TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes for video_bookmarks
CREATE INDEX IF NOT EXISTS idx_video_bookmarks_user_id ON video_bookmarks(user_id);
CREATE INDEX IF NOT EXISTS idx_video_bookmarks_video_id ON video_bookmarks(video_id);
CREATE INDEX IF NOT EXISTS idx_video_bookmarks_timestamp ON video_bookmarks(timestamp);

-- ═══════════════════════════════════════════════════════
-- Short-Form Videos Table
-- ═══════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS short_form_videos (
  id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
  url TEXT NOT NULL,
  thumbnail TEXT,
  sound_id TEXT REFERENCES sounds(id) ON DELETE SET NULL,
  caption TEXT,
  hashtags TEXT[] DEFAULT ARRAY[]::TEXT[],
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  user_name TEXT,
  user_avatar TEXT,
  duration INTEGER DEFAULT 0,
  aspect_ratio TEXT DEFAULT '9:16',
  likes INTEGER DEFAULT 0,
  comments INTEGER DEFAULT 0,
  shares INTEGER DEFAULT 0,
  views INTEGER DEFAULT 0,
  is_pinned BOOLEAN DEFAULT FALSE,
  is_featured BOOLEAN DEFAULT FALSE,
  location JSONB,
  mentions TEXT[] DEFAULT ARRAY[]::TEXT[],
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes for short_form_videos
CREATE INDEX IF NOT EXISTS idx_short_form_videos_user_id ON short_form_videos(user_id);
CREATE INDEX IF NOT EXISTS idx_short_form_videos_sound_id ON short_form_videos(sound_id);
CREATE INDEX IF NOT EXISTS idx_short_form_videos_is_featured ON short_form_videos(is_featured);
CREATE INDEX IF NOT EXISTS idx_short_form_videos_created_at ON short_form_videos(created_at DESC);

-- ═══════════════════════════════════════════════════════
-- Sounds Table
-- ═══════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS sounds (
  id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
  url TEXT NOT NULL,
  title TEXT,
  artist TEXT,
  duration INTEGER DEFAULT 0,
  cover_image TEXT,
  use_count INTEGER DEFAULT 0,
  is_trending BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes for sounds
CREATE INDEX IF NOT EXISTS idx_sounds_is_trending ON sounds(is_trending);
CREATE INDEX IF NOT EXISTS idx_sounds_use_count ON sounds(use_count DESC);
CREATE INDEX IF NOT EXISTS idx_sounds_created_at ON sounds(created_at DESC);

-- ═══════════════════════════════════════════════════════
-- User Interactions Table (for feed algorithm)
-- ═══════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS user_interactions (
  id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  target_user_id TEXT REFERENCES users(id) ON DELETE CASCADE,
  target_post_id TEXT REFERENCES posts(id) ON DELETE SET NULL,
  interaction_type TEXT CHECK (type IN ('like', 'comment', 'share', 'view', 'follow')),
  count INTEGER DEFAULT 1,
  last_interacted_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(user_id, target_user_id, target_post_id, interaction_type)
);

-- Indexes for user_interactions
CREATE INDEX IF NOT EXISTS idx_user_interactions_user_id ON user_interactions(user_id);
CREATE INDEX IF NOT EXISTS idx_user_interactions_target_user_id ON user_interactions(target_user_id);
CREATE INDEX IF NOT EXISTS idx_user_interactions_target_post_id ON user_interactions(target_post_id);
CREATE INDEX IF NOT EXISTS idx_user_interactions_last_interacted_at ON user_interactions(last_interacted_at DESC);

-- ═══════════════════════════════════════════════════════
-- Triggers for updated_at
-- ═══════════════════════════════════════════════════════
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply trigger to tables with updated_at
CREATE TRIGGER update_groups_updated_at BEFORE UPDATE ON groups
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_pages_updated_at BEFORE UPDATE ON pages
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_events_updated_at BEFORE UPDATE ON events
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_collections_updated_at BEFORE UPDATE ON collections
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_notification_settings_updated_at BEFORE UPDATE ON notification_settings
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- ═══════════════════════════════════════════════════════
-- Row Level Security (RLS) Policies
-- ═══════════════════════════════════════════════════════

-- Enable RLS
ALTER TABLE groups ENABLE ROW LEVEL SECURITY;
ALTER TABLE pages ENABLE ROW LEVEL SECURITY;
ALTER TABLE events ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE saved_posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE collections ENABLE ROW LEVEL SECURITY;
ALTER TABLE watch_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE video_bookmarks ENABLE ROW LEVEL SECURITY;
ALTER TABLE short_form_videos ENABLE ROW LEVEL SECURITY;

-- Groups policies
CREATE POLICY "Users can view public groups" ON groups
  FOR SELECT USING (type = 'public' OR created_by = auth.uid());

CREATE POLICY "Users can create groups" ON groups
  FOR INSERT WITH CHECK (created_by = auth.uid());

CREATE POLICY "Users can update their own groups" ON groups
  FOR UPDATE USING (created_by = auth.uid());

-- Pages policies
CREATE POLICY "Users can view all pages" ON pages
  FOR SELECT USING (true);

CREATE POLICY "Users can create pages" ON pages
  FOR INSERT WITH CHECK (created_by = auth.uid());

CREATE POLICY "Users can update their own pages" ON pages
  FOR UPDATE USING (created_by = auth.uid());

-- Events policies
CREATE POLICY "Users can view public events" ON events
  FOR SELECT USING (is_public = true OR organizer_id = auth.uid());

CREATE POLICY "Users can create events" ON events
  FOR INSERT WITH CHECK (organizer_id = auth.uid());

CREATE POLICY "Users can update their own events" ON events
  FOR UPDATE USING (organizer_id = auth.uid());

-- Notifications policies
CREATE POLICY "Users can view their own notifications" ON notifications
  FOR SELECT USING (recipient_id = auth.uid());

CREATE POLICY "Users can update their own notifications" ON notifications
  FOR UPDATE USING (recipient_id = auth.uid());

-- Saved posts policies
CREATE POLICY "Users can view their own saved posts" ON saved_posts
  FOR SELECT USING (user_id = auth.uid());

CREATE POLICY "Users can create saved posts" ON saved_posts
  FOR INSERT WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can delete their own saved posts" ON saved_posts
  FOR DELETE USING (user_id = auth.uid());

-- Collections policies
CREATE POLICY "Users can view their own collections" ON collections
  FOR SELECT USING (user_id = auth.uid() OR is_private = false);

CREATE POLICY "Users can create collections" ON collections
  FOR INSERT WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can update their own collections" ON collections
  FOR UPDATE USING (user_id = auth.uid());

CREATE POLICY "Users can delete their own collections" ON collections
  FOR DELETE USING (user_id = auth.uid());

-- Watch history policies
CREATE POLICY "Users can view their own watch history" ON watch_history
  FOR SELECT USING (user_id = auth.uid());

CREATE POLICY "Users can create watch history" ON watch_history
  FOR INSERT WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can update their own watch history" ON watch_history
  FOR UPDATE USING (user_id = auth.uid());

-- Video bookmarks policies
CREATE POLICY "Users can view their own bookmarks" ON video_bookmarks
  FOR SELECT USING (user_id = auth.uid());

CREATE POLICY "Users can create bookmarks" ON video_bookmarks
  FOR INSERT WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can delete their own bookmarks" ON video_bookmarks
  FOR DELETE USING (user_id = auth.uid());

-- Short-form videos policies
CREATE POLICY "Users can view all videos" ON short_form_videos
  FOR SELECT USING (true);

CREATE POLICY "Users can create videos" ON short_form_videos
  FOR INSERT WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can update their own videos" ON short_form_videos
  FOR UPDATE USING (user_id = auth.uid());

-- ═══════════════════════════════════════════════════════
-- Functions for Common Operations
-- ═══════════════════════════════════════════════════════

-- Function to get unread notification count
CREATE OR REPLACE FUNCTION get_unread_count(p_user_id TEXT)
RETURNS INTEGER AS $$
BEGIN
  RETURN (
    SELECT COUNT(*)
    FROM notifications
    WHERE recipient_id = p_user_id AND is_read = FALSE
  );
END;
$$ LANGUAGE plpgsql;

-- Function to increment group member count
CREATE OR REPLACE FUNCTION increment_group_member_count(p_group_id TEXT)
RETURNS VOID AS $$
BEGIN
  UPDATE groups
  SET member_count = member_count + 1
  WHERE id = p_group_id;
END;
$$ LANGUAGE plpgsql;

-- Function to increment page follower count
CREATE OR REPLACE FUNCTION increment_page_follower_count(p_page_id TEXT)
RETURNS VOID AS $$
BEGIN
  UPDATE pages
  SET follower_count = follower_count + 1
  WHERE id = p_page_id;
END;
$$ LANGUAGE plpgsql;

-- Function to increment event attendee count
CREATE OR REPLACE FUNCTION increment_event_attendee_count(p_event_id TEXT, p_status TEXT)
RETURNS VOID AS $$
BEGIN
  IF p_status = 'going' THEN
    UPDATE events
    SET attendee_count = attendee_count + 1
    WHERE id = p_event_id;
  ELSIF p_status = 'interested' THEN
    UPDATE events
    SET interested_count = interested_count + 1
    WHERE id = p_event_id;
  END IF;
END;
$$ LANGUAGE plpgsql;

-- Function to increment sound use count
CREATE OR REPLACE FUNCTION increment_sound_use_count(p_sound_id TEXT)
RETURNS VOID AS $$
BEGIN
  UPDATE sounds
  SET use_count = use_count + 1
  WHERE id = p_sound_id;
END;
$$ LANGUAGE plpgsql;

-- ═══════════════════════════════════════════════════════
-- End of Schema
-- ═══════════════════════════════════════════════════════
