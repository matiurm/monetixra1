# One-Click GitHub Upload Script
# Run this script to upload the entire project to GitHub

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Monetixra One-Click GitHub Upload" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Navigate to project directory
$projectPath = "D:\monetixra-main 27-09-2026"
Set-Location $projectPath
Write-Host "✓ Working directory: $projectPath" -ForegroundColor Green
Write-Host ""

# Set paths
$gitPath = "C:\Program Files\Git\bin\git.exe"
$ghPath = "C:\Program Files\GitHub CLI\gh.exe"

# Check if Git is already initialized
if (-not (Test-Path ".git")) {
    Write-Host "Initializing Git repository..." -ForegroundColor Yellow
    & $gitPath init
    & $gitPath config user.name "matiurm"
    & $gitPath config user.email "myworktoolsp2@gmail.com"
    Write-Host "✓ Git initialized" -ForegroundColor Green
    Write-Host ""
}

# Add all files
Write-Host "Adding files to Git..." -ForegroundColor Yellow
& $gitPath add .
Write-Host "✓ Files added" -ForegroundColor Green
Write-Host ""

# Create commit if needed
$commitNeeded = & $gitPath status --porcelain
if ($commitNeeded) {
    Write-Host "Creating commit..." -ForegroundColor Yellow
    & $gitPath commit -m "🎉 Initial commit - Monetixra v8.0 with all advanced features

Features:
- GraphQL API with subscriptions
- AI-powered content moderation
- Advanced analytics dashboard
- Blockchain NFT rewards system
- Storage verification system
- Advanced security (2FA, encryption, audit logging)
- CDN integration (Cloudflare)
- Microservices architecture
- Security hardening (ad guard, withdraw guard, chat guard)"
    Write-Host "✓ Commit created" -ForegroundColor Green
    Write-Host ""
} else {
    Write-Host "✓ No changes to commit" -ForegroundColor Green
    Write-Host ""
}

# Add remote if not exists
$remoteExists = & $gitPath remote get-url origin 2>$null
if (-not $remoteExists) {
    Write-Host "Adding GitHub remote..." -ForegroundColor Yellow
    & $gitPath remote add origin https://github.com/matiurm/monetixra.git
    Write-Host "✓ Remote added" -ForegroundColor Green
    Write-Host ""
}

# Set main branch
& $gitPath branch -M main

# Check GitHub authentication
Write-Host "Checking GitHub authentication..." -ForegroundColor Yellow
$authStatus = & $ghPath auth status 2>&1

if ($LASTEXITCODE -ne 0) {
    Write-Host "⚠ Not authenticated with GitHub" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host "  Please Authenticate with GitHub" -ForegroundColor Cyan
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "Running: gh auth login" -ForegroundColor Gray
    Write-Host ""
    Write-Host "Follow these steps:" -ForegroundColor Cyan
    Write-Host "1. What account? -> GitHub.com" -ForegroundColor White
    Write-Host "2. Protocol? -> HTTPS" -ForegroundColor White
    Write-Host "3. Authenticate Git? -> Yes" -ForegroundColor White
    Write-Host "4. Press Enter to open browser" -ForegroundColor White
    Write-Host "5. Login and authorize on GitHub" -ForegroundColor White
    Write-Host ""
    Write-Host "Press any key to continue..." -ForegroundColor Yellow
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")

    & $ghPath auth login

    if ($LASTEXITCODE -ne 0) {
        Write-Host "✗ Authentication failed" -ForegroundColor Red
        Write-Host "Please try manually or create a Personal Access Token" -ForegroundColor Yellow
        exit 1
    }

    Write-Host "✓ Authentication successful" -ForegroundColor Green
    Write-Host ""
} else {
    Write-Host "✓ Already authenticated with GitHub" -ForegroundColor Green
    Write-Host ""
}

# Check if repository exists
Write-Host "Checking if repository exists..." -ForegroundColor Yellow
$repoExists = & $ghPath repo view matiurm/monetixra 2>&1

if ($LASTEXITCODE -ne 0) {
    Write-Host "⚠ Repository does not exist" -ForegroundColor Yellow
    Write-Host "Creating repository..." -ForegroundColor Cyan
    & $ghPath repo create matiurm/monetixra --public --description "Complete Social Earn Platform with AI, Crypto, NFT, Blockchain & Live Streaming"
    Write-Host "✓ Repository created" -ForegroundColor Green
    Write-Host ""
} else {
    Write-Host "✓ Repository exists" -ForegroundColor Green
    Write-Host ""
}

# Push to GitHub
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Pushing to GitHub..." -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "This may take a few minutes..." -ForegroundColor Yellow
Write-Host "Please wait..." -ForegroundColor Gray
Write-Host ""

& $gitPath push -u origin main

if ($LASTEXITCODE -eq 0) {
    Write-Host ""
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host "  🎉🎉🎉 UPLOAD SUCCESSFUL! 🎉🎉🎉" -ForegroundColor Green
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "Your repository is now live at:" -ForegroundColor Cyan
    Write-Host "https://github.com/matiurm/monetixra" -ForegroundColor Green
    Write-Host ""
    Write-Host "📊 Upload Summary:" -ForegroundColor Yellow
    Write-Host "  • Total files: 303" -ForegroundColor White
    Write-Host "  • Total lines: 164,024" -ForegroundColor White
    Write-Host "  • Repository: monetixra" -ForegroundColor White
    Write-Host "  • Owner: matiurm" -ForegroundColor White
    Write-Host ""
    Write-Host "🚀 Next Steps:" -ForegroundColor Yellow
    Write-Host "  1. Visit: https://github.com/matiurm/monetixra" -ForegroundColor White
    Write-Host "  2. Verify all files are uploaded" -ForegroundColor White
    Write-Host "  3. Add README.md if needed" -ForegroundColor White
    Write-Host "  4. Configure for deployment" -ForegroundColor White
    Write-Host ""
    Write-Host "========================================" -ForegroundColor Cyan
} else {
    Write-Host ""
    Write-Host "✗ Push failed" -ForegroundColor Red
    Write-Host ""
    Write-Host "Troubleshooting:" -ForegroundColor Yellow
    Write-Host "1. Check your internet connection" -ForegroundColor White
    Write-Host "2. Verify repository exists: https://github.com/matiurm/monetixra" -ForegroundColor White
    Write-Host "3. Try manual push: git push -u origin main" -ForegroundColor White
    Write-Host ""
}

Write-Host "Press any key to exit..." -ForegroundColor Yellow
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
