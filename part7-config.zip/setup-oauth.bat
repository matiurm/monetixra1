@echo off
echo ============================================================
echo          OAuth Configuration Helper
echo ============================================================
echo.
echo This script will help you configure OAuth providers.
echo Please have your API keys ready from each provider dashboard.
echo.
echo Press any key to continue...
pause > nul

node setup-oauth-config.js

echo.
echo ============================================================
echo Configuration complete!
echo ============================================================
echo.
echo Next steps:
echo 1. Restart your server: node server.js
echo 2. Open test page: http://localhost:3000/test-oauth.html
echo 3. Test each OAuth provider
echo.
pause
