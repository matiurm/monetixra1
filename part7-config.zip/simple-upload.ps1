# Simple GitHub Upload - Just Run This!

# Go to project folder
cd "D:\monetixra-main 27-09-2026"

# Authenticate with GitHub (opens browser)
& "C:\Program Files\GitHub CLI\gh.exe" auth login

# Create repository (if not exists)
& "C:\Program Files\GitHub CLI\gh.exe" repo create matiurm/monetixra --public --description "Complete Social Earn Platform with AI, Crypto, NFT, Blockchain & Live Streaming" --source=. --remote=origin --push

Write-Host "✅ Upload Complete!" -ForegroundColor Green
Write-Host "Visit: https://github.com/matiurm/monetixra" -ForegroundColor Cyan
