# Final GitHub Upload Script
# Run this script to complete the GitHub upload

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Monetixra GitHub Upload - Final Step" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Navigate to project directory
$projectPath = "D:\monetixra-main 27-09-2026"
Set-Location $projectPath
Write-Host "✓ Working directory: $projectPath" -ForegroundColor Green
Write-Host ""

# Step 1: Authenticate with GitHub
Write-Host "Step 1: Authenticating with GitHub..." -ForegroundColor Yellow
Write-Host "Running: gh auth login" -ForegroundColor Gray
Write-Host ""
Write-Host "Follow these steps:" -ForegroundColor Cyan
Write-Host "1. What account do you want to log into? -> GitHub.com" -ForegroundColor White
Write-Host "2. What is your preferred protocol for Git operations? -> HTTPS" -ForegroundColor White
Write-Host "3. Authenticate Git with your GitHub credentials? -> Yes" -ForegroundColor White
Write-Host "4. Press Enter to open browser for authentication" -ForegroundColor White
Write-Host ""

# Run GitHub CLI authentication
gh auth login

if ($LASTEXITCODE -ne 0) {
    Write-Host "✗ GitHub authentication failed" -ForegroundColor Red
    Write-Host "Please try again or use manual authentication" -ForegroundColor Yellow
    exit 1
}

Write-Host "✓ GitHub authentication successful" -ForegroundColor Green
Write-Host ""

# Step 2: Verify repository exists
Write-Host "Step 2: Verifying GitHub repository..." -ForegroundColor Yellow
$repoExists = gh repo view matiurm/monetixra 2>$null

if ($LASTEXITCODE -ne 0) {
    Write-Host "⚠ Repository does not exist on GitHub" -ForegroundColor Yellow
    Write-Host "Creating repository..." -ForegroundColor Cyan
    gh repo create matiurm/monetixra --public --description "Complete Social Earn Platform with AI, Crypto, NFT, Blockchain & Live Streaming"
    Write-Host "✓ Repository created" -ForegroundColor Green
} else {
    Write-Host "✓ Repository exists" -ForegroundColor Green
}
Write-Host ""

# Step 3: Push to GitHub
Write-Host "Step 3: Pushing to GitHub..." -ForegroundColor Yellow
Write-Host "This may take a few minutes depending on your internet speed..." -ForegroundColor Gray
Write-Host ""

# Use full path to git
$gitPath = "C:\Program Files\Git\bin\git.exe"
& $gitPath push -u origin main

if ($LASTEXITCODE -eq 0) {
    Write-Host ""
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host "  🎉 Upload Successful!" -ForegroundColor Green
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "Your repository is now live at:" -ForegroundColor Cyan
    Write-Host "https://github.com/matiurm/monetixra" -ForegroundColor Green
    Write-Host ""
    Write-Host "Total files uploaded: 303" -ForegroundColor White
    Write-Host "Total lines of code: 164,024" -ForegroundColor White
    Write-Host ""
    Write-Host "Next steps:" -ForegroundColor Yellow
    Write-Host "1. Visit your repository: https://github.com/matiurm/monetixra" -ForegroundColor White
    Write-Host "2. Verify all files are uploaded" -ForegroundColor White
    Write-Host "3. Add a README.md if needed" -ForegroundColor White
    Write-Host "4. Configure environment variables for deployment" -ForegroundColor White
    Write-Host ""
} else {
    Write-Host ""
    Write-Host "✗ Push failed" -ForegroundColor Red
    Write-Host "Please check your internet connection and try again" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Manual push command:" -ForegroundColor Yellow
    Write-Host "git push -u origin main" -ForegroundColor Gray
}

Write-Host "========================================" -ForegroundColor Cyan
