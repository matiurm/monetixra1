-- Copyright Enforcement System Schema
-- This schema manages copyright reports, notifications, and auto-deletion

-- Copyright Reports Table
CREATE TABLE IF NOT EXISTS copyright_reports (
  id SERIAL PRIMARY KEY,
  user_id VARCHAR(255) NOT NULL,
  reported_by VARCHAR(255) NOT NULL,
  content_type VARCHAR(50) NOT NULL, -- 'video', 'audio', 'photo', 'text'
  content_id VARCHAR(255) NOT NULL,
  content_url TEXT,
  original_source VARCHAR(255), -- Original copyright holder/website
  report_reason TEXT NOT NULL,
  report_status VARCHAR(50) DEFAULT 'pending', -- 'pending', 'reviewed', 'confirmed', 'rejected'
  severity VARCHAR(20) DEFAULT 'medium', -- 'low', 'medium', 'high', 'critical'
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  reviewed_at TIMESTAMP,
  reviewed_by VARCHAR(255),
  metadata JSONB DEFAULT '{}',
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Copyright Violations Table (for tracking user violation history)
CREATE TABLE IF NOT EXISTS copyright_violations (
  id SERIAL PRIMARY KEY,
  user_id VARCHAR(255) NOT NULL,
  report_id INTEGER REFERENCES copyright_reports(id) ON DELETE CASCADE,
  violation_count INTEGER DEFAULT 1,
  violation_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  status VARCHAR(50) DEFAULT 'active', -- 'active', 'resolved', 'expired'
  auto_delete_scheduled_at TIMESTAMP,
  auto_delete_completed_at TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Copyright Notifications Table
CREATE TABLE IF NOT EXISTS copyright_notifications (
  id SERIAL PRIMARY KEY,
  user_id VARCHAR(255) NOT NULL,
  report_id INTEGER REFERENCES copyright_reports(id) ON DELETE CASCADE,
  notification_type VARCHAR(50) NOT NULL, -- 'warning', 'deletion_notice', 'suspension'
  message TEXT NOT NULL,
  content_type VARCHAR(50),
  content_id VARCHAR(255),
  deletion_deadline TIMESTAMP,
  is_read BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  read_at TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- User Copyright Status Table (tracks copyright-free status)
CREATE TABLE IF NOT EXISTS user_copyright_status (
  user_id VARCHAR(255) PRIMARY KEY,
  is_copyright_free BOOLEAN DEFAULT TRUE,
  total_violations INTEGER DEFAULT 0,
  active_violations INTEGER DEFAULT 0,
  last_violation_date TIMESTAMP,
  status_updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  notes TEXT,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Auto-Delete Queue Table (for scheduled deletions)
CREATE TABLE IF NOT EXISTS auto_delete_queue (
  id SERIAL PRIMARY KEY,
  user_id VARCHAR(255) NOT NULL,
  content_type VARCHAR(50) NOT NULL,
  content_id VARCHAR(255) NOT NULL,
  content_url TEXT,
  report_id INTEGER REFERENCES copyright_reports(id) ON DELETE CASCADE,
  scheduled_at TIMESTAMP NOT NULL,
  status VARCHAR(50) DEFAULT 'pending', -- 'pending', 'processing', 'completed', 'failed'
  processed_at TIMESTAMP,
  error_message TEXT,
  retry_count INTEGER DEFAULT 0,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_copyright_reports_user_id ON copyright_reports(user_id);
CREATE INDEX IF NOT EXISTS idx_copyright_reports_status ON copyright_reports(report_status);
CREATE INDEX IF NOT EXISTS idx_copyright_reports_created_at ON copyright_reports(created_at);
CREATE INDEX IF NOT EXISTS idx_copyright_reports_content_id ON copyright_reports(content_id);
CREATE INDEX IF NOT EXISTS idx_copyright_violations_user_id ON copyright_violations(user_id);
CREATE INDEX IF NOT EXISTS idx_copyright_violations_status ON copyright_violations(status);
CREATE INDEX IF NOT EXISTS idx_copyright_notifications_user_id ON copyright_notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_copyright_notifications_is_read ON copyright_notifications(is_read);
CREATE INDEX IF NOT EXISTS idx_auto_delete_queue_scheduled_at ON auto_delete_queue(scheduled_at);
CREATE INDEX IF NOT EXISTS idx_auto_delete_queue_status ON auto_delete_queue(status);

-- ── ADVANCED FEATURES SCHEMA ────────────────────────────────────────────────

-- Content Fingerprinting Table (for duplicate detection)
CREATE TABLE IF NOT EXISTS content_fingerprints (
  id SERIAL PRIMARY KEY,
  content_id VARCHAR(255) NOT NULL,
  content_type VARCHAR(50) NOT NULL,
  fingerprint_hash VARCHAR(255) NOT NULL UNIQUE,
  fingerprint_algorithm VARCHAR(50) DEFAULT 'sha256',
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  last_scanned_at TIMESTAMP,
  is_blacklisted BOOLEAN DEFAULT FALSE,
  confidence_score DECIMAL(5,2),
  FOREIGN KEY (content_id) REFERENCES posts(id) ON DELETE CASCADE
);

-- AI Detection Results Table
CREATE TABLE IF NOT EXISTS ai_detection_results (
  id SERIAL PRIMARY KEY,
  content_id VARCHAR(255) NOT NULL,
  content_type VARCHAR(50) NOT NULL,
  detection_type VARCHAR(50) NOT NULL, -- 'copyright', 'adult', 'violence', 'spam'
  confidence_score DECIMAL(5,2) NOT NULL,
  is_flagged BOOLEAN DEFAULT FALSE,
  flag_reason TEXT,
  model_used VARCHAR(100),
  model_version VARCHAR(50),
  detection_metadata JSONB DEFAULT '{}',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  reviewed_by VARCHAR(255),
  reviewed_at TIMESTAMP,
  review_status VARCHAR(50) DEFAULT 'pending', -- 'pending', 'confirmed', 'rejected'
  FOREIGN KEY (content_id) REFERENCES posts(id) ON DELETE CASCADE
);

-- User Reputation System
CREATE TABLE IF NOT EXISTS user_reputation (
  user_id VARCHAR(255) PRIMARY KEY,
  reputation_score INTEGER DEFAULT 100, -- 0-100 scale
  trust_level VARCHAR(20) DEFAULT 'trusted', -- 'trusted', 'warning', 'suspicious', 'blocked'
  total_reports_submitted INTEGER DEFAULT 0,
  accurate_reports INTEGER DEFAULT 0,
  false_reports INTEGER DEFAULT 0,
  report_accuracy_rate DECIMAL(5,2) DEFAULT 100.00,
  total_violations INTEGER DEFAULT 0,
  consecutive_clean_days INTEGER DEFAULT 0,
  last_violation_date TIMESTAMP,
  last_activity_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  reputation_history JSONB DEFAULT '[]',
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Appeal System Table
CREATE TABLE IF NOT EXISTS copyright_appeals (
  id SERIAL PRIMARY KEY,
  report_id INTEGER REFERENCES copyright_reports(id) ON DELETE CASCADE,
  user_id VARCHAR(255) NOT NULL,
  appeal_reason TEXT NOT NULL,
  evidence_urls TEXT[],
  appeal_status VARCHAR(50) DEFAULT 'pending', -- 'pending', 'under_review', 'approved', 'rejected'
  reviewed_by VARCHAR(255),
  reviewed_at TIMESTAMP,
  admin_notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Content Whitelist Table
CREATE TABLE IF NOT EXISTS content_whitelist (
  id SERIAL PRIMARY KEY,
  content_id VARCHAR(255) NOT NULL,
  content_type VARCHAR(50) NOT NULL,
  whitelisted_by VARCHAR(255) NOT NULL,
  whitelist_reason TEXT,
  expiry_date TIMESTAMP,
  is_permanent BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (content_id) REFERENCES posts(id) ON DELETE CASCADE
);

-- Copyright Analytics Table
CREATE TABLE IF NOT EXISTS copyright_analytics (
  id SERIAL PRIMARY KEY,
  date DATE NOT NULL,
  total_reports INTEGER DEFAULT 0,
  confirmed_violations INTEGER DEFAULT 0,
  false_reports INTEGER DEFAULT 0,
  auto_deletions INTEGER DEFAULT 0,
  manual_deletions INTEGER DEFAULT 0,
  appeals_submitted INTEGER DEFAULT 0,
  appeals_approved INTEGER DEFAULT 0,
  users_flagged INTEGER DEFAULT 0,
  users_cleared INTEGER DEFAULT 0,
  avg_response_time_hours DECIMAL(10,2),
  content_type_breakdown JSONB DEFAULT '{}',
  severity_breakdown JSONB DEFAULT '{}',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Multi-level Warning System
CREATE TABLE IF NOT EXISTS user_warnings (
  id SERIAL PRIMARY KEY,
  user_id VARCHAR(255) NOT NULL,
  warning_level INTEGER DEFAULT 1, -- 1-5 scale
  warning_type VARCHAR(50) NOT NULL, -- 'copyright', 'spam', 'abuse', 'other'
  warning_message TEXT NOT NULL,
  expires_at TIMESTAMP,
  is_active BOOLEAN DEFAULT TRUE,
  acknowledged_at TIMESTAMP,
  acknowledged_by VARCHAR(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Content Scan Queue (for real-time scanning)
CREATE TABLE IF NOT EXISTS content_scan_queue (
  id SERIAL PRIMARY KEY,
  content_id VARCHAR(255) NOT NULL,
  content_type VARCHAR(50) NOT NULL,
  content_url TEXT,
  scan_type VARCHAR(50) NOT NULL, -- 'copyright', 'adult', 'violence', 'all'
  priority INTEGER DEFAULT 5, -- 1-10, 1 = highest priority
  status VARCHAR(50) DEFAULT 'pending', -- 'pending', 'scanning', 'completed', 'failed'
  scan_result JSONB DEFAULT '{}',
  error_message TEXT,
  retry_count INTEGER DEFAULT 0,
  max_retries INTEGER DEFAULT 3,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  started_at TIMESTAMP,
  completed_at TIMESTAMP,
  FOREIGN KEY (content_id) REFERENCES posts(id) ON DELETE CASCADE
);

-- Blacklisted Sources Table
CREATE TABLE IF NOT EXISTS blacklisted_sources (
  id SERIAL PRIMARY KEY,
  source_name VARCHAR(255) NOT NULL,
  source_url VARCHAR(255),
  source_type VARCHAR(50) NOT NULL, -- 'website', 'platform', 'channel', 'user'
  blacklist_reason TEXT NOT NULL,
  added_by VARCHAR(255) NOT NULL,
  is_active BOOLEAN DEFAULT TRUE,
  severity VARCHAR(20) DEFAULT 'medium',
  report_count INTEGER DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Advanced Indexes
CREATE INDEX IF NOT EXISTS idx_content_fingerprints_hash ON content_fingerprints(fingerprint_hash);
CREATE INDEX IF NOT EXISTS idx_content_fingerprints_blacklisted ON content_fingerprints(is_blacklisted);
CREATE INDEX IF NOT EXISTS idx_ai_detection_content_id ON ai_detection_results(content_id);
CREATE INDEX IF NOT EXISTS idx_ai_detection_flagged ON ai_detection_results(is_flagged);
CREATE INDEX IF NOT EXISTS idx_user_reputation_score ON user_reputation(reputation_score);
CREATE INDEX IF NOT EXISTS idx_user_reputation_trust ON user_reputation(trust_level);
CREATE INDEX IF NOT EXISTS idx_appeals_status ON copyright_appeals(appeal_status);
CREATE INDEX IF NOT EXISTS idx_appeals_user_id ON copyright_appeals(user_id);
CREATE INDEX IF NOT EXISTS idx_whitelist_content ON content_whitelist(content_id);
CREATE INDEX IF NOT EXISTS idx_analytics_date ON copyright_analytics(date);
CREATE INDEX IF NOT EXISTS idx_warnings_user_id ON user_warnings(user_id);
CREATE INDEX IF NOT EXISTS idx_warnings_active ON user_warnings(is_active);
CREATE INDEX IF NOT EXISTS idx_scan_queue_status ON content_scan_queue(status);
CREATE INDEX IF NOT EXISTS idx_scan_queue_priority ON content_scan_queue(priority);
CREATE INDEX IF NOT EXISTS idx_blacklisted_sources_active ON blacklisted_sources(is_active);

-- Function to update user copyright status
CREATE OR REPLACE FUNCTION update_user_copyright_status(p_user_id VARCHAR)
RETURNS VOID AS $$
BEGIN
  INSERT INTO user_copyright_status (user_id, is_copyright_free, total_violations, active_violations, last_violation_date, status_updated_at)
  VALUES (
    p_user_id,
    FALSE,
    1,
    1,
    CURRENT_TIMESTAMP,
    CURRENT_TIMESTAMP
  )
  ON CONFLICT (user_id) DO UPDATE SET
    total_violations = user_copyright_status.total_violations + 1,
    active_violations = user_copyright_status.active_violations + 1,
    last_violation_date = CURRENT_TIMESTAMP,
    is_copyright_free = FALSE,
    status_updated_at = CURRENT_TIMESTAMP;
END;
$$ LANGUAGE plpgsql;

-- Function to mark user as copyright-free after resolution
CREATE OR REPLACE FUNCTION mark_user_copyright_free(p_user_id VARCHAR)
RETURNS VOID AS $$
BEGIN
  UPDATE user_copyright_status
  SET
    is_copyright_free = TRUE,
    active_violations = 0,
    status_updated_at = CURRENT_TIMESTAMP
  WHERE user_id = p_user_id;
END;
$$ LANGUAGE plpgsql;

-- Trigger to automatically update user copyright status on new report
CREATE OR REPLACE FUNCTION trigger_update_copyright_status()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.report_status = 'confirmed' THEN
    PERFORM update_user_copyright_status(NEW.user_id);
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger
DROP TRIGGER IF EXISTS trg_update_copyright_status ON copyright_reports;
CREATE TRIGGER trg_update_copyright_status
  AFTER UPDATE ON copyright_reports
  FOR EACH ROW
  EXECUTE FUNCTION trigger_update_copyright_status();
