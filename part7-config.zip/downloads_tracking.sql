-- Downloads Tracking Table for Monetixra
-- This table tracks all downloads with timing and income information

CREATE TABLE IF NOT EXISTS downloads (
  id SERIAL PRIMARY KEY,
  user_id VARCHAR(255) NOT NULL,
  download_id VARCHAR(255) UNIQUE NOT NULL,
  type VARCHAR(50) NOT NULL, -- 'video', 'audio', 'audio_extraction'
  quality VARCHAR(20) NOT NULL, -- '240p', '360p', '480p', '720p', '1080p', '2k', 'low', 'medium', 'high', 'ultra'
  start_time TIMESTAMP NOT NULL,
  end_time TIMESTAMP NOT NULL,
  duration INTEGER NOT NULL, -- in milliseconds
  income DECIMAL(10, 4) NOT NULL DEFAULT 0.0000, -- income in USD
  points INTEGER NOT NULL DEFAULT 0,
  timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Index for faster queries
CREATE INDEX IF NOT EXISTS idx_downloads_user_id ON downloads(user_id);
CREATE INDEX IF NOT EXISTS idx_downloads_timestamp ON downloads(timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_downloads_type ON downloads(type);

-- Comments for documentation
COMMENT ON TABLE downloads IS 'Tracks all media downloads with timing and income data';
COMMENT ON COLUMN downloads.user_id IS 'User ID who downloaded the media';
COMMENT ON COLUMN downloads.download_id IS 'Unique download identifier';
COMMENT ON COLUMN downloads.type IS 'Type of download: video, audio, or audio_extraction';
COMMENT ON COLUMN downloads.quality IS 'Quality of the downloaded media';
COMMENT ON COLUMN downloads.start_time IS 'When the download started';
COMMENT ON COLUMN downloads.end_time IS 'When the download completed';
COMMENT ON COLUMN downloads.duration IS 'Download duration in milliseconds';
COMMENT ON COLUMN downloads.income IS 'Income earned from this download in USD';
COMMENT ON COLUMN downloads.points IS 'Points earned from this download';

-- Function to calculate total income for a user
CREATE OR REPLACE FUNCTION get_user_total_income(user_id_param VARCHAR)
RETURNS DECIMAL AS $$
BEGIN
  RETURN (
    SELECT COALESCE(SUM(income), 0)
    FROM downloads
    WHERE user_id = user_id_param
  );
END;
$$ LANGUAGE plpgsql;

-- Function to get download statistics for a user
CREATE OR REPLACE FUNCTION get_user_download_stats(user_id_param VARCHAR)
RETURNS TABLE(
  total_downloads BIGINT,
  total_income DECIMAL,
  total_points BIGINT,
  avg_duration DECIMAL,
  most_downloaded_quality VARCHAR
) AS $$
BEGIN
  RETURN QUERY
  SELECT
    COUNT(*) as total_downloads,
    COALESCE(SUM(income), 0) as total_income,
    COALESCE(SUM(points), 0) as total_points,
    COALESCE(AVG(duration), 0) as avg_duration,
    quality as most_downloaded_quality
  FROM downloads
  WHERE user_id = user_id_param
  GROUP BY quality
  ORDER BY COUNT(*) DESC
  LIMIT 1;
END;
$$ LANGUAGE plpgsql;
