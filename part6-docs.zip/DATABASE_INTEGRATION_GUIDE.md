# Database Integration Guide
## Supabase/PostgreSQL Setup for New Features

**Date:** 2026-10-03
**Status:** Schema and Integration Code Created

---

## ✅ সম্পন্ন হয়েছে

### ১. SQL Schema তৈরি
**ফাইল:** `supabase_new_features_schema.sql`
- সব নতুন ফিচারের জন্য database tables
- Indexes এবং constraints
- Row Level Security (RLS) policies
- Triggers এবং functions

### ২. Node.js Integration Code তৈরি
**ফাইল:** `supabase-new-features-integration.js`
- Database helper functions
- CRUD operations
- Error handling

---

## 📊 Database Tables

### ১. Groups Table
```sql
groups (
  id, name, description, type, cover_image, profile_image,
  category, location, created_by, member_count, post_count,
  rules, tags, settings, created_at, updated_at
)
```

**ফিচার:**
- Public, Private, Secret groups
- Group member management
- Group posts
- Group rules and settings

### ২. Pages Table
```sql
pages (
  id, name, username, description, type, cover_image, profile_image,
  category, location, website, phone, email, created_by,
  follower_count, post_count, verified, tags, settings,
  created_at, updated_at
)
```

**ফিচার:**
- Business, Brand, Community pages
- Page follower management
- Page verification
- Page posts

### ৩. Events Table
```sql
events (
  id, title, description, type, category, cover_image, location,
  online_link, start_date, end_date, timezone, is_all_day,
  organizer_id, organizer_name, attendee_count, interested_count,
  capacity, is_public, is_free, price, currency, tags, settings,
  created_at, updated_at
)
```

**ফিচার:**
- Online, In-person, Hybrid events
- Event categories
- Attendance management
- Free and paid events

### ৪. Notifications Table
```sql
notifications (
  id, recipient_id, sender_id, sender_name, sender_avatar,
  type, title, message, data, priority, is_read, is_seen,
  created_at, expires_at, action_url, action_text
)
```

**ফিচার:**
- Multiple notification types
- Priority levels
- Read/Seen status
- Action URLs

### ৫. Saved Posts Table
```sql
saved_posts (
  id, user_id, post_id, collection_id, created_at
)
```

**ফিচার:**
- Save/unsave posts
- Collection organization
- User saved posts tracking

### ৬. Collections Table
```sql
collections (
  id, user_id, name, description, cover_image, is_private,
  post_count, created_at, updated_at
)
```

**ফিচার:**
- Create collections
- Private/public collections
- Collection management

### ৭. Watch History Table
```sql
watch_history (
  id, user_id, video_id, first_watched_at, last_watched_at,
  total_watch_time, watch_count
)
```

**ফিচার:**
- Track watch history
- Total watch time
- Watch count

### ৮. Video Bookmarks Table
```sql
video_bookmarks (
  id, user_id, video_id, timestamp, note, created_at
)
```

**ফিচার:**
- Video timestamps
- Bookmark notes
- Video navigation

### ৯. Short-Form Videos Table
```sql
short_form_videos (
  id, url, thumbnail, sound_id, caption, hashtags, user_id,
  user_name, user_avatar, duration, aspect_ratio, likes, comments,
  shares, views, is_pinned, is_featured, location, mentions,
  created_at
)
```

**ফিচার:**
- TikTok-style videos
- Sound integration
- Hashtags and mentions
- Engagement tracking

### ১০. Sounds Table
```sql
sounds (
  id, url, title, artist, duration, cover_image, use_count,
  is_trending, created_at
)
```

**ফিচার:**
- Sound library
- Usage tracking
- Trending detection

### ১১. User Interactions Table
```sql
user_interactions (
  id, user_id, target_user_id, target_post_id, interaction_type,
  count, last_interacted_at
)
```

**ফিচার:**
- Track user interactions
- Feed algorithm support
- Engagement scoring

---

## 🚀 ইনস্টলেশন গাইড

### ধাপ ১: Supabase Project Setup

1. Supabase এ নতুন project তৈরি করুন
2. Project settings থেকে `DATABASE_URL` কপি করুন
3. `.env` ফাইলে যোগ করুন:
```env
DATABASE_URL=postgresql://user:password@host:5432/database
```

### ধাপ ২: Schema ইনস্টল করা

```bash
# Supabase SQL Editor এ যান
# অথবা command line থেকে:
psql $DATABASE_URL -f supabase_new_features_schema.sql
```

### ধাপ ৩: Integration Code ব্যবহার করা

```javascript
// server.js এ যোগ করুন
const { GroupsDB, PagesDB, EventsDB, NotificationsDB, SavedPostsDB, WatchHistoryDB } = require('./supabase-new-features-integration');

// Group তৈরির উদাহরণ
app.post('/api/groups', async (req, res) => {
  try {
    const group = await GroupsDB.createGroup(req.body);
    res.json({ success: true, group });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Notification পাঠানোর উদাহরণ
app.post('/api/notifications', async (req, res) => {
  try {
    const notification = await NotificationsDB.createNotification(req.body);
    res.json({ success: true, notification });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});
```

---

## 📋 API Endpoints Examples

### Groups API
```javascript
// Create group
POST /api/groups
Body: { name, description, type, category, createdBy }

// Get group
GET /api/groups/:groupId

// Add member
POST /api/groups/:groupId/members
Body: { userId, role }

// Search groups
GET /api/groups/search?query=term&type=public
```

### Pages API
```javascript
// Create page
POST /api/pages
Body: { name, username, description, type, category, createdBy }

// Get page
GET /api/pages/:pageId

// Add follower
POST /api/pages/:pageId/followers
Body: { userId, role }

// Search pages
GET /api/pages/search?query=term&type=business
```

### Events API
```javascript
// Create event
POST /api/events
Body: { title, description, type, category, startDate, organizerId }

// Get event
GET /api/events/:eventId

// Add attendee
POST /api/events/:eventId/attendees
Body: { userId, status }

// Get upcoming events
GET /api/events/upcoming?limit=10

// Search events
GET /api/events/search?query=term&category=music
```

### Notifications API
```javascript
// Create notification
POST /api/notifications
Body: { recipientId, type, title, message, priority }

// Get notifications
GET /api/notifications/:userId?limit=20&unreadOnly=true

// Get unread count
GET /api/notifications/:userId/unread-count

// Mark as read
POST /api/notifications/:notificationId/read
Body: { userId }

// Mark all as read
POST /api/notifications/:userId/read-all
```

### Saved Posts API
```javascript
// Save post
POST /api/posts/save
Body: { userId, postId, collectionId }

// Unsave post
DELETE /api/posts/unsave
Body: { userId, postId }

// Check if saved
GET /api/posts/saved/:userId/:postId

// Get saved posts
GET /api/posts/saved/:userId?limit=20

// Create collection
POST /api/collections
Body: { userId, name, description, isPrivate }

// Get collections
GET /api/collections/:userId
```

### Watch History API
```javascript
// Record watch history
POST /api/watch-history
Body: { userId, videoId, watchTime }

// Get watch history
GET /api/watch-history/:userId?limit=20
```

---

## 🔒 Row Level Security (RLS)

সব tables এ RLS সক্ষম করা হয়েছে:

### Groups Policies
- ইউজাররা public groups দেখতে পারে
- ইউজাররা নিজের groups তৈরি করতে পারে
- ইউজাররা নিজের groups আপডেট করতে পারে

### Pages Policies
- ইউজাররা সব pages দেখতে পারে
- ইউজাররা নিজের pages তৈরি করতে পারে
- ইউজাররা নিজের pages আপডেট করতে পারে

### Events Policies
- ইউজাররা public events দেখতে পারে
- ইউজাররা নিজের events তৈরি করতে পারে
- ইউজাররা নিজের events আপডেট করতে পারে

### Notifications Policies
- ইউজাররা নিজের notifications দেখতে পারে
- ইউজাররা নিজের notifications আপডেট করতে পারে

### Saved Posts Policies
- ইউজাররা নিজের saved posts দেখতে পারে
- ইউজাররা নিজের saved posts তৈরি/ডিলিট করতে পারে

### Collections Policies
- ইউজাররা নিজের private collections দেখতে পারে
- ইউজাররা নিজের collections তৈরি/আপডেট/ডিলিট করতে পারে

---

## 🎯 Helper Functions

কিছু database functions তৈরি করা হয়েছে:

### `get_unread_count(userId)`
নির্দিষ্ট ইউজারের আনরিড নোটিফিকেশন কাউন্ট পায়।

### `increment_group_member_count(groupId)`
Group member count বাড়ায়।

### `increment_page_follower_count(pageId)`
Page follower count বাড়ায়।

### `increment_event_attendee_count(eventId, status)`
Event attendee বা interested count বাড়ায়।

### `increment_sound_use_count(soundId)`
Sound use count বাড়ায়।

---

## 📊 Indexes

পারফরম্যান্স অপ্টিমাইজেশনের জন্য indexes তৈরি করা হয়েছে:

- `idx_groups_type`, `idx_groups_category`, `idx_groups_created_by`
- `idx_pages_type`, `idx_pages_category`, `idx_pages_username`
- `idx_events_type`, `idx_events_category`, `idx_events_start_date`
- `idx_notifications_recipient_id`, `idx_notifications_type`, `idx_notifications_is_read`
- `idx_saved_posts_user_id`, `idx_saved_posts_post_id`
- `idx_collections_user_id`, `idx_collections_is_private`
- `idx_watch_history_user_id`, `idx_watch_history_last_watched_at`
- এবং আরও অনেক...

---

## 🔧 Triggers

`updated_at` column অটোমেটিক আপডেট করার জন্য triggers তৈরি করা হয়েছে:

- `update_groups_updated_at`
- `update_pages_updated_at`
- `update_events_updated_at`
- `update_collections_updated_at`
- `update_notification_settings_updated_at`

---

## 🧪 Testing

### Database Connection Test
```javascript
const { pool } = require('./supabase-new-features-integration');

async function testConnection() {
  try {
    const result = await pool.query('SELECT NOW()');
    console.log('Database connected:', result.rows[0]);
  } catch (error) {
    console.error('Database connection failed:', error);
  }
}

testConnection();
```

### Create Group Test
```javascript
const { GroupsDB } = require('./supabase-new-features-integration');

async function testCreateGroup() {
  try {
    const group = await GroupsDB.createGroup({
      name: 'Test Group',
      description: 'This is a test group',
      type: 'public',
      category: 'general',
      createdBy: 'user-123'
    });
    console.log('Group created:', group);
  } catch (error) {
    console.error('Error creating group:', error);
  }
}

testCreateGroup();
```

---

## 📋 চেকলিস্ট

- [x] SQL schema তৈরি করা হয়েছে
- [x] Node.js integration code তৈরি করা হয়েছে
- [ ] Supabase project setup করতে হবে
- [ ] Schema ইনস্টল করতে হবে
- [ ] Environment variables সেট করতে হবে
- [ ] API endpoints তৈরি করতে হবে
- [ ] Testing করতে হবে

---

## 🎯 পরবর্তী পদক্ষেপ

আপনি কোন কাজটি পরবর্তী করতে চান?

1. **API endpoints** - server.js এ API endpoints তৈরি করা
2. **UI components** - ফ্রন্টএন্ড UI তৈরি করা
3. **Testing** - database integration টেস্ট করা
4. **পেন্ডিং ফিচার** - বাকি ফিচারগুলি উন্নতি করা

---

**তৈরি করা হয়েছে:** 2026-10-03
**অবস্থা:** Database integration কোড প্রস্তুত
