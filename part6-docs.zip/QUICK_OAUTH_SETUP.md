# ⚡ Quick OAuth Setup Guide - Step by Step

এই গাইডটি অনুসরণ করে আপনি ১০ মিনিটের মধ্যে সব OAuth প্রোভাইডার সেটআপ করতে পারবেন।

## 📋 Prerequisites

- একটি Google অ্যাকাউন্ট
- একটি Facebook অ্যাকাউন্ট
- একটি Apple Developer অ্যাকাউন্ট ($99/year - optional)
- একটি Twitter অ্যাকাউন্ট
- একটি Line অ্যাকাউন্ট
- একটি Kakao অ্যাকাউন্ট

---

## 1️⃣ Google OAuth Setup (5 minutes)

### Step 1: Google Cloud Console এ যান
```
https://console.cloud.google.com/
```

### Step 2: New Project তৈরি করুন
1. উপরের ডান কোণায় "Select a project" ক্লিক করুন
2. "NEW PROJECT" ক্লিক করুন
3. Project name: "Monetixra"
4. "CREATE" ক্লিক করুন

### Step 3: APIs Enable করুন
1. বাম পাশে "APIs & Services" → "Library" যান
2. Search: "Google+ API"
3. "Google+ API" ক্লিক করুন → "ENABLE"
4. Search: "Google Identity"
5. "Google Identity Toolkit API" ক্লিক করুন → "ENABLE"

### Step 4: OAuth Consent Screen সেটআপ করুন
1. "APIs & Services" → "OAuth consent screen" যান
2. "External" সিলেক্ট করুন → "CREATE"
3. App name: "Monetixra"
4. User support email: আপনার email
5. Developer contact: আপনার email
6. "SAVE AND CONTINUE" ক্লিক করুন (সব step skip করে)

### Step 5: OAuth Client ID তৈরি করুন
1. "APIs & Services" → "Credentials" যান
2. "CREATE CREDENTIALS" → "OAuth client ID" ক্লিক করুন
3. Application type: "Web application"
4. Name: "Monetixra Web"
5. Authorized redirect URIs এ যোগ করুন:
   - `http://localhost:3000/auth/google/callback`
   - `https://yourdomain.com/auth/google/callback`
6. "CREATE" ক্লিক করুন

### Step 6: Client ID Copy করুন
- Copy করুন: "Your Client ID" (এটা দেখতে এমন: `123456789-abc.apps.googleusercontent.com`)

---

## 2️⃣ Facebook OAuth Setup (3 minutes)

### Step 1: Facebook Developers এ যান
```
https://developers.facebook.com/
```

### Step 2: New App তৈরি করুন
1. "Get Started" ক্লিক করুন
2. App type: "Consumer" বা "Business"
3. Display name: "Monetixra"
4. Contact email: আপনার email
5. "Create App" ক্লিক করুন

### Step 3: Facebook Login Add করুন
1. Dashboard এ "Add Product" খুঁজুন
2. "Facebook Login" এর নিচে "Set Up" ক্লিক করুন
3. Platform: "Web" সিলেক্ট করুন
4. Site URL: `http://localhost:3000`
5. "Save" ক্লিক করুন

### Step 4: Settings Configure করুন
1. বাম পাশে "Settings" → "Basic" যান
2. Copy করুন: "App ID"
3. Copy করুন: "App Secret" (Show বাটনে ক্লিক করে)

### Step 5: Redirect URIs Add করুন
1. "Settings" → "Facebook Login" → "Settings" যান
2. Valid OAuth Redirect URIs এ যোগ করুন:
   - `http://localhost:3000/auth/facebook/callback`
   - `https://yourdomain.com/auth/facebook/callback`
3. "Save Changes" ক্লিক করুন

---

## 3️⃣ Apple Sign In Setup (Optional - Requires $99/year)

### Step 1: Apple Developer এ যান
```
https://developer.apple.com/
```

### Step 2: New App ID তৈরি করুন
1. "Account" → "Certificates, Identifiers & Profiles"
2. "Identifiers" → "+" ক্লিক করুন
3. "App IDs" সিলেক্ট করুন → "Continue"
4. Description: "Monetixra"
5. Bundle ID: `com.monetixra.app`
6. Capabilities: "Sign In with Apple" চেক করুন
7. "Continue" → "Register"

### Step 3: Service ID তৈরি করুন
1. "Identifiers" → "+" ক্লিক করুন
2. "Services IDs" সিলেক্ট করুন → "Continue"
3. Description: "Monetixra Sign In"
4. Identifier: `com.monetixra.signin`
5. "Continue" → "Register"

### Step 4: Service ID Configure করুন
1. Service ID এ ক্লিক করুন
2. "Sign In with Apple" এ "Configure" ক্লিক করুন
3. Domains and Subdomains: `localhost` বা আপনার domain
4. Return URLs:
   - `http://localhost:3000/auth/apple/callback`
   - `https://yourdomain.com/auth/apple/callback`
5. "Save" ক্লিক করুন

### Step 5: Keys Copy করুন
- Copy করুন: Services ID (Client ID)
- Copy করুন: Team ID
- Copy করুন: Key ID
- Download করুন: .p8 private key file

---

## 4️⃣ Twitter/X OAuth Setup (5 minutes)

### Step 1: Twitter Developer Portal এ যান
```
https://developer.twitter.com/
```

### Step 2: Developer Portal Sign Up করুন
1. "Apply for a Developer Account" ক্লিক করুন
2. Account details পূরণ করুন
3. Use case: "Making a bot" বা "Student project"
4. Submit করুন (approval নিতে ২-৩ দিন লাগতে পারে)

### Step 3: New Project তৈরি করুন
1. Dashboard এ "Create Project" ক্লিক করুন
2. Name: "Monetixra"
3. "Next" → "Create"

### Step 4: New App তৈরি করুন
1. Project এ "Create App" ক্লিক করুন
2. Name: "Monetixra Web"
3. Callback URI: `http://localhost:3000/auth/twitter/callback`
4. Website URL: `http://localhost:3000`
5. "Create" ক্লিক করুন

### Step 5: Keys Copy করুন
1. App settings এ যান
2. Copy করুন: Client ID
3. Copy করুন: Client Secret
4. "App permissions" এ "Read and write" সিলেক্ট করুন
5. OAuth 2.0 enable করুন

---

## 5️⃣ Line Login Setup (4 minutes)

### Step 1: Line Developers এ যান
```
https://developers.line.biz/
```

### Step 2: New Provider তৈরি করুন
1. "Console" এ যান
2. "Create new provider" ক্লিক করুন
3. Provider name: "Monetixra"
4. "Create" ক্লিক করুন

### Step 3: Login Channel তৈরি করুন
1. Provider এ "Create a channel" ক্লিক করুন
2. Channel type: "Login"
3. Channel name: "Monetixra Login"
4. Channel description: "Monetixra social login"
5. "Create" ক্লিক করুন

### Step 4: Channel Settings Configure করুন
1. Channel settings এ যান
2. Copy করুন: Channel ID
3. Copy করুন: Channel Secret (Issue বাটনে ক্লিক করে)

### Step 5: Callback URL Add করুন
1. "Callback URL" tab এ যান
2. Add করুন:
   - `http://localhost:3000/auth/line/callback`
   - `https://yourdomain.com/auth/line/callback`
3. "Save" ক্লিক করুন

---

## 6️⃣ Kakao Login Setup (4 minutes)

### Step 1: Kakao Developers এ যান
```
https://developers.kakao.com/
```

### Step 2: New App তৈরি করুন
1. "My Application" → "Create an App" ক্লিক করুন
2. App name: "Monetixra"
3. Icon upload করুন (optional)
4. "Save" ক্লিক করুন

### Step 3: Platform Settings
1. App settings এ "Platform" যান
2. "Web platform" add করুন
3. Site URL: `http://localhost:3000`
4. "Save" ক্লিক করুন

### Step 4: Kakao Login Enable করুন
1. "Product Settings" → "Kakao Login" যান
2. "Kakao Login" enable করুন
3. "Redirect URI" add করুন:
   - `http://localhost:3000/auth/kakao/callback`
   - `https://yourdomain.com/auth/kakao/callback`
4. "Save" ক্লিক করুন

### Step 5: Keys Copy করুন
1. "App Keys" tab এ যান
2. Copy করুন: REST API Key (এটাই Client ID)
3. Copy করুন: JavaScript Key (optional)
4. Secret key generate করুন এবং copy করুন

---

## 🔧 Configuration Update করুন

সব keys পাওয়ার পর, নিচের ফাইলগুলো update করুন:

### 1. index.html এ update করুন (Line 850-889)

```javascript
window.__MONETIXRA_CONFIG__ = {
  oauth: {
    google: {
      clientId: 'YOUR_GOOGLE_CLIENT_ID_HERE'
    },
    facebook: {
      appId: 'YOUR_FACEBOOK_APP_ID_HERE'
    },
    apple: {
      clientId: 'YOUR_APPLE_SERVICE_ID_HERE'
    },
    twitter: {
      clientId: 'YOUR_TWITTER_CLIENT_ID_HERE'
    },
    line: {
      channelId: 'YOUR_LINE_CHANNEL_ID_HERE'
    },
    kakao: {
      clientId: 'YOUR_KAKAO_CLIENT_ID_HERE'
    }
  }
};
```

### 2. .env ফাইলে update করুন

```env
GOOGLE_CLIENT_ID=your_google_client_id
GOOGLE_CLIENT_SECRET=your_google_client_secret
FACEBOOK_APP_ID=your_facebook_app_id
FACEBOOK_APP_SECRET=your_facebook_app_secret
APPLE_SERVICE_ID=your_apple_service_id
APPLE_TEAM_ID=your_apple_team_id
APPLE_KEY_ID=your_apple_key_id
APPLE_PRIVATE_KEY=path_to_private_key.p8
TWITTER_CLIENT_ID=your_twitter_client_id
TWITTER_CLIENT_SECRET=your_twitter_client_secret
LINE_CHANNEL_ID=your_line_channel_id
LINE_CHANNEL_SECRET=your_line_channel_secret
KAKAO_CLIENT_ID=your_kakao_client_id
KAKAO_CLIENT_SECRET=your_kakao_client_secret
```

---

## 🧪 Test করুন

### Step 1: Server Restart করুন
```bash
# Stop server (Ctrl+C)
# Start again
node server.js
```

### Step 2: Test Page এ যান
```
http://localhost:3000/test-oauth.html
```

### Step 3: প্রতিটি বাটন ক্লিক করুন
- Google বাটন ক্লিক করুন → Google login page আসবে
- Facebook বাটন ক্লিক করুন → Facebook login page আসবে
- ইত্যাদি...

### Step 4: Browser Console Check করুন
- F12 চাপুন
- Console tab এ দেখুন error আছে কিনা

---

## ✅ Verification Checklist

- [ ] Google Client ID copy করা হয়েছে
- [ ] Facebook App ID copy করা হয়েছে
- [ ] Apple Service ID copy করা হয়েছে (optional)
- [ ] Twitter Client ID copy করা হয়েছে
- [ ] Line Channel ID copy করা হয়েছে
- [ ] Kakao Client ID copy করা হয়েছে
- [ ] index.html update করা হয়েছে
- [ ] .env update করা হয়েছে
- [ ] Server restart করা হয়েছে
- [ ] test-oauth.html এ test করা হয়েছে

---

## 🆘 Troubleshooting

### "Popup blocked" error
- Browser popup settings এ allow করুন
- `chrome://settings/content/popups` এ যান

### "Invalid redirect URI" error
- Developer dashboard এ redirect URI ঠিক আছে কিনা check করুন
- কোন trailing slash আছে কিনা check করুন

### "Client ID not configured" error
- index.html এ configuration ঠিক আছে কিনা check করুন
- Browser refresh করুন

### "OAuth callback failed" error
- Server running আছে কিনা check করুন
- .env এ secrets ঠিক আছে কিনা check করুন

---

## 📞 Support

যদি কোনো সমস্যা হয়:
1. Browser console check করুন
2. Server terminal check করুন
3. Developer dashboard এ app status check করুন
4. OAUTH_SETUP_GUIDE.md পড়ুন

---

## 🎉 Done!

সব ঠিকঠাক থাকলে, আপনার Monetixra app এ OAuth login কাজ করবে!
