# Storage Configuration Guide for Monetixra

**Date:** 2026-10-04
**Status:** Verification System Created

---

## 📊 Overview

Monetixra uses multiple storage systems to ensure data persistence, media storage, and real-time communication. This guide verifies all systems are properly configured.

---

## 🔧 Storage Systems

### 1. Supabase Database Storage

**Purpose:** User profiles, login information, points, content data, and app tracking system

**Configuration Required:**
```env
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_ANON_KEY=your-anon-key
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key
```

**What It Stores:**
- User profiles and authentication data
- Points and earnings
- Posts and content metadata
- Transactions and withdrawals
- Groups and pages data
- Notifications and messages

**Verification:**
- ✅ URL format validation
- ✅ API key presence check
- ✅ Connectivity test
- ✅ Fallback mode support

**Setup Guide:** See <ref_file file="D:\monetixra-main 27-09-2026\SUPABASE_SETUP.md" />

---

### 2. Mega Cloud Storage

**Purpose:** Media files (video, audio, images, apps) permanent and secure storage

**Configuration Required:**
```env
MEGA_API_KEY=your-mega-api-key
```

**What It Stores:**
- User-uploaded videos
- Audio files
- Images and avatars
- App files
- Large media content

**Verification:**
- ✅ API key presence check
- ✅ API key format validation
- ⚠️ Fallback to local storage if not configured

**Alternative:** Cloudinary (configured via CLOUDINARY_* env vars)

---

### 3. WebRTC P2P Communication

**Purpose:** Low-latency peer-to-peer high-quality audio/video exchange

**Configuration:**
- No external configuration required
- Browser-native WebRTC support

**What It Provides:**
- Direct peer-to-peer connections
- Audio/video streaming
- Screen sharing
- Real-time communication

**Verification:**
- ✅ Browser WebRTC support check
- ✅ RTCPeerConnection availability
- ✅ STUN/TURN server configuration

---

### 4. Socket.io Signaling Server

**Purpose:** Call creation, connection requests (call ringing), and handshake between users

**Configuration:**
- Built into Node.js server (server.js)
- Uses Socket.io library

**What It Provides:**
- Real-time signaling
- Call initiation
- Connection management
- Live streaming coordination

**Verification:**
- ✅ Socket.io client loaded check
- ✅ Connection status check
- ✅ Server availability

---

### 5. Metered Video TURN/STUN Server

**Purpose:** Uninterrupted and stable video/audio call connections through firewall/NAT

**Configuration Required:**
```env
METERED_API_KEY=your-metered-api-key
```

**What It Provides:**
- TURN server for NAT traversal
- STUN server for IP discovery
- Firewall bypass
- Stable connections

**Verification:**
- ✅ API key presence check
- ✅ TURN server connectivity test
- ✅ ICE credentials retrieval
- ⚠️ Falls back to static ICE servers if not configured

**Static ICE Fallback:**
```javascript
const STATIC_ICE = [
  { urls: 'stun:stun.relay.metered.ca:80' },
  { urls: 'turn:global.relay.metered.ca:80', username: 'd583b2ca0185d321a1fd3b93', credential: 'olukX7eOalIsC9EK' },
  { urls: 'turn:global.relay.metered.ca:80?transport=tcp', username: 'd583b2ca0185d321a1fd3b93', credential: 'olukX7eOalIsC9EK' },
  { urls: 'turn:global.relay.metered.ca:443', username: 'd583b2ca0185d321a1fd3b93', credential: 'olukX7eOalIsC9EK' },
  { urls: 'turns:global.relay.metered.ca:443?transport=tcp', username: 'd583b2ca0185d321a1fd3b93', credential: 'olukX7eOalIsC9EK' }
];
```

---

### 6. Agora RTC SDK

**Purpose:** High-quality audio/video processing, screen sharing, and lag-free real-time calls

**Configuration Required:**
```env
AGORA_APP_ID=your-agora-app-id
AGORA_APP_CERTIFICATE=your-agora-certificate
AGORA_API_KEY=your-agora-api-key
AGORA_API_SECRET=your-agora-api-secret
```

**What It Provides:**
- Advanced audio processing
- Video enhancement
- Screen sharing
- Real-time communication
- Recording capabilities

**Verification:**
- ✅ App ID presence check
- ✅ App ID format validation (32-character hex)
- ✅ Certificate presence check

---

### 7. Data Persistence & Backup

**Purpose:** Client-side data persistence and backup systems

**Systems:**
- IndexedDB (large data storage)
- localStorage (small data storage)
- Enhanced Persistence (js/enhanced-persistence.js)
- Ultimate Persistence (js/ultimate-persistence.js)
- Complete Persistence (js/complete-persistence-system.js)

**What It Stores:**
- User sessions
- Offline data
- Media cache
- Chat history
- Post drafts

**Verification:**
- ✅ IndexedDB support check
- ✅ localStorage support check
- ✅ Persistence systems loaded check
- ✅ Cross-device sync capability

---

## 🔍 Verification System

### How to Verify

1. **Server-Side Verification:**
   ```bash
   curl http://localhost:3000/api/storage/verify
   ```

2. **Web Interface:**
   - Open `storage-verification.html` in browser
   - Automatic verification on load
   - Export report functionality

3. **Programmatic Verification:**
   ```javascript
   const StorageVerification = require('./STORAGE_VERIFICATION_SYSTEM.js');
   const results = await StorageVerification.verifyAll();
   console.log(results);
   ```

### Verification Results

**Status Levels:**
- ✅ **Success:** System is configured and working
- ⚠️ **Warning:** System is configured but has issues
- ❌ **Error:** System is not configured or failing

**Example Response:**
```json
{
  "timestamp": "2026-10-04T00:00:00.000Z",
  "systems": {
    "supabase": {
      "configured": true,
      "url": "https://your-project.supabase.co",
      "reachable": true,
      "fallbackMode": false,
      "lastError": null
    },
    "mega": {
      "configured": true,
      "apiKey": "4dt-..."
    },
    "agora": {
      "configured": true,
      "appId": "e9cfd627...",
      "hasCertificate": true
    },
    "metered": {
      "configured": true,
      "apiKey": "ffb2...",
      "hasStaticICE": true
    },
    "redis": {
      "configured": true,
      "connected": true
    },
    "postgresql": {
      "configured": true,
      "poolSize": 30,
      "idleCount": 5
    }
  },
  "overall": {
    "status": "success",
    "message": "All storage systems configured"
  }
}
```

---

## 📝 Configuration Checklist

### Required for Production:

- [ ] Supabase URL
- [ ] Supabase ANON Key
- [ ] Supabase Service Role Key
- [ ] JWT Secret
- [ ] Admin Password
- [ ] Agora App ID
- [ ] Metered API Key (or static ICE fallback)

### Optional but Recommended:

- [ ] MEGA API Key (or Cloudinary)
- [ ] Redis URL (for caching)
- [ ] PostgreSQL URL (for pooling)
- [ ] Agora Certificate (for enhanced security)

### Development Only:

- [ ] OPENAI_API_KEY (AI features)
- [ ] DEEPSEEK_API_KEY (AI features)
- [ ] GOOGLE_API_KEY (Vision features)

---

## 🚀 Quick Setup

### 1. Environment Variables

Copy `.env.example` to `.env`:
```bash
cp .env.example .env
```

Edit `.env` with your credentials:
```env
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_ANON_KEY=your-anon-key
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key
AGORA_APP_ID=your-agora-app-id
METERED_API_KEY=your-metered-api-key
```

### 2. Supabase Setup

Follow the guide: <ref_file file="D:\monetixra-main 27-09-2026\SUPABASE_SETUP.md" />

Run SQL schema:
```bash
psql -h your-project.supabase.co -U postgres -d postgres -f supabase_schema.sql
```

### 3. Start Server

```bash
npm install
npm start
```

### 4. Verify Storage

Open `storage-verification.html` in browser or run:
```bash
curl http://localhost:3000/api/storage/verify
```

---

## 🔧 Troubleshooting

### Supabase Connection Failed

**Symptoms:** 
- Supabase status shows "error"
- "Supabase connection failed" message

**Solutions:**
1. Check SUPABASE_URL format (should be `https://project-id.supabase.co`)
2. Verify API keys are correct
3. Check network connectivity
4. Enable fallback mode if needed

### MEGA Storage Not Working

**Symptoms:**
- Media uploads fail
- "MEGA API key not configured" warning

**Solutions:**
1. Set MEGA_API_KEY in .env
2. Or configure Cloudinary as alternative
3. Check API key validity

### WebRTC Connection Issues

**Symptoms:**
- Calls not connecting
- "WebRTC not supported" error

**Solutions:**
1. Use a modern browser (Chrome, Firefox, Safari)
2. Check firewall settings
3. Verify TURN/STUN servers
4. Test with static ICE fallback

### Socket.io Not Connecting

**Symptoms:**
- Real-time features not working
- "Socket.io not connected" warning

**Solutions:**
1. Ensure server is running
2. Check CORS configuration
3. Verify WebSocket support
4. Check network/firewall settings

---

## 📊 Data Persistence Strategy

### Primary Storage:
- **Supabase:** User data, posts, transactions (server-side)
- **IndexedDB:** Large media files, offline data (client-side)
- **localStorage:** User preferences, session data (client-side)

### Backup Strategy:
- **Automatic:** Real-time sync to Supabase
- **Manual:** Export functionality in admin panel
- **Cloud:** MEGA/Cloudinary for media files

### Redundancy:
- **Database:** PostgreSQL with PgBouncer pooling
- **Cache:** Redis for performance
- **Fallback:** Local storage when services unavailable

---

## ✅ Verification Tools

### Files Created:
1. **STORAGE_VERIFICATION_SYSTEM.js** - Verification library
2. **storage-verification.html** - Web interface
3. **STORAGE_CONFIGURATION_GUIDE.md** - This guide

### Server Endpoint:
- **GET /api/storage/verify** - Returns storage system status

### Usage:
```javascript
// In browser
fetch('/api/storage/verify')
  .then(r => r.json())
  .then(data => console.log(data));

// In Node.js
const StorageVerification = require('./STORAGE_VERIFICATION_SYSTEM.js');
const results = await StorageVerification.verifyAll();
```

---

## 🎯 Best Practices

### Security:
- Never commit `.env` file
- Use strong secrets
- Rotate API keys regularly
- Enable Row Level Security (RLS) in Supabase

### Performance:
- Use Redis caching for frequently accessed data
- Implement CDN for static assets
- Optimize database queries
- Use connection pooling

### Reliability:
- Implement retry logic for API calls
- Use fallback mechanisms
- Monitor system health
- Set up alerts for failures

### Data Integrity:
- Validate all inputs
- Implement data sanitization
- Use transactions for critical operations
- Regular backups

---

## 📞 Support

For issues with:
- **Supabase:** https://supabase.com/docs
- **Agora:** https://docs.agora.io
- **Metered:** https://www.metered.ca/docs
- **Socket.io:** https://socket.io/docs

---

**Last Updated:** 2026-10-04
**Status:** ✅ Verification System Complete
