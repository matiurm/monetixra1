# Monetixra Video/Audio Transcoding System

## 🎬 Overview

The Monetixra platform now includes a powerful server-side video and audio transcoding system powered by FFmpeg. This allows users to download videos and audio in multiple resolutions and quality settings.

## ✨ Features

### Video Transcoding
- **7 Quality Options**: 240p, 360p, 480p, 640p, 720p, 1080p, 2K
- **Automatic Resolution Scaling**: Maintains aspect ratio with letterboxing
- **Optimized Bitrates**: Quality-appropriate encoding for each resolution
- **Fast Streaming**: Uses faststart for web playback
- **Smart Caching**: Reuses previously transcoded files

### Audio Transcoding
- **4 Quality Options**: Low (64kbps), Medium (128kbps), High (192kbps), Ultra (320kbps)
- **Multiple Formats**: MP3, AAC support
- **High-Quality Encoding**: LAME codec for MP3

### Audio Extraction
- **Extract Audio from Video**: Convert video files to audio-only
- **Quality Selection**: Choose audio quality during extraction
- **Fast Processing**: Direct audio stream extraction

### Additional Features
- **Video Thumbnails**: Generate thumbnails at any timestamp
- **Video Information**: Extract metadata (duration, resolution, codecs)
- **Progress Tracking**: Real-time transcoding progress

## 🔧 Installation

The transcoding system requires FFmpeg and related npm packages:

```bash
npm install
```

Required packages:
- `@ffmpeg-installer/ffmpeg` - FFmpeg binary installer
- `@ffprobe-installer/ffprobe` - FFprobe binary for media analysis
- `fluent-ffmpeg` - Node.js wrapper for FFmpeg

## 🚀 API Endpoints

### Get Available Qualities
```http
GET /api/video/qualities
```

**Response:**
```json
{
  "video": ["240p", "360p", "480p", "640p", "720p", "1080p", "2k"],
  "audio": ["low", "medium", "high", "ultra"],
  "presets": {
    "video": {
      "720p": {
        "width": 1280,
        "height": 720,
        "bitrate": "2500k",
        "audioBitrate": "192k",
        "codec": "libx264",
        "preset": "medium",
        "crf": 22,
        "label": "720p (HD)"
      }
    },
    "audio": {
      "high": {
        "bitrate": "192k",
        "codec": "libmp3lame",
        "quality": 2,
        "label": "192 kbps (High)"
      }
    }
  }
}
```

### Transcode Video
```http
POST /api/video/transcode
Content-Type: application/json

{
  "videoUrl": "https://example.com/video.mp4",
  "quality": "720p"
}
```

**Response:**
```json
{
  "success": true,
  "quality": "720p",
  "downloadUrl": "/downloads/video_abc123_720p.mp4",
  "filename": "video_abc123_720p.mp4",
  "preset": {
    "width": 1280,
    "height": 720,
    "bitrate": "2500k",
    "label": "720p (HD)"
  }
}
```

### Transcode Audio
```http
POST /api/audio/transcode
Content-Type: application/json

{
  "audioUrl": "https://example.com/audio.mp3",
  "quality": "high"
}
```

**Response:**
```json
{
  "success": true,
  "quality": "high",
  "downloadUrl": "/downloads/audio_xyz789_high.mp3",
  "filename": "audio_xyz789_high.mp3",
  "preset": {
    "bitrate": "192k",
    "label": "192 kbps (High)"
  }
}
```

### Extract Audio from Video
```http
POST /api/video/extract-audio
Content-Type: application/json

{
  "videoUrl": "https://example.com/video.mp4",
  "quality": "high"
}
```

**Response:**
```json
{
  "success": true,
  "quality": "high",
  "downloadUrl": "/downloads/audio_extract_def456_high.mp3",
  "filename": "audio_extract_def456_high.mp3",
  "preset": {
    "bitrate": "192k",
    "label": "192 kbps (High)"
  }
}
```

### Get Video Information
```http
POST /api/video/info
Content-Type: application/json

{
  "videoUrl": "https://example.com/video.mp4"
}
```

**Response:**
```json
{
  "success": true,
  "info": {
    "duration": 120.5,
    "size": 15728640,
    "video": {
      "width": 1920,
      "height": 1080,
      "codec": "h264",
      "bitrate": 5000000,
      "fps": 30
    },
    "audio": {
      "codec": "aac",
      "bitrate": 192000,
      "sampleRate": 44100,
      "channels": 2
    }
  }
}
```

### Create Video Thumbnail
```http
POST /api/video/thumbnail
Content-Type: application/json

{
  "videoUrl": "https://example.com/video.mp4",
  "timestamp": "00:00:05",
  "width": 320
}
```

**Response:**
```json
{
  "success": true,
  "thumbnailUrl": "/downloads/thumb_ghi789.jpg",
  "filename": "thumb_ghi789.jpg"
}
```

## 🎨 Client-Side Integration

The download system is automatically integrated via `js/download-system.js`. It provides:

1. **Download Buttons**: Automatically added to video/audio elements
2. **Quality Selector**: User-friendly popup for quality selection
3. **Audio Extraction**: Option to extract audio from videos
4. **Progress Indicators**: Real-time transcoding progress
5. **User Preferences**: Remembers user's quality choices

### Usage Example

The system automatically detects video and audio elements in posts:

```html
<div class="post-media">
  <video src="https://example.com/video.mp4" controls></video>
</div>
```

A download button will be automatically added. When clicked, users can:
- Choose video quality (240p - 2K)
- Choose audio quality (low - ultra)
- Extract audio only from videos

## 📊 Quality Presets

### Video Qualities

| Quality | Resolution | Video Bitrate | Audio Bitrate | Best For |
|---------|------------|---------------|---------------|----------|
| 240p | 426x240 | 300k | 64k | Low bandwidth, older devices |
| 360p | 640x360 | 500k | 96k | Mobile devices, slow connections |
| 480p | 854x480 | 800k | 128k | Standard mobile playback |
| 640p | 854x480 | 1000k | 128k | Enhanced mobile quality |
| 720p | 1280x720 | 2500k | 192k | HD desktop/tablet |
| 1080p | 1920x1080 | 5000k | 192k | Full HD desktop |
| 2K | 2560x1440 | 8000k | 320k | QHD high-quality |

### Audio Qualities

| Quality | Bitrate | Codec | Best For |
|---------|---------|-------|----------|
| Low | 64 kbps | MP3 | Voice, low bandwidth |
| Medium | 128 kbps | MP3 | Standard music |
| High | 192 kbps | MP3 | High-quality music |
| Ultra | 320 kbps | MP3 | Audiophile quality |

## 🔍 Technical Details

### FFmpeg Configuration

The system uses optimized FFmpeg settings:

- **Video Codec**: H.264 (libx264) for maximum compatibility
- **Audio Codec**: AAC for video, MP3 for audio-only
- **Presets**: Fast to slow depending on quality
- **CRF**: Constant Rate Factor for quality control
- **Faststart**: Optimized for web streaming

### File Management

- **Input Files**: Stored in `temp/` directory
- **Output Files**: Stored in `public/downloads/` directory
- **Caching**: Files are cached based on hash to avoid re-transcoding
- **Cleanup**: Old temporary files are automatically removed

### Performance

- **Parallel Processing**: Multiple transcodes can run simultaneously
- **Progress Tracking**: Real-time progress via event listeners
- **Error Handling**: Graceful failure with cleanup
- **Memory Management**: Efficient buffer handling

## 🧪 Testing

Run the test script to verify FFmpeg installation:

```bash
node test-transcoding.js
```

This will:
1. Check FFmpeg availability
2. List all quality presets
3. Verify system configuration

## 🛠️ Configuration

### Server Configuration

The transcoding system is initialized in `server.js`:

```javascript
const videoTranscoder = require('./video-transcoder');

// Initialize on server start
videoTranscoder.init().then(ffmpegAvailable => {
  if (ffmpegAvailable) {
    console.log('✅ FFmpeg Video Transcoding System');
  } else {
    console.log('⚠️ FFmpeg not available - video transcoding disabled');
  }
});
```

### Custom Quality Presets

You can modify quality presets in `video-transcoder.js`:

```javascript
const VIDEO_QUALITY_PRESETS = {
  'custom': {
    width: 1920,
    height: 1080,
    bitrate: '3000k',
    audioBitrate: '192k',
    codec: 'libx264',
    preset: 'medium',
    crf: 21,
    label: 'Custom HD'
  }
};
```

## 📝 Usage Examples

### Download Video in 720p

```javascript
const response = await fetch('/api/video/transcode', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    videoUrl: 'https://example.com/video.mp4',
    quality: '720p'
  })
});

const data = await response.json();
// Download: data.downloadUrl
```

### Extract Audio as High Quality MP3

```javascript
const response = await fetch('/api/video/extract-audio', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    videoUrl: 'https://example.com/video.mp4',
    quality: 'high'
  })
});

const data = await response.json();
// Download: data.downloadUrl
```

## 🔒 Security Considerations

- **File Size Limits**: Configure rate limiting to prevent abuse
- **URL Validation**: Only process trusted media URLs
- **Temp File Cleanup**: Automatic cleanup of temporary files
- **Rate Limiting**: Built-in rate limiting on API endpoints

## 🚀 Performance Tips

1. **Use Caching**: The system automatically caches transcoded files
2. **Choose Appropriate Quality**: Lower quality for faster processing
3. **Monitor Disk Space**: Transcoded files can consume significant space
4. **Background Processing**: Consider using job queues for heavy loads

## 🐛 Troubleshooting

### FFmpeg Not Found

If FFmpeg is not available:
```bash
# The npm packages should install FFmpeg automatically
# If not, install FFmpeg manually:
# Windows: Download from https://ffmpeg.org/download.html
# macOS: brew install ffmpeg
# Linux: sudo apt install ffmpeg
```

### Transcoding Fails

Common issues:
- **Invalid URL**: Ensure the media URL is accessible
- **Unsupported Format**: Some formats may not be supported
- **Insufficient Resources**: Check CPU/memory availability
- **Disk Space**: Ensure adequate disk space for output files

### Slow Performance

Optimization tips:
- Use lower quality presets for faster processing
- Enable hardware acceleration if available
- Process videos during off-peak hours
- Consider CDN integration for distribution

## 📞 Support

For issues or questions:
1. Check the server logs for error messages
2. Verify FFmpeg installation with `node test-transcoding.js`
3. Review API endpoint responses for detailed error information
4. Check disk space and system resources

## 🎯 Future Enhancements

Potential improvements:
- HLS/DASH streaming support
- Hardware acceleration (NVENC, QuickSync)
- Batch processing capabilities
- Advanced filters (watermarks, overlays)
- Format conversion (WebM, AVI, MOV)
- Audio normalization and enhancement
- GIF generation from video segments