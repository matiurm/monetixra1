# Monetixra নতুন ফিচার ইন্টিগ্রেশন গাইড

## ✅ সম্পন্ন হয়েছে

### ১. স্ক্রিপ্ট ট্যাগ যোগ করা হয়েছে
**ফাইল:** `index.html`
**অবস্থা:** সফলভাবে যোগ করা হয়েছে

নিচের স্ক্রিপ্ট ট্যাগগুলি যোগ করা হয়েছে:

```html
<!-- News Feed Algorithm -->
<script src="js/news-feed-algorithm.js" defer></script>

<!-- Advanced Post Targeting -->
<script src="js/advanced-post-targeting.js" defer></script>

<!-- Groups & Pages System -->
<script src="js/groups-pages-system.js" defer></script>

<!-- Events System -->
<script src="js/events-system.js" defer></script>

<!-- Enhanced Video Player -->
<script src="js/enhanced-video-player.js" defer></script>

<!-- Short-Form Video Feed -->
<script src="js/short-form-video-feed.js" defer></script>

<!-- Proper Notifications System -->
<script src="js/proper-notifications-system.js" defer></script>

<!-- Saved Posts Collection -->
<script src="js/saved-posts-collection.js" defer></script>
```

---

## 🎯 পরবর্তী পদক্ষেপ

### ধাপ ১: সার্ভার-সাইড API Endpoints তৈরি করা

`server.js` ফাইলে নিচের API endpoints যোগ করতে হবে:

```javascript
// ═══════════════════════════════════════════════════════
// News Feed API
// ═══════════════════════════════════════════════════════

app.get('/api/feed/personalized', async (req, res) => {
  try {
    const { userId, limit = 20, offset = 0 } = req.query;
    // Implementation using NewsFeedAlgorithm
    res.json({ success: true, feed: [] });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/feed/trending', async (req, res) => {
  try {
    const { limit = 10 } = req.query;
    // Implementation using NewsFeedAlgorithm
    res.json({ success: true, trending: [] });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ═══════════════════════════════════════════════════════
// Post Targeting API
// ═══════════════════════════════════════════════════════

app.post('/api/posts/targeting', async (req, res) => {
  try {
    const { postId, targeting } = req.body;
    // Implementation using AdvancedPostTargeting
    res.json({ success: true, rule: {} });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/posts/visible/:userId', async (req, res) => {
  try {
    const { userId } = req.params;
    // Implementation using AdvancedPostTargeting
    res.json({ success: true, posts: [] });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ═══════════════════════════════════════════════════════
// Groups & Pages API
// ═══════════════════════════════════════════════════════

app.post('/api/groups', async (req, res) => {
  try {
    const groupData = req.body;
    // Implementation using GroupsPagesSystem
    res.json({ success: true, group: {} });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/pages', async (req, res) => {
  try {
    const pageData = req.body;
    // Implementation using GroupsPagesSystem
    res.json({ success: true, page: {} });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/groups/search', async (req, res) => {
  try {
    const { query } = req.query;
    // Implementation using GroupsPagesSystem
    res.json({ success: true, groups: [] });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/pages/search', async (req, res) => {
  try {
    const { query } = req.query;
    // Implementation using GroupsPagesSystem
    res.json({ success: true, pages: [] });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ═══════════════════════════════════════════════════════
// Events API
// ═══════════════════════════════════════════════════════

app.post('/api/events', async (req, res) => {
  try {
    const eventData = req.body;
    // Implementation using EventsSystem
    res.json({ success: true, event: {} });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/events/upcoming', async (req, res) => {
  try {
    const { limit = 10 } = req.query;
    // Implementation using EventsSystem
    res.json({ success: true, events: [] });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/events/search', async (req, res) => {
  try {
    const { query } = req.query;
    // Implementation using EventsSystem
    res.json({ success: true, events: [] });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ═══════════════════════════════════════════════════════
// Notifications API
// ═══════════════════════════════════════════════════════

app.get('/api/notifications/:userId', async (req, res) => {
  try {
    const { userId } = req.params;
    const { limit = 20, unreadOnly = false } = req.query;
    // Implementation using ProperNotificationsSystem
    res.json({ success: true, notifications: [] });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/notifications/mark-read', async (req, res) => {
  try {
    const { notificationId, userId } = req.body;
    // Implementation using ProperNotificationsSystem
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/notifications/mark-all-read', async (req, res) => {
  try {
    const { userId } = req.body;
    // Implementation using ProperNotificationsSystem
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ═══════════════════════════════════════════════════════
// Saved Posts API
// ═══════════════════════════════════════════════════════

app.post('/api/posts/save', async (req, res) => {
  try {
    const { userId, postId, collectionId } = req.body;
    // Implementation using SavedPostsCollection
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.delete('/api/posts/unsave', async (req, res) => {
  try {
    const { userId, postId } = req.body;
    // Implementation using SavedPostsCollection
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/collections', async (req, res) => {
  try {
    const { userId, collectionData } = req.body;
    // Implementation using SavedPostsCollection
    res.json({ success: true, collection: {} });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/collections/:userId', async (req, res) => {
  try {
    const { userId } = req.params;
    // Implementation using SavedPostsCollection
    res.json({ success: true, collections: [] });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});
```

---

### ধাপ ২: UI Components তৈরি করা

প্রতিটি ফিচারের জন্য UI components তৈরি করতে হবে:

#### News Feed UI
```javascript
// ফিড লোড করার উদাহরণ
const feed = NewsFeedAlgorithm.getPersonalizedFeed(allPosts, userId, {
  limit: 20,
  contentType: 'video'
});
```

#### Groups & Pages UI
```javascript
// গ্রুপ তৈরির উদাহরণ
const group = GroupsPagesSystem.createGroup({
  name: 'My Group',
  description: 'Group description',
  type: 'public',
  createdBy: userId
});
```

#### Events UI
```javascript
// ইভেন্ট তৈরির উদাহরণ
const event = EventsSystem.createEvent({
  title: 'My Event',
  description: 'Event description',
  startDate: '2026-10-10T10:00:00Z',
  organizerId: userId
});
```

#### Video Player UI
```javascript
// ভিডিও প্লেয়ার ইনিশিয়ালাইজেশন
const player = EnhancedVideoPlayer.initializePlayer(videoElement, {
  autoplay: true,
  controls: true,
  customControls: true
});
```

#### Notifications UI
```javascript
// নোটিফিকেশন পাওয়ার উদাহরণ
const notifications = ProperNotificationsSystem.getNotifications(userId, {
  limit: 20,
  unreadOnly: true
});
```

---

### ধাপ ৩: Database Integration

Supabase বা PostgreSQL এ ডেটা সংরক্ষণ করতে হবে:

```sql
-- Groups table
CREATE TABLE groups (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  type TEXT DEFAULT 'public',
  created_by TEXT REFERENCES users(id),
  created_at TIMESTAMP DEFAULT NOW()
);

-- Pages table
CREATE TABLE pages (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  type TEXT DEFAULT 'business',
  created_by TEXT REFERENCES users(id),
  created_at TIMESTAMP DEFAULT NOW()
);

-- Events table
CREATE TABLE events (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT,
  start_date TIMESTAMP NOT NULL,
  end_date TIMESTAMP,
  organizer_id TEXT REFERENCES users(id),
  created_at TIMESTAMP DEFAULT NOW()
);

-- Notifications table
CREATE TABLE notifications (
  id TEXT PRIMARY KEY,
  recipient_id TEXT REFERENCES users(id),
  type TEXT NOT NULL,
  title TEXT,
  message TEXT,
  is_read BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT NOW()
);

-- Saved posts table
CREATE TABLE saved_posts (
  id TEXT PRIMARY KEY,
  user_id TEXT REFERENCES users(id),
  post_id TEXT,
  collection_id TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);

-- Collections table
CREATE TABLE collections (
  id TEXT PRIMARY KEY,
  user_id TEXT REFERENCES users(id),
  name TEXT NOT NULL,
  description TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);
```

---

### ধাপ ৪: Testing

প্রতিটি ফিচার টেস্ট করতে হবে:

1. **News Feed Algorithm:**
   - পার্সোনালাইজড ফিড টেস্ট
   - ট্রেন্ডিং পোস্ট টেস্ট
   - এনগেজমেন্ট স্কোরিং টেস্ট

2. **Post Targeting:**
   - লোকেশন টার্গেটিং টেস্ট
   - গ্রুপ টার্গেটিং টেস্ট
   - অডিয়েন্স প্রিভিউ টেস্ট

3. **Groups & Pages:**
   - গ্রুপ তৈরি টেস্ট
   - মেম্বার ম্যানেজমেন্ট টেস্ট
   - গ্রুপ পোস্ট টেস্ট

4. **Events:**
   - ইভেন্ট তৈরি টেস্ট
   - অ্যাটেনডেন্স টেস্ট
   - ইভেন্ট ক্যালেন্ডার টেস্ট

5. **Video Player:**
   - প্লে/পজ টেস্ট
   - স্পিড কন্ট্রোল টেস্ট
   - PiP মোড টেস্ট

6. **Notifications:**
   - নোটিফিকেশন পাঠানো টেস্ট
   - মার্ক রিড টেস্ট
   - কোয়ায়েট আওয়ার্স টেস্ট

7. **Saved Posts:**
   - সেভ পোস্ট টেস্ট
   - কালেকশন তৈরি টেস্ট
   - কালেকশন ম্যানেজমেন্ট টেস্ট

---

## 📋 চেকলিস্ট

- [x] স্ক্রিপ্ট ট্যাগ যোগ করা হয়েছে
- [ ] API endpoints তৈরি করতে হবে
- [ ] UI components তৈরি করতে হবে
- [ ] Database integration করতে হবে
- [ ] Testing করতে হবে
- [ ] Documentation আপডেট করতে হবে

---

## 🎯 পরবর্তী কাজ

আপনি কোন কাজটি পরবর্তী করতে চান?

1. **API endpoints** - server.js এ API endpoints তৈরি করা
2. **UI components** - ফ্রন্টএন্ড UI তৈরি করা
3. **Database integration** - Supabase/PostgreSQL ইন্টিগ্রেশন
4. **Testing** - ফিচার টেস্টিং
5. **পেন্ডিং ফিচার** - বাকি ফিচারগুলি উন্নতি করা

---

**তৈরি করা হয়েছে:** 2026-10-03
**অবস্থা:** ইন্টিগ্রেশন শুরু হয়েছে
