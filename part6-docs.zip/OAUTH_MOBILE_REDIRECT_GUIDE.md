# OAuth Mobile Redirect Guide - বাংলা

## সারসংক্ষেপ

এই গাইডটি দেখাবে কিভাবে Google, Facebook, Apple, Twitter/X, Line, বা Kakao এ সরাসরি redirect করে sign in/sign up করতে হয়, বিশেষ করে মোবাইল ডিভাইসের জন্য।

## তিনটি লগইন পদ্ধতি

### 1. Popup Login (`oauthLogin`)
- একটি popup উইন্ডোতে OAuth provider খোলে
- Desktop এর জন্য সেরা
- ব্যবহারকারী মূল পেজে থাকে

```html
<button onclick="oauthLogin('google')">Sign in with Google</button>
```

### 2. Redirect Login (`oauthLoginRedirect`)
- সরাসরি OAuth provider এ redirect করে
- Mobile এর জন্য সেরা
- ব্যবহারকারী মোবাইল app এ সরাসরি যায়

```html
<button onclick="oauthLoginRedirect('google')">Sign in with Google</button>
```

### 3. Smart Login (`oauthLoginSmart`) ⭐ সবচেয়ে সেরা
- স্বয়ংক্রিয়ভাবে ডিভাইস ধরন চিনতে পারে
- Mobile হলে redirect ব্যবহার করে
- Desktop হলে popup ব্যবহার করে
- একটি বাটনেই সব সমাধান

```html
<button onclick="oauthLoginSmart('google')">Sign in with Google</button>
```

## সমর্থিত Providers

সব providers এই তিনটি পদ্ধতিই সমর্থন করে:

- **Google** - `oauthLogin('google')`
- **Facebook** - `oauthLogin('facebook')`
- **Apple** - `oauthLogin('apple')`
- **Twitter/X** - `oauthLogin('twitter')`
- **Line** - `oauthLogin('line')`
- **Kakao** - `oauthLogin('kakao')`

## উদাহরণ: সব Providers এর জন্য Smart Login

```html
<!DOCTYPE html>
<html>
<head>
  <title>Monetixra Login</title>
</head>
<body>
  <h1>Sign In</h1>
  
  <!-- Smart Login Buttons - স্বয়ংক্রিয়ভাবে সেরা পদ্ধতি বেছে নেয় -->
  <button onclick="oauthLoginSmart('google')">Sign in with Google</button>
  <button onclick="oauthLoginSmart('facebook')">Sign in with Facebook</button>
  <button onclick="oauthLoginSmart('apple')">Sign in with Apple</button>
  <button onclick="oauthLoginSmart('twitter')">Sign in with X</button>
  <button onclick="oauthLoginSmart('line')">Sign in with Line</button>
  <button onclick="oauthLoginSmart('kakao')">Sign in with Kakao</button>

  <!-- Load OAuth Script -->
  <script src="js/advanced-oauth-auth.js"></script>
  
  <!-- Configuration -->
  <script>
    window.__MONETIXRA_CONFIG__ = {
      oauth: {
        google: {
          clientId: 'YOUR_GOOGLE_CLIENT_ID'
        },
        facebook: {
          appId: 'YOUR_FACEBOOK_APP_ID'
        },
        apple: {
          clientId: 'YOUR_APPLE_SERVICE_ID'
        },
        twitter: {
          clientId: 'YOUR_TWITTER_CLIENT_ID'
        },
        line: {
          channelId: 'YOUR_LINE_CHANNEL_ID'
        },
        kakao: {
          clientId: 'YOUR_KAKAO_CLIENT_ID'
        }
      }
    };
  </script>
</body>
</html>
```

## Mobile vs Desktop এর আচরণ

### Mobile ডিভাইসে (Android, iPhone, iPad)
- **Smart Login** স্বয়ংক্রিয়ভাবে `oauthLoginRedirect` ব্যবহার করে
- ব্যবহারকারী সরাসরি Google/Facebook/Apple app এ চলে যায়
- Login করার পর স্বয়ংক্রিয়ভাবে আপনার app এ ফিরে আসে

### Desktop ডিভাইসে
- **Smart Login** স্বয়ংক্রিয়ভাবে `oauthLogin` (popup) ব্যবহার করে
- একটি popup উইন্ডোতে OAuth provider খোলে
- ব্যবহারকারী মূল পেজে থাকে

## কনফিগারেশন

প্রতিটি provider এর জন্য আপনাকে তাদের ডেভেলপার পোর্টাল থেকে Client ID নিতে হবে:

1. **Google** - [Google Cloud Console](https://console.cloud.google.com/)
2. **Facebook** - [Facebook Developers](https://developers.facebook.com/)
3. **Apple** - [Apple Developer](https://developer.apple.com/)
4. **Twitter/X** - [Twitter Developer Portal](https://developer.twitter.com/)
5. **Line** - [Line Developers](https://developers.line.biz/)
6. **Kakao** - [Kakao Developers](https://developers.kakao.com/)

বিস্তারিত সেটআপ গাইডের জন্য `js/OAUTH_SETUP_GUIDE.md` দেখুন।

## টেস্টিং

আপনার OAuth সিস্টেম টেস্ট করতে:

1. `test-oauth.html` ফাইলটি ব্রাউজারে খুলুন
2. প্রতিটি provider এর জন্য তিনটি বাটন দেখতে পাবেন:
   - Popup
   - Redirect
   - Smart (স্বয়ংক্রিয়)
3. Mobile ডিভাইসে টেস্ট করলে "Smart" বাটন redirect ব্যবহার করবে
4. Desktop এ টেস্ট করলে "Smart" বাটন popup ব্যবহার করবে

## নিরাপত্তা

- **State Parameter** - CSRF আক্রমণ প্রতিরোধ করে
- **PKCE** - Authorization code interception প্রতিরোধ করে
- **HTTPS** - Production এ সবসময় HTTPS ব্যবহার করুন
- **Token Expiration** - উপযুক্ত token expiration সেট করুন

## সমস্যা সমাধান

### "Popup blocked" ত্রুটি
- Popup ব্যবহার না করে `oauthLoginRedirect` বা `oauthLoginSmart` ব্যবহার করুন
- Mobile ডিভাইসের জন্য redirect পদ্ধতি সেরা

### "Mobile app এ redirect হচ্ছে না"
- নিশ্চিত করুন যে redirect URI সঠিকভাবে কনফিগার করা আছে
- Provider এর ডেভেলপার পোর্টালে redirect URI যোগ করুন

### "লগইন করার পর ফিরে আসছে না"
- নিশ্চিত করুন যে callback endpoint ঠিকমতো কাজ করছে
- Server.js এ `/api/oauth/callback` endpoint চেক করুন

## সেরা অনুশীলন

1. **সবসময় `oauthLoginSmart` ব্যবহার করুন** - এটি স্বয়ংক্রিয়ভাবে সেরা পদ্ধতি বেছে নেয়
2. **Mobile ডিভাইসে টেস্ট করুন** - নিশ্চিত করুন যে redirect ঠিকমতো কাজ করছে
3. **Desktop এ টেস্ট করুন** - নিশ্চিত করুন যে popup ঠিকমতো কাজ করছে
4. **HTTPS ব্যবহার করুন** - Production এ সবসময় HTTPS ব্যবহার করুন
5. **Redirect URI যোগ করুন** - প্রতিটি provider এর ডেভেলপার পোর্টালে redirect URI যোগ করুন

## সহায়তা

আরও তথ্যের জন্য:
- `js/OAUTH_SETUP_GUIDE.md` - বিস্তারিত সেটআপ গাইড
- `test-oauth.html` - টেস্টিং পেজ
- `js/advanced-oauth-auth.js` - OAuth সিস্টেম কোড
