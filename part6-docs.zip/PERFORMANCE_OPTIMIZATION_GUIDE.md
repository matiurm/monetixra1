# Monetixra Performance Optimization Guide
## Step-by-Step Implementation Plan

**Current Status:**
- File Size: ~1.46 MB (index.html)
- Script Tags: 107
- Style Tags: 9
- Mobile Load Time: 8-10s
- Lighthouse Score: 40-50

**Target Status:**
- Initial Load: <200KB
- Script Tags: <20 (consolidated)
- Mobile Load Time: <2s
- Lighthouse Score: 90+

---

## ✅ COMPLETED (Already Done)

### 1. Viewport Meta Tag Fix
- Changed `maximum-scale=1.0` to `maximum-scale=5.0`
- Allows users to zoom (accessibility improvement)
- File: `index.html` line 135

---

## 🚀 PHASE 1: Critical CSS Extraction (Do First)

### Step 1.1: Extract Critical CSS
The current inline CSS is ~200 lines. Extract to separate file:

```bash
# Create CSS directory if not exists
mkdir -p css

# Extract critical CSS from index.html (lines 180-424)
# Save to css/critical.css
```

**Critical CSS Content:**
- CSS variables (:root)
- Reset styles
- Loading screen
- Bottom navigation
- FAB button
- Input styles
- Basic animations

**Action Required:**
1. Copy CSS from `<style>` tag (lines 180-424)
2. Paste into `css/critical.css`
3. Replace inline `<style>` with:
```html
<link rel="stylesheet" href="css/critical.css">
```

**Expected Impact:**
- Reduce HTML size by ~8KB
- Enable browser caching for CSS
- Faster initial render

---

## 🚀 PHASE 2: Script Lazy Loading (Do Second)

### Step 2.1: Identify Critical vs Non-Critical Scripts

**Critical Scripts (Load Immediately):**
- enhanced-persistence.js
- biometric-auth.js
- mobile-deep-linking.js

**Non-Critical Scripts (Lazy Load):**
- advanced-ai-chatbot.js
- advanced-calling-system.js
- advanced-collaboration.js
- advanced-defi-integration.js
- advanced-nft-marketplace.js
- advanced-oauth-auth.js
- ai-content-generation.js
- ai-messaging.js
- ai-ml-enhancements.js
- analytics-monitoring.js
- call-analytics.js
- collaboration-tools.js
- complete-persistence-system.js
- copyright-enforcement.js
- cross-device-sync.js
- defi-integration.js
- download-system.js
- gamification.js
- global-feed-system.js
- multilingual-support.js
- performance-enhancements.js
- secure-calling.js
- settings-enhancements.js
- smart-notifications.js
- video-effects.js
- video-processing-advanced.js
- web3-integration.js

### Step 2.2: Implement Lazy Loading

Replace current script tags with lazy loading:

```html
<!-- Critical scripts (load immediately) -->
<script src="js/enhanced-persistence.js" defer></script>
<script src="js/biometric-auth.js" defer></script>
<script src="js/mobile-deep-linking.js" defer></script>

<!-- Lazy loaded scripts -->
<script>
  // Lazy load non-critical modules
  function loadScript(src) {
    return new Promise((resolve, reject) => {
      const script = document.createElement('script');
      script.src = src;
      script.defer = true;
      script.onload = resolve;
      script.onerror = reject;
      document.head.appendChild(script);
    });
  }

  // Load scripts when user interacts or after initial load
  document.addEventListener('DOMContentLoaded', async () => {
    // Load AI features after 2 seconds
    setTimeout(async () => {
      await loadScript('js/advanced-ai-chatbot.js');
      await loadScript('js/ai-messaging.js');
    }, 2000);

    // Load calling features when user navigates to call tab
    // (add event listener for tab switching)
  });
</script>
```

**Expected Impact:**
- Reduce initial load by ~500KB
- Faster time to interactive
- Better mobile performance

---

## 🚀 PHASE 3: Event Listener Consolidation (Do Third)

### Step 3.1: Identify Duplicate Event Listeners

Current issues:
- Multiple `DOMContentLoaded` listeners
- 15+ `setInterval` calls
- No cleanup on page unload

### Step 3.2: Create Central Event Manager

Create `js/event-manager.js`:

```javascript
/**
 * Central Event Manager
 * Consolidates all event listeners and provides cleanup
 */
const EventManager = (function() {
  'use strict';

  const listeners = new Map();
  const intervals = new Set();
  const timeouts = new Set();

  function addEventListener(element, event, handler, options) {
    const key = `${event}_${Date.now()}`;
    element.addEventListener(event, handler, options);
    listeners.set(key, { element, event, handler, options });
    return key;
  }

  function removeEventListener(key) {
    const entry = listeners.get(key);
    if (entry) {
      entry.element.removeEventListener(entry.event, entry.handler, entry.options);
      listeners.delete(key);
    }
  }

  function setInterval(callback, delay) {
    const id = window.setInterval(callback, delay);
    intervals.add(id);
    return id;
  }

  function clearInterval(id) {
    window.clearInterval(id);
    intervals.delete(id);
  }

  function setTimeout(callback, delay) {
    const id = window.setTimeout(callback, delay);
    timeouts.add(id);
    return id;
  }

  function clearTimeout(id) {
    window.clearTimeout(id);
    timeouts.delete(id);
  }

  function cleanup() {
    // Remove all event listeners
    listeners.forEach((entry, key) => {
      entry.element.removeEventListener(entry.event, entry.handler, entry.options);
    });
    listeners.clear();

    // Clear all intervals
    intervals.forEach(id => window.clearInterval(id));
    intervals.clear();

    // Clear all timeouts
    timeouts.forEach(id => window.clearTimeout(id));
    timeouts.clear();
  }

  // Cleanup on page unload
  window.addEventListener('beforeunload', cleanup);

  return {
    addEventListener,
    removeEventListener,
    setInterval,
    clearInterval,
    setTimeout,
    clearTimeout,
    cleanup
  };
})();
```

### Step 3.3: Replace Event Listeners

Replace all event listeners in codebase:

**Before:**
```javascript
document.addEventListener('DOMContentLoaded', init);
setInterval(updateFeed, 5000);
```

**After:**
```javascript
EventManager.addEventListener(document, 'DOMContentLoaded', init);
EventManager.setInterval(updateFeed, 5000);
```

**Expected Impact:**
- Prevent memory leaks
- Better battery life on mobile
- Cleaner code

---

## 🚀 PHASE 4: Image Optimization (Do Fourth)

### Step 4.1: Implement Native Lazy Loading

Add `loading="lazy"` to all images:

```html
<!-- Before -->
<img src="image.jpg" alt="description">

<!-- After -->
<img src="image.jpg" alt="description" loading="lazy" width="800" height="600">
```

### Step 4.2: Use Responsive Images

Implement `srcset` for different screen sizes:

```html
<img
  src="image-800.jpg"
  srcset="image-400.jpg 400w,
          image-800.jpg 800w,
          image-1200.jpg 1200w"
  sizes="(max-width: 600px) 400px,
         (max-width: 1200px) 800px,
         1200px"
  alt="description"
  loading="lazy">
```

### Step 4.3: Convert to WebP

Convert images to WebP format with fallbacks:

```html
<picture>
  <source srcset="image.webp" type="image/webp">
  <source srcset="image.jpg" type="image/jpeg">
  <img src="image.jpg" alt="description" loading="lazy">
</picture>
```

**Expected Impact:**
- 30-50% smaller image sizes
- Faster image loading
- Better mobile experience

---

## 🚀 PHASE 5: Code Splitting (Do Fifth)

### Step 5.1: Split HTML into Components

Current structure (1.46MB single file):
```
index.html (everything)
```

Target structure:
```
index.html (<50KB - shell only)
├── css/
│   ├── critical.css (inline)
│   └── main.css (deferred)
├── js/
│   ├── core.js (essential - <50KB)
│   ├── feed.js (lazy load)
│   ├── chat.js (lazy load)
│   ├── live.js (lazy load)
│   └── features/ (modular)
└── assets/
    ├── images/ (optimized)
    └── icons/ (SVG)
```

### Step 5.2: Implement Code Splitting

**Step 1: Create Shell HTML**
```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Monetixra</title>
  <link rel="stylesheet" href="css/critical.css">
</head>
<body>
  <div id="app"></div>
  <script src="js/core.js"></script>
</body>
</html>
```

**Step 2: Create Core JS**
```javascript
// js/core.js
import { loadFeed } from './feed.js';
import { loadChat } from './chat.js';
import { loadLive } from './live.js';

// Initialize app
document.addEventListener('DOMContentLoaded', () => {
  const app = document.getElementById('app');
  // Render shell
  app.innerHTML = renderShell();

  // Lazy load features based on navigation
  handleNavigation();
});
```

**Expected Impact:**
- Initial load <200KB
- Faster time to interactive
- Better code organization

---

## 🚀 PHASE 6: Service Worker (Do Sixth)

### Step 6.1: Update Service Worker

Enhance existing `sw.js` for better caching:

```javascript
const CACHE_NAME = 'monetixra-v2';
const STATIC_CACHE = 'static-v2';
const DYNAMIC_CACHE = 'dynamic-v2';

// Cache static assets
const STATIC_ASSETS = [
  '/',
  '/css/critical.css',
  '/js/core.js',
  '/icon-192.png',
  '/icon-512.png'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(STATIC_CACHE)
      .then(cache => cache.addAll(STATIC_ASSETS))
  );
});

self.addEventListener('fetch', (event) => {
  event.respondWith(
    caches.match(event.request)
      .then(response => {
        return response || fetch(event.request)
          .then(fetchResponse => {
            // Cache dynamic responses
            return caches.open(DYNAMIC_CACHE)
              .then(cache => {
                cache.put(event.request, fetchResponse.clone());
                return fetchResponse;
              });
          });
      })
  );
});
```

**Expected Impact:**
- Offline functionality
- Faster subsequent loads
- Better mobile experience

---

## 🚀 PHASE 7: Performance Monitoring (Do Seventh)

### Step 7.1: Add Performance Metrics

Create `js/performance-monitor.js`:

```javascript
/**
 * Performance Monitoring
 * Tracks key metrics and reports to analytics
 */
const PerformanceMonitor = (function() {
  'use strict';

  function trackMetrics() {
    // Core Web Vitals
    if ('PerformanceObserver' in window) {
      // LCP (Largest Contentful Paint)
      const lcpObserver = new PerformanceObserver((list) => {
        const entries = list.getEntries();
        const lastEntry = entries[entries.length - 1];
        console.log('LCP:', lastEntry.renderTime || lastEntry.loadTime);
      });
      lcpObserver.observe({ entryTypes: ['largest-contentful-paint'] });

      // FID (First Input Delay)
      const fidObserver = new PerformanceObserver((list) => {
        const entries = list.getEntries();
        entries.forEach(entry => {
          console.log('FID:', entry.processingStart - entry.startTime);
        });
      });
      fidObserver.observe({ entryTypes: ['first-input'] });

      // CLS (Cumulative Layout Shift)
      const clsObserver = new PerformanceObserver((list) => {
        let clsValue = 0;
        list.getEntries().forEach(entry => {
          if (!entry.hadRecentInput) {
            clsValue += entry.value;
          }
        });
        console.log('CLS:', clsValue);
      });
      clsObserver.observe({ entryTypes: ['layout-shift'] });
    }

    // Navigation timing
    window.addEventListener('load', () => {
      const perfData = performance.timing;
      const pageLoadTime = perfData.loadEventEnd - perfData.navigationStart;
      const connectTime = perfData.responseEnd - perfData.requestStart;
      const renderTime = perfData.domComplete - perfData.domLoading;

      console.log('Page Load Time:', pageLoadTime);
      console.log('Connect Time:', connectTime);
      console.log('Render Time:', renderTime);
    });
  }

  return {
    trackMetrics
  };
})();

// Initialize
PerformanceMonitor.trackMetrics();
```

**Expected Impact:**
- Real-time performance tracking
- Identify bottlenecks
- Data-driven optimization

---

## 📊 EXPECTED RESULTS

### Before Optimization:
- Load Time: 8-10s (mobile)
- File Size: 1.46MB
- Script Tags: 107
- Lighthouse: 40-50

### After Optimization:
- Load Time: <2s (mobile)
- Initial File Size: <200KB
- Script Tags: <20
- Lighthouse: 90+

---

## 🎯 IMPLEMENTATION ORDER

1. ✅ **Viewport Fix** (DONE)
2. **Critical CSS Extraction** (30 min)
3. **Script Lazy Loading** (1 hour)
4. **Event Listener Consolidation** (2 hours)
5. **Image Optimization** (1 hour)
6. **Code Splitting** (4 hours)
7. **Service Worker Update** (1 hour)
8. **Performance Monitoring** (30 min)

**Total Time:** ~10 hours

---

## 🔧 TOOLS TO USE

### For Image Optimization:
- **Squoosh** (https://squoosh.app/) - Free image optimizer
- **ImageMagick** - Command line tool
- **Sharp** - Node.js image processor

### For Code Analysis:
- **Lighthouse** - Chrome DevTools
- **WebPageTest** - https://www.webpagetest.org/
- **Chrome DevTools** - Performance tab

### For Build Tools:
- **Webpack** - Module bundler
- **Rollup** - Alternative bundler
- **Vite** - Fast build tool

---

## 📝 NOTES

- Test each phase on real mobile devices
- Monitor Lighthouse scores after each change
- Keep backups before major changes
- Test offline functionality after service worker update
- Verify all features still work after code splitting

---

**Generated:** 2026-10-03
**Status:** Ready for Implementation
