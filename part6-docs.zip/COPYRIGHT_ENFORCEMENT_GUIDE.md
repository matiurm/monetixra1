# Copyright Enforcement System - Complete Advanced Guide

## সিস্টেম ওভারভিউ (System Overview)

এই কপিরাইট এনফোর্সমেন্ট সিস্টেমটি Monetixra প্ল্যাটফর্মে কপিরাইট লঙ্ঘন ডিটেক্ট করে, ইউজারকে নোটিফিকেশন দেয় এবং ১২-২৪ ঘন্টার মধ্যে অটোমেটিক কন্টেন্ট ডিলিট করে।

This copyright enforcement system detects copyright violations, notifies users, and automatically deletes content within 12-24 hours on the Monetixra platform.

## মূল ফিচারসমূহ (Key Features)

### 1. কপিরাইট রিপোর্ট সিস্টেম (Copyright Reporting System)
- যেকোনো ইউজার কপিরাইট লঙ্ঘন রিপোর্ট করতে পারে
- রিপোর্টে কন্টেন্ট টাইপ (ভিডিও, অডিও, ফটো, টেক্সট) নির্দিষ্ট করা যায়
- সিভিয়রিটি লেভেল (low, medium, high, critical) সেট করা যায়
- অরিজিনাল সোর্স/ওয়েবসাইট উল্লেখ করা যায়

### 2. অটো-ডিলিট সিস্টেম (Auto-Delete System)
- **Critical**: ১২ ঘন্টার মধ্যে ডিলিট
- **High**: ১৮ ঘন্টার মধ্যে ডিলিট
- **Medium/Low**: ২৪ ঘন্টার মধ্যে ডিলিট
- অটোমেটিক স্কেডিউলার প্রতি ঘন্টা চেক করে
- ডিলিট হওয়া কন্টেন্ট ইউজারকে নোটিফাই করে

### 3. নোটিফিকেশন সিস্টেম (Notification System)
- রিয়েল-টাইম সকেট নোটিফিকেশন
- পুশ নোটিফিকেশন (Web Push)
- ইন-অ্যাপ ব্যানার নোটিফিকেশন
- ডিটেইলস মডাল উইন্ডো

### 4. ইউজার কপিরাইট স্ট্যাটাস ট্র্যাকিং (User Copyright Status Tracking)
- ইউজার আইডি কপিরাইট-মুক্ত কিনা ট্র্যাক করে
- টোটাল ভায়োলেশন কাউন্ট
- অ্যাক্টিভ ভায়োলেশন কাউন্ট
- শেষ ভায়োলেশন ডেট

## 🚀 উন্নত ফিচারসমূহ (Advanced Features)

### 5. AI-ভিত্তিক কন্টেন্ট ডিটেকশন (AI-Based Content Detection)
- OpenAI GPT-4 দিয়ে কপিরাইট ডিটেকশন
- অটোমেটিক কন্টেন্ট স্ক্যানিং
- কনফিডেন্স স্কোর ভিত্তিক ফ্ল্যাগিং
- হাই কনফিডেন্সে অটো রিপোর্টিং

### 6. কন্টেন্ট ফিঙ্গারপ্রিন্টিং (Content Fingerprinting)
- SHA-256 হ্যাশ ভিত্তিক ডুপ্লিকেট ডিটেকশন
- ব্ল্যাকলিস্টেড কন্টেন্ট ম্যাচিং
- রিয়েল-টাইম ডুপ্লিকেট চেক
- কন্টেন্ট অরিজিন ট্র্যাকিং

### 7. রিয়েল-টাইম কন্টেন্ট স্ক্যানিং (Real-Time Content Scanning)
- আপলোডের সময় স্ক্যানিং
- প্রায়রিটি ভিত্তিক স্ক্যান কিউ
- ব্যাচ প্রসেসিং
- অটোমেটিক রিট্রাই মেকানিজম

### 8. মাল্টি-লেভেল ওয়ার্নিং সিস্টেম (Multi-Level Warning System)
- ১-৫ লেভেল ওয়ার্নিং
- কাস্টম ওয়ার্নিং মেসেজ
- এক্সপায়ারি ডেট
- ওয়ার্নিং হিস্ট্রি

### 9. ইউজার রেপুটেশন সিস্টেম (User Reputation System)
- ০-১০০ স্কেল রেপুটেশন স্কোর
- ট্রাস্ট লেভেল (trusted, warning, suspicious, blocked)
- রিপোর্ট অ্যাকুরেসি ট্র্যাকিং
- রেপুটেশন হিস্ট্রি

### 10. অ্যাপিল সিস্টেম (Appeal System)
- ভুল রিপোর্টের জন্য অ্যাপিল
- এভিডেন্স আপলোড
- অ্যাডমিন রিভিউ
- অ্যাপিল স্ট্যাটাস ট্র্যাকিং

### 11. কন্টেন্ট হোয়াইটলিস্ট সিস্টেম (Content Whitelist System)
- নিরাপদ কন্টেন্ট হোয়াইটলিস্ট
- টেম্পোরারি এবং পারমানেন্ট হোয়াইটলিস্ট
- এক্সপায়ারি ডেট
- হোয়াইটলিস্ট রিজন

### 12. ব্ল্যাকলিস্টেড সোর্স ম্যানেজমেন্ট (Blacklisted Sources Management)
- ওয়েবসাইট/প্ল্যাটফর্ম ব্ল্যাকলিস্ট
- সোর্স টাইপ ক্যাটাগরাইজেশন
- সিভিয়রিটি লেভেল
- রিপোর্ট কাউন্ট ট্র্যাকিং

### 13. অ্যাডভান্সড অ্যানালিটিক্স ড্যাশবোর্ড (Advanced Analytics Dashboard)
- ডেইলি অ্যানালিটিক্স অ্যাগ্রিগেশন
- কন্টেন্ট টাইপ ব্রেকডাউন
- সিভিয়রিটি ব্রেকডাউন
- অ্যাকুরেসি রেট ক্যালকুলেশন

## ইনস্টলেশন (Installation)

### 1. ডাটাবেস স্কিমা সেটআপ (Database Schema Setup)

```bash
# PostgreSQL ডাটাবেসে স্কিমা রান করুন
psql -U your_user -d your_database -f copyright-schema.sql
```

অথবা Supabase SQL Editor এ গিয়ে `copyright-schema.sql` ফাইলের কন্টেন্ট পেস্ট করুন।

### 2. এনভায়রনমেন্ট ভেরিয়েবল সেটআপ (Environment Variables Setup)

`.env` ফাইলে নিচের ভেরিয়েবলগুলো যোগ করুন:

```env
# Copyright Enforcement System
COPYRIGHT_AUTO_DELETE_HOURS=12
COPYRIGHT_AUTO_DELETE_HOURS_HIGH=18
COPYRIGHT_AUTO_DELETE_HOURS_CRITICAL=12
COPYRIGHT_SCHEDULER_INTERVAL_MINUTES=60
COPYRIGHT_NOTIFICATION_ENABLED=true
COPYRIGHT_AUTO_DELETE_ENABLED=true
```

### 3. ফ্রন্টএন্ড স্ক্রিপ্ট লোড (Frontend Script Loading)

`index.html` এ ইতিমধ্যে স্ক্রিপ্ট যোগ করা হয়েছে:

```html
<!-- Copyright Enforcement System -->
<script src="js/copyright-enforcement.js"></script>
```

## API এন্ডপয়েন্টসমূহ (API Endpoints)

### বেসিক এন্ডপয়েন্টসমূহ (Basic Endpoints)

### 1. কপিরাইট রিপোর্ট জমা দিন (Submit Copyright Report)

```javascript
POST /api/copyright/report

{
  "userId": "target_user_id",
  "reportedBy": "reporter_user_id",
  "contentType": "video", // video, audio, photo, text
  "contentId": "content_id",
  "contentUrl": "https://example.com/content",
  "originalSource": "YouTube",
  "reportReason": "Copyright violation detected",
  "severity": "medium" // low, medium, high, critical
}
```

### 2. ইউজারের কপিরাইট রিপোর্ট পান (Get User Copyright Reports)

```javascript
GET /api/copyright/reports/:userId
```

### 3. ইউজারের কপিরাইট নোটিফিকেশন পান (Get User Copyright Notifications)

```javascript
GET /api/copyright/notifications/:userId
```

### 4. নোটিফিকেশন রিড মার্ক করুন (Mark Notification as Read)

```javascript
POST /api/copyright/notifications/:notificationId/read
```

### 5. ইউজার কপিরাইট স্ট্যাটাস পান (Get User Copyright Status)

```javascript
GET /api/copyright/status/:userId
```

### 6. অ্যাডমিন: কপিরাইট রিপোর্ট রিভিউ করুন (Admin: Review Copyright Report)

```javascript
POST /api/copyright/review
Headers: Authorization: Bearer <admin_token>

{
  "reportId": 123,
  "status": "confirmed", // reviewed, confirmed, rejected
  "reviewedBy": "admin_id"
}
```

### 7. অ্যাডমিন: ডিলিট কিউ স্ট্যাটাস পান (Admin: Get Delete Queue Status)

```javascript
GET /api/copyright/delete-queue
Headers: Authorization: Bearer <admin_token>
```

### 8. অ্যাডমিন: ম্যানুয়াল ডিলিট (Admin: Manual Delete)

```javascript
POST /api/copyright/delete-now
Headers: Authorization: Bearer <admin_token>

{
  "contentId": "content_id",
  "contentType": "video",
  "userId": "user_id"
}
```

### উন্নত এন্ডপয়েন্টসমূহ (Advanced Endpoints)

### 9. AI-ভিত্তিক কন্টেন্ট ডিটেকশন (AI-Based Content Detection)

```javascript
POST /api/copyright/ai-detect

{
  "contentId": "content_id",
  "contentType": "video",
  "contentData": "content_data_or_url",
  "contentUrl": "https://example.com/content"
}
```

**Response:**
```javascript
{
  "success": true,
  "detection": {
    "isFlagged": false,
    "confidenceScore": 15,
    "flagReason": "",
    "detectionType": "copyright"
  }
}
```

### 10. কন্টেন্ট ফিঙ্গারপ্রিন্টিং (Content Fingerprinting)

```javascript
POST /api/copyright/fingerprint

{
  "contentId": "content_id",
  "contentType": "video",
  "contentData": "content_data"
}
```

**Response:**
```javascript
{
  "success": true,
  "fingerprint": {
    "id": 1,
    "fingerprintHash": "abc123...",
    "isBlacklisted": false
  },
  "isDuplicate": false,
  "warning": null
}
```

### 11. কন্টেন্ট স্ক্যান কিউতে যোগ করুন (Add to Scan Queue)

```javascript
POST /api/copyright/scan

{
  "contentId": "content_id",
  "contentType": "video",
  "contentUrl": "https://example.com/content",
  "scanType": "all", // copyright, adult, violence, all
  "priority": 5 // 1-10, 1 = highest priority
}
```

### 12. ইউজার ওয়ার্নিং তৈরি করুন (Create User Warning) - Admin

```javascript
POST /api/copyright/warning
Headers: Authorization: Bearer <admin_token>

{
  "userId": "user_id",
  "warningType": "copyright",
  "warningMessage": "Repeated copyright violations detected",
  "warningLevel": 2,
  "expiresInDays": 30
}
```

### 13. ইউজার ওয়ার্নিং পান (Get User Warnings)

```javascript
GET /api/copyright/warnings/:userId
```

### 14. ইউজার রেপুটেশন পান (Get User Reputation)

```javascript
GET /api/copyright/reputation/:userId
```

**Response:**
```javascript
{
  "reputation": {
    "userId": "user_id",
    "reputationScore": 85,
    "trustLevel": "trusted",
    "totalReportsSubmitted": 10,
    "accurateReports": 8,
    "falseReports": 2,
    "reportAccuracyRate": 80.00,
    "totalViolations": 1,
    "consecutiveCleanDays": 15
  }
}
```

### 15. ইউজার রেপুটেশন আপডেট করুন (Update User Reputation) - Admin

```javascript
POST /api/copyright/reputation/update
Headers: Authorization: Bearer <admin_token>

{
  "userId": "user_id",
  "action": "accurate_report", // accurate_report, false_report, violation, clean_day, appeal_approved
  "metadata": {}
}
```

### 16. অ্যাপিল জমা দিন (Submit Appeal)

```javascript
POST /api/copyright/appeal

{
  "reportId": 123,
  "userId": "user_id",
  "appealReason": "This content is original and licensed",
  "evidenceUrls": ["https://example.com/license.pdf"]
}
```

### 17. অ্যাপিল রিভিউ করুন (Review Appeal) - Admin

```javascript
POST /api/copyright/appeal/review
Headers: Authorization: Bearer <admin_token>

{
  "appealId": 456,
  "status": "approved", // approved, rejected
  "adminNotes": "License verified",
  "reviewedBy": "admin_id"
}
```

### 18. কন্টেন্ট হোয়াইটলিস্ট করুন (Whitelist Content) - Admin

```javascript
POST /api/copyright/whitelist
Headers: Authorization: Bearer <admin_token>

{
  "contentId": "content_id",
  "contentType": "video",
  "whitelistedBy": "admin_id",
  "whitelistReason": "Licensed content",
  "isPermanent": false,
  "expiryDays": 30
}
```

### 19. হোয়াইটলিস্ট চেক করুন (Check Whitelist)

```javascript
GET /api/copyright/whitelist/check/:contentId
```

### 20. সোর্স ব্ল্যাকলিস্ট করুন (Blacklist Source) - Admin

```javascript
POST /api/copyright/blacklist-source
Headers: Authorization: Bearer <admin_token>

{
  "sourceName": "YouTube",
  "sourceUrl": "https://youtube.com",
  "sourceType": "platform",
  "blacklistReason": "Copyright violations",
  "addedBy": "admin_id",
  "severity": "high"
}
```

### 21. ব্ল্যাকলিস্ট চেক করুন (Check Blacklist)

```javascript
GET /api/copyright/blacklist/check/:sourceName
```

### 22. অ্যানালিটিক্স ড্যাশবোর্ড পান (Get Analytics Dashboard) - Admin

```javascript
GET /api/copyright/analytics?startDate=2024-01-01&endDate=2024-01-31&period=daily
Headers: Authorization: Bearer <admin_token>
```

**Response:**
```javascript
{
  "analytics": [...],
  "summary": {
    "totalReports": 150,
    "confirmedViolations": 120,
    "falseReports": 30,
    "autoDeletions": 100,
    "manualDeletions": 20,
    "appealsSubmitted": 15,
    "appealsApproved": 10,
    "usersFlagged": 45,
    "usersCleared": 30,
    "accuracyRate": 80.00
  },
  "period": {
    "start": "2024-01-01",
    "end": "2024-01-31",
    "granularity": "daily"
  }
}
```

## ফ্রন্টএন্ড ব্যবহার (Frontend Usage)

### বেসিক ফিচারসমূহ (Basic Features)

### 1. কপিরাইট রিপোর্ট জমা দিন (Submit Copyright Report)

```javascript
// কন্টেন্ট রিপোর্ট করুন
MonetixraCopyright.reportContent('video', 'video_123', {
  targetUserId: 'user_456',
  contentUrl: 'https://example.com/video.mp4',
  originalSource: 'YouTube',
  reason: 'This video is copied from YouTube without permission',
  severity: 'high'
});
```

### 2. কপিরাইট স্ট্যাটাস চেক করুন (Check Copyright Status)

```javascript
// ইউজার স্ট্যাটাস পান
const status = await MonetixraCopyright.getStatus('user_id');
console.log('Copyright Free:', status.isCopyrightFree);
console.log('Active Violations:', status.activeViolations);
```

### 3. নোটিফিকেশন পান (Get Notifications)

```javascript
// নোটিফিকেশন পান
const notifications = await MonetixraCopyright.getNotifications('user_id');
console.log('Unread notifications:', notifications.filter(n => !n.is_read));
```

### 4. ম্যানুয়াল ইনিশিয়ালাইজেশন (Manual Initialization)

```javascript
// সিস্টেম ম্যানুয়ালি ইনিশিয়ালাইজ করুন
MonetixraCopyright.initialize();
```

### উন্নত ফিচারসমূহ (Advanced Features)

### 5. AI-ভিত্তিক কন্টেন্ট ডিটেকশন (AI-Based Content Detection)

```javascript
// AI ডিটেকশন চালান
const detection = await MonetixraCopyright.aiDetectContent(
  'content_123',
  'video',
  'video_data_or_url',
  'https://example.com/video.mp4'
);

console.log('Is Flagged:', detection.isFlagged);
console.log('Confidence Score:', detection.confidenceScore);
```

### 6. কন্টেন্ট ফিঙ্গারপ্রিন্টিং (Content Fingerprinting)

```javascript
// ফিঙ্গারপ্রিন্ট জেনারেট করুন
const fingerprint = await MonetixraCopyright.generateFingerprint(
  'content_123',
  'video',
  'video_data'
);

console.log('Is Duplicate:', fingerprint.isDuplicate);
console.log('Fingerprint Hash:', fingerprint.fingerprint?.fingerprintHash);
```

### 7. কন্টেন্ট স্ক্যান কিউতে যোগ করুন (Add to Scan Queue)

```javascript
// স্ক্যান কিউতে যোগ করুন
await MonetixraCopyright.queueContentScan(
  'content_123',
  'video',
  'https://example.com/video.mp4',
  'all',
  5 // priority
);
```

### 8. ইউজার ওয়ার্নিং পান (Get User Warnings)

```javascript
// ওয়ার্নিং পান
const warnings = await MonetixraCopyright.getUserWarnings('user_id');
console.log('Active Warnings:', warnings);
```

### 9. ওয়ার্নিং মডাল দেখান (Show Warnings Modal)

```javascript
// ওয়ার্নিং মডাল দেখান
MonetixraCopyright.showWarningsModal(warnings);
```

### 10. ইউজার রেপুটেশন পান (Get User Reputation)

```javascript
// রেপুটেশন পান
const reputation = await MonetixraCopyright.getUserReputation('user_id');
console.log('Reputation Score:', reputation.reputationScore);
console.log('Trust Level:', reputation.trustLevel);
```

### 11. রেপুটেশন ব্যাজ দেখান (Show Reputation Badge)

```javascript
// রেপুটেশন ব্যাজ দেখান
MonetixraCopyright.showReputationBadge(reputation);
```

### 12. রেপুটেশন মডাল দেখান (Show Reputation Modal)

```javascript
// রেপুটেশন মডাল দেখান
MonetixraCopyright.showReputationModal(reputation);
```

### 13. অ্যাপিল জমা দিন (Submit Appeal)

```javascript
// অ্যাপিল জমা দিন
const result = await MonetixraCopyright.submitAppeal(
  123, // reportId
  'This content is original and licensed',
  ['https://example.com/license.pdf']
);

console.log('Appeal Submitted:', result.success);
```

### 14. অ্যাপিল মডাল দেখান (Show Appeal Modal)

```javascript
// অ্যাপিল মডাল দেখান
MonetixraCopyright.showAppealModal(123); // reportId
```

### 15. হোয়াইটলিস্ট চেক করুন (Check Whitelist)

```javascript
// হোয়াইটলিস্ট চেক করুন
const isWhitelisted = await MonetixraCopyright.checkWhitelist('content_123');
console.log('Is Whitelisted:', isWhitelisted);
```

### 16. ব্ল্যাকলিস্ট চেক করুন (Check Blacklist)

```javascript
// ব্ল্যাকলিস্ট চেক করুন
const isBlacklisted = await MonetixraCopyright.checkBlacklist('YouTube');
console.log('Is Blacklisted:', isBlacklisted);
```

### 17. কমপ্রিহেন্সিভ কন্টেন্ট চেক (Comprehensive Content Check)

```javascript
// সম্পূর্ণ কন্টেন্ট চেক
const results = await MonetixraCopyright.comprehensiveContentCheck(
  'content_123',
  'video',
  'video_data',
  'https://example.com/video.mp4',
  'YouTube'
);

console.log('Overall Safe:', results.overallSafe);
console.log('Warnings:', results.warnings);
console.log('AI Detection:', results.aiDetection);
console.log('Fingerprint:', results.fingerprint);
```

### 18. কন্টেন্ট চেক রেজাল্ট দেখান (Show Content Check Results)

```javascript
// কন্টেন্ট চেক রেজাল্ট দেখান
MonetixraCopyright.showContentCheckResults(results);
```

### আপলোডের আগে কন্টেন্ট চেক (Pre-Upload Content Check)

```javascript
// আপলোডের আগে কন্টেন্ট চেক করুন
async function uploadWithCheck(contentData, contentType, sourceName) {
  const contentId = 'content_' + Date.now();
  
  // কমপ্রিহেন্সিভ চেক
  const checkResults = await MonetixraCopyright.comprehensiveContentCheck(
    contentId,
    contentType,
    contentData,
    '',
    sourceName
  );
  
  // রেজাল্ট দেখান
  MonetixraCopyright.showContentCheckResults(checkResults);
  
  // যদি নিরাপদ হয় তবে আপলোড করুন
  if (checkResults.overallSafe) {
    // আপলোড লজিক
    console.log('Proceeding with upload...');
  } else {
    console.log('Upload blocked due to copyright concerns');
  }
}
```

## ডাটাবেস টেবিল স্ট্রাকচার (Database Table Structure)

### copyright_reports
কপিরাইট রিপোর্ট সংরক্ষণ করে।

### copyright_violations
ইউজার ভায়োলেশন হিস্ট্রি ট্র্যাক করে।

### copyright_notifications
ইউজারকে পাঠানো নোটিফিকেশন সংরক্ষণ করে।

### user_copyright_status
ইউজারের কপিরাইট-মুক্ত স্ট্যাটাস ট্র্যাক করে।

### auto_delete_queue
স্কেডিউলড ডিলিট টাস্ক সংরক্ষণ করে।

## অটোমেটিক প্রসেস (Automatic Process)

### স্কেডিউলার (Scheduler)
- প্রতি ৬০ মিনিটে রান হয়
- পেন্ডিং ডিলিট চেক করে
- ডিউ ডিলিট প্রসেস করে
- ইউজারকে নোটিফাই করে
- স্ট্যাটাস আপডেট করে

### স্ট্যাটাস আপডেট (Status Update)
- কনফার্মড রিপোর্টে অটো ডিলিট স্কেডিউল হয়
- ডিলিট কমপ্লিট হলে ভায়োলেশন রিজলভড হয়
- অ্যাক্টিভ ভায়োলেশন ০ হলে ইউজার কপিরাইট-মুক্ত হয়

## সিকিউরিটি ফিচারসমূহ (Security Features)

1. **অ্যাডমিন অথেন্টিকেশন**: সংবেদনশীল এন্ডপয়েন্টে অ্যাডমিন টোকেন প্রয়োজন
2. **রেট লিমিটিং**: অ্যাবিউজ প্রতিরোধ করতে রেট লিমিট
3. **ভ্যালিডেশন**: ইনপুট ভ্যালিডেশন এবং স্যানিটাইজেশন
4. **অডিট লগ**: সব অ্যাকশন লগ করা হয়

## ট্রাবলশুটিং (Troubleshooting)

### স্কিমা ইনস্টলেশন সমস্যা
```bash
# PostgreSQL সংযোগ চেক করুন
psql -U your_user -d your_database -c "SELECT version();"
```

### স্কেডিউলার রান হচ্ছে না
```javascript
// সার্ভার লগ চেক করুন
console.log('[Copyright] Running auto-delete scheduler...');
```

### নোটিফিকেশন আসছে না
- VAPID keys চেক করুন
- পুশ সাবস্ক্রিপশন চেক করুন
- ব্রাউজার পারমিশন চেক করুন

## বেস্ট প্র্যাকটিস (Best Practices)

1. **রিপোর্ট রিভিউ**: অ্যাডমিন রিপোর্ট রিভিউ করে কনফার্ম করুন
2. **সিভিয়রিটি লেভেল**: সঠিক সিভিয়রিটি লেভেল ব্যবহার করুন
3. **ইউজার কমিউনিকেশন**: ইউজারকে ক্লিয়ার নোটিফিকেশন দিন
4. **অডিট লগ**: নিয়মিত অডিট লগ চেক করুন
5. **ব্যাকআপ**: ডাটাবেস ব্যাকআপ রাখুন

## সাপোর্ট (Support)

সমস্যা হলে:
1. সার্ভার লগ চেক করুন
2. ডাটাবেস কানেকশন চেক করুন
3. এনভায়রনমেন্ট ভেরিয়েবল চেক করুন
4. API রেসপন্স চেক করুন

## লাইসেন্স (License)

এই সিস্টেমটি Monetixra প্ল্যাটফর্মের অংশ। বাণিজ্যিক ব্যবহারের জন্য অনুমতি প্রয়োজন।

---

**নোট**: এই সিস্টেমটি শুধুমাত্র লিগ্যাল কপিরাইট এনফোর্সমেন্টের জন্য ডিজাইন করা হয়েছে। অ্যাবিউস প্রতিরোধ করতে সঠিকভাবে ব্যবহার করুন।

**Note**: This system is designed only for legal copyright enforcement. Use properly to prevent abuse.
