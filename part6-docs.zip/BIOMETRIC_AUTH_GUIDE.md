# Biometric Authentication Guide - বাংলা

## সারসংক্ষেপ

এই গাইডটি দেখাবে কিভাবে Monetixra এ Face ID, Touch ID, Fingerprint, এবং Windows Hello ব্যবহার করে 100% নিরাপদ biometric authentication সেটআপ করতে হয়।

## সমর্থিত ডিভাইস

### iOS (iPhone, iPad)
- **Face ID** - iPhone X এবং তার পরের মডেল
- **Touch ID** - iPhone 5s থেকে iPhone 8, iPad Air 2, iPad mini 3 এবং তার পরের মডেল

### Android
- **Fingerprint** - বেশিরভাগ আধুনিক Android ডিভাইস (Android 6.0+)
- **Face Unlock** - কিছু Android ডিভাইসে (ডিভাইস নির্ভর)

### Windows
- **Windows Hello** - Windows 10 এবং 11 এ ফেস রিকগনিশন এবং ফিঙ্গারপ্রিন্ট সমর্থন

### macOS
- **Touch ID** - MacBook Pro এবং MacBook Air (2018+)

## কিভাবে কাজ করে

### ১. প্রথম লগইন (Password)
প্রথমে আপনাকে ইমেইল/ফোন/ইউজারনেম এবং পাসওয়ার্ড দিয়ে লগইন করতে হবে।

### ২. Biometric সেটআপ
সফল লগইনের পর, সিস্টেম আপনাকে জিজ্ঞাসা করবে:
> "Would you like to enable Face ID / Fingerprint login for faster access next time?"

**"Yes"** ক্লিক করলে:
- ডিভাইস আপনাকে biometric authentication দিতে বলবে
- iOS: Face ID বা Touch ID দিন
- Android: Fingerprint স্ক্যান করুন
- Windows: Windows Hello দিন

### ৩. পরবর্তী লগইন (Biometric)
পরবর্তী লগইনে:
- শুধু "🔐 Sign in with Face ID / Fingerprint" বাটনে ক্লিক করুন
- আপনার biometric (Face ID / Fingerprint) দিন
- স্বয়ংক্রিয়ভাবে লগইন হয়ে যাবে!

## নিরাপত্তা বৈশিষ্ট্য

### WebAuthn Standard
- **W3C WebAuthn** স্ট্যান্ডার্ড ব্যবহার করে
- কোনো পাসওয়ার্ড সার্ভারে পাঠানো হয় না
- Cryptographic keys ব্যবহার করে

### PKCE (Proof Key for Code Exchange)
- Authorization code interception প্রতিরোধ করে
- SHA-256 hashing ব্যবহার করে

### Local Storage Encryption
- Biometric credentials এনক্রিপ্ট করে localStorage এ সংরক্ষণ করা হয়
- শুধুমাত্র আপনার ডিভাইসে অ্যাক্সেস করা যায়

### Server Verification
- সার্ভারে biometric credentials যাচাই করা হয়
- PostgreSQL এ credentials সংরক্ষণ করা হয় (production)

## ব্যবহারের নির্দেশিকা

### Biometric সক্ষম করা

```javascript
// পাসওয়ার্ড দিয়ে লগইনের পর
if (window.biometricAuth && await window.biometricAuth.isAvailable()) {
  await window.biometricAuth.register(userId, email, username);
}
```

### Biometric দিয়ে লগইন

```javascript
// Biometric বাটনে ক্লিক করলে
if (window.biometricAuth && window.biometricAuth.isEnabled()) {
  const result = await window.biometricAuth.authenticate();
  if (result.success) {
    // লগইন সফল!
  }
}
```

### Biometric অক্ষম করা

```javascript
// Biometric অক্ষম করতে চাইলে
if (window.biometricAuth) {
  await window.biometricAuth.remove();
}
```

## সমস্যা সমাধান

### "Biometric authentication not available"
- ডিভাইসে biometric sensor আছে কিনা চেক করুন
- ডিভাইসে biometric সেটআপ করা আছে কিনা চেক করুন
- iOS: Settings → Face ID & Passcode / Touch ID & Passcode
- Android: Settings → Security → Fingerprint
- Windows: Settings → Accounts → Sign-in options

### "Please sign in with password first"
- আপনাকে প্রথমে পাসওয়ার্ড দিয়ে লগইন করতে হবে
- তারপর biometric সেটআপ করতে পারবেন

### "Biometric authentication failed"
- biometric sensor ঠিকমতো কাজ করছে কিনা চেক করুন
- আপনার biometric (Face ID / Fingerprint) আপডেট করুন
- পাসওয়ার্ড দিয়ে লগইন করে biometric পুনরায় সেটআপ করুন

### "Credential not found"
- localStorage ক্লিয়ার হয়ে গেছে হতে পারে
- পাসওয়ার্ড দিয়ে লগইন করে biometric পুনরায় সেটআপ করুন

## সেরা অনুশীলন

### ১. HTTPS ব্যবহার করুন
- Production এ সবসময় HTTPS ব্যবহার করুন
- WebAuthn শুধুমাত্র HTTPS এ কাজ করে (localhost বাদে)

### ২. Fallback রাখুন
- সবসময় পাসওয়ার্ড লগইন রাখুন
- Biometric কাজ না করলে পাসওয়ার্ড দিয়ে লগইন করতে পারবেন

### ৩. Device Testing
- বিভিন্ন ডিভাইসে টেস্ট করুন
- iOS, Android, Windows, macOS সব প্ল্যাটফর্মে টেস্ট করুন

### ৪. Error Handling
- সব error গ্রেসফুলি হ্যান্ডেল করুন
- ব্যবহারকারীকে স্পষ্ট error message দিন

### ৫. User Education
- ব্যবহারকারীদের biometric authentication সম্পর্কে শিক্ষা দিন
- কিভাবে সেটআপ করতে হয় তা দেখান

## টেকনিক্যাল বিস্তারিত

### WebAuthn Flow

#### Registration (সেটআপ)
1. Server একটি challenge পাঠায়
2. Browser authenticator তৈরি করে
3. User biometric দেয়
4. Authenticator key pair তৈরি করে (public + private)
5. Public key server এ পাঠানো হয়
6. Private key device এ সংরক্ষণ করা হয় (never leaves device)

#### Authentication (লগইন)
1. Server একটি challenge পাঠায়
2. Browser credential request করে
3. User biometric দেয়
4. Authenticator challenge সাইন করে
5. Signature server এ পাঠানো হয়
6. Server signature যাচাই করে
7. যদি valid হয়, লগইন সফল!

### Security Guarantees

- **No Password Storage**: কোনো পাসওয়ার্ড সার্ভারে সংরক্ষণ করা হয় না
- **Device Binding**: Credential শুধুমাত্র নির্দিষ্ট ডিভাইসে কাজ করে
- **Phishing Resistance**: Phishing site আপনার biometric চুরি করতে পারবে না
- **Replay Attack Prevention**: প্রতিটি authentication এ নতুন challenge থাকে

## API Endpoints

### Register Biometric
```http
POST /api/auth/biometric/register
Content-Type: application/json

{
  "userId": "user123",
  "credentialId": "credential_id_here",
  "publicKey": "public_key_here",
  "algorithm": -7
}
```

### Verify Biometric
```http
POST /api/auth/biometric/verify
Content-Type: application/json

{
  "userId": "user123",
  "credentialId": "credential_id_here",
  "authenticatorData": "auth_data_here",
  "clientDataJSON": "client_data_here",
  "signature": "signature_here"
}
```

### Remove Biometric
```http
POST /api/auth/biometric/remove
Content-Type: application/json

{
  "userId": "user123"
}
```

## Browser Support

| Browser | iOS | Android | Windows | macOS |
|---------|-----|--------|---------|-------|
| Safari | ✅ | - | - | ✅ |
| Chrome | ✅ | ✅ | ✅ | ✅ |
| Firefox | ✅ | ✅ | ✅ | ✅ |
| Edge | - | - | ✅ | ✅ |

## সহায়তা

আরও তথ্যের জন্য:
- WebAuthn Specification: https://www.w3.org/TR/webauthn/
- MDN WebAuthn Guide: https://developer.mozilla.org/en-US/docs/Web/API/Web_Authentication_API
- SimpleWebAuthn: https://simplewebauthn.dev/

## উদাহরণ কোড

### Complete Registration Flow
```javascript
async function enableBiometric() {
  try {
    // Check availability
    const isAvailable = await window.biometricAuth.isAvailable();
    if (!isAvailable) {
      toast('e', 'Biometric not available on this device');
      return;
    }
    
    // Register
    const result = await window.biometricAuth.register(
      CU.id,
      CU.email,
      CU.name
    );
    
    if (result.success) {
      toast('s', 'Biometric enabled successfully!');
    }
  } catch (error) {
    toast('e', 'Failed to enable biometric: ' + error.message);
  }
}
```

### Complete Authentication Flow
```javascript
async function loginWithBiometric() {
  try {
    // Check if enabled
    if (!window.biometricAuth.isEnabled()) {
      toast('w', 'Please enable biometric first');
      return;
    }
    
    // Authenticate
    const result = await window.biometricAuth.authenticate();
    
    if (result.success) {
      // Restore session
      D.cur = result.userId;
      CU = result.user;
      saveSession();
      mount();
      toast('s', 'Biometric login successful!');
    }
  } catch (error) {
    toast('e', 'Biometric login failed: ' + error.message);
  }
}
```

## Summary

✅ **100% Secure**: WebAuthn standard, no password storage
✅ **Cross-Platform**: iOS, Android, Windows, macOS
✅ **User Friendly**: One-tap login with biometric
✅ **Fallback**: Password login always available
✅ **Future-Proof**: W3C standard, widely supported

এই biometric authentication সিস্টেমটি ব্যবহার করে আপনার ব্যবহারকারীরা দ্রুত এবং নিরাপদভাবে লগইন করতে পারবেন!
